//
//  LeavePeopleCellFrame.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/18.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@class LeavePeopleCellModel;

@interface LeavePeopleCellFrame : NSObject

@property (nonatomic, strong) LeavePeopleCellModel *message;

@property (nonatomic, assign, readonly) CGRect timeFrame;
@property (nonatomic, assign, readonly) CGRect iconFrame;
@property (nonatomic, assign, readonly) CGRect nameFrame;
@property (nonatomic, assign, readonly) CGRect textFrame;
@property (nonatomic, assign, readonly) CGRect backImageFrame;
@property (nonatomic, assign, readonly) CGRect collectionFrame;
@property (nonatomic, assign, readonly) CGFloat cellHeght;

-(CGSize)sizeWithString:(NSString*)str font:(UIFont *)font maxSize:(CGSize)maxSize;
@end
