//
//  LineDetailCellFrame.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/12.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//


#import "LineDetailCellFrame.h"

@implementation LineDetailCellFrame
- (void)setWeibo:(LineDetailCellModel *)weibo{
    _weibo=weibo;
    CGFloat jiange =0;
    if (IS_IPAD) {
        jiange=25;
    }
    else
    {
        jiange=8;
    }
    _start_dateFrame=CGRectMake(jiange, 8, 68, 21);
    _fengefuFrame=CGRectMake(21, 25, 42, 14);
    _end_dateFrame=CGRectMake(jiange, 37, 68, 21);
    _circleImageFrame=CGRectMake(79, 14, 20, 20);
    CGSize weight = [_weibo.projectTitleString sizeWithAttributes:@{NSFontAttributeName:[UIFont fontWithName:@"Arial" size:17]}];
    if (weight.width>kScreenW-CGRectGetMaxX(_start_dateFrame)-3-10) {
        weight.width=kScreenW-CGRectGetMaxX(_start_dateFrame)-3-10;
    }
    _projectTitleFrame=CGRectMake(CGRectGetMaxX(_circleImageFrame)+jiange, 13, weight.width, weight.height);
    
    weight = [_weibo.responNameLabelString sizeWithAttributes:@{NSFontAttributeName:[UIFont fontWithName:@"Arial" size:15]}];
    if (weight.width>kScreenW-CGRectGetMaxX(_circleImageFrame)-jiange-70) {
        weight.width=kScreenW-CGRectGetMaxX(_circleImageFrame)-jiange-70;
    }
    _responNameLabelFrame=CGRectMake(CGRectGetMaxX(_start_dateFrame)+jiange+25, CGRectGetMaxY(_projectTitleFrame)+20, weight.width, weight.height);
    
    _dateLabelFrame=CGRectMake(CGRectGetMaxX(_responNameLabelFrame)+5, _responNameLabelFrame.origin.y, 60, _responNameLabelFrame.size.height);
    CGSize complete=[self sizeWithString:_weibo.complete_stdString font:[UIFont fontWithName:@"Arial" size:15] maxSize:CGSizeMake(kScreenW-CGRectGetMaxX(_circleImageFrame)-8-10, MAXFLOAT)];
    _complete_stdFrame=CGRectMake(_responNameLabelFrame.origin.x, CGRectGetMaxY(_responNameLabelFrame)+2, complete.width, complete.height);
    
    _maxHeight=CGRectGetMaxY(_complete_stdFrame)+20;
    _lineFrame=CGRectMake(88, 0, 2, _maxHeight);
    
    _backImageFrame=CGRectMake(CGRectGetMaxX(_circleImageFrame)+1, 9, kScreenW-8-CGRectGetMaxX(_circleImageFrame)-1, CGRectGetMaxY(_complete_stdFrame)-4);
    
    
    
}
-(CGSize)sizeWithString:(NSString*)str font:(UIFont *)font maxSize:(CGSize)maxSize{
    NSDictionary *dict=@{NSFontAttributeName:font};
    if (![str length]) {
        CGSize tempSize=CGSizeMake(0, 0);
        return tempSize;
    }
    CGSize size=[str boundingRectWithSize:maxSize options:NSStringDrawingUsesLineFragmentOrigin attributes:dict context:nil].size;
    return size;
    
}
@end
