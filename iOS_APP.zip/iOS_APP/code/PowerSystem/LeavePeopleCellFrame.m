//
//  LeavePeopleCellFrame.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/18.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "LeavePeopleCellFrame.h"
#import "LeavePeopleCellModel.h"
#define padding 10
#define imageDistance 5
#define iconW 40
#define iconH 40
#define nameW 180
//展示图片的大小
#define kCollImg 80

#define textW 245
@implementation LeavePeopleCellFrame

-(void)setMessage:(LeavePeopleCellModel *)message{
    _message=message;
    //时间frame
    CGFloat timeLabelX=0;
    CGFloat timeLabelY=0;
    CGFloat timeLabelW=kScreenW;
    CGFloat timeLabelH=18;
    _timeFrame=CGRectMake(timeLabelX, timeLabelY, timeLabelW, timeLabelH);
    
    //图标frame
    CGFloat iconFrameX = _message.is_self ? (kScreenW - padding - iconW) : padding;
    CGFloat iconFrameY = CGRectGetMaxY(_timeFrame);
    CGFloat iconFrameW = iconW;
    CGFloat iconFrameH = iconH;
    _iconFrame = CGRectMake(iconFrameX, iconFrameY, iconFrameW, iconFrameH);
    
    //名称frame
    
    CGSize nameSize = [self sizeWithString:_message.user_name font:[UIFont systemFontOfSize:15.0] maxSize:CGSizeMake(nameW, 21)];
    CGFloat nameFrameX = _message.is_self ? kScreenW - padding-iconW-nameSize.width:CGRectGetMaxX(_iconFrame)+2 ;
    CGFloat nameFrameY = iconFrameY;
    CGFloat nameFrameW = nameSize.width;
    CGFloat nameFrameH = nameSize.height;
    _nameFrame = CGRectMake(nameFrameX, nameFrameY, nameFrameW, nameFrameH);
    


    
    //文字frame

    CGSize textSize = [message.content sizeWithAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:17.0]}];
    
    if (textSize.width>=245) {
        
        textSize =[self sizeWithString:message.content font:[UIFont systemFontOfSize:17.0] maxSize:CGSizeMake(textW, MAXFLOAT)];
    }

    
    CGFloat textFrameX;
    if (message.is_self) {
        textFrameX = 7.0;
    }else{
        textFrameX = 12.0;
    }
    
    
    CGFloat textFrameY = 10.0;
    _textFrame=CGRectMake(textFrameX, textFrameY, textSize.width, textSize.height);
    
    
    //图片frame
    CGFloat connectionFrameW =kCollImg*3+4;
    CGFloat connectionFrameX =textFrameX;
    CGFloat connectionFrameY = CGRectGetMaxY(_textFrame)+5;
    CGFloat connectionFrameH =0;
    
    if ([_message.image_list count]==0) {
        connectionFrameH=0;
        connectionFrameW=0;
        connectionFrameY = CGRectGetMaxY(_textFrame);
    }
    else
    {
        if ([_message.image_list count]<=3) {
            connectionFrameH=kCollImg;
            if ([_message.image_list count]==1) {
                connectionFrameW=kCollImg;

            }
            else if ([_message.image_list count]==2){
                connectionFrameW=kCollImg*2+2;
            }else{
                connectionFrameW =kCollImg*3+4;
            }
        }
        else if ([_message.image_list count]>3&&[_message.image_list count]<7)
        {
            connectionFrameH=2*kCollImg+2;
            if ([_message.image_list count]==4) {
                connectionFrameW=kCollImg*2+2;
            }else{
                connectionFrameW=kCollImg*3+4;
            }
        }
        else
        {
            connectionFrameW =kCollImg*3+4;
            connectionFrameH =3*kCollImg+4;
        }
    }
    
    _collectionFrame = CGRectMake(connectionFrameX, connectionFrameY, connectionFrameW, connectionFrameH);
    
    //底图的位置
    CGFloat backFrameW;
    CGFloat backFrameX;
    CGFloat backFrameY = CGRectGetMaxY(_nameFrame)+5;
    if (textSize.width>connectionFrameW) {
        backFrameW = textSize.width + padding+10;
        backFrameX = _message.is_self ?  (kScreenW-iconW-3*padding-textSize.width):CGRectGetMaxX(_iconFrame);
    }else{
        backFrameW = connectionFrameW + padding+10;
        backFrameX = _message.is_self ?  (kScreenW-iconW-3*padding-connectionFrameW):CGRectGetMaxX(_iconFrame);
    }
    CGFloat backFrameH = connectionFrameH +_textFrame.size.height +2*padding+10;
    
    
    
    
    _backImageFrame = CGRectMake(backFrameX, backFrameY, backFrameW, backFrameH);
    
    _cellHeght = CGRectGetMaxY(_backImageFrame)+2*padding;
    NSLog(@"-----BackFrame:%@---height:%f",NSStringFromCGRect(_backImageFrame),_cellHeght);
    
}
-(CGSize)sizeWithString:(NSString*)str font:(UIFont *)font maxSize:(CGSize)maxSize{
    NSDictionary *dict=@{NSFontAttributeName:font};
    if (![str length]) {
        CGSize tempSize=CGSizeMake(0, 0);
        return tempSize;
    }
    CGSize size=[str boundingRectWithSize:maxSize options:NSStringDrawingUsesLineFragmentOrigin attributes:dict context:nil].size;
    return size;
    
}
@end
