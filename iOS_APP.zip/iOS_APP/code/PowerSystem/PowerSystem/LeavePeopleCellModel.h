//
//  LeavePeopleCellModel.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/18.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LeavePeopleCellModel : NSObject

@property(nonatomic,copy)NSNumber *user_id;
@property(nonatomic,copy)NSString *user_name;
@property(nonatomic,copy)NSString *content;
@property(nonatomic,copy)NSArray *image_list;
@property(nonatomic,copy)NSString *time;
@property(nonatomic,assign)BOOL is_self;

+ (instancetype)messageModelWithDict:(NSDictionary *)dict;
@end
