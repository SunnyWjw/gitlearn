//
//  SearchFileModel.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/18.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SearchFileModel : NSObject
@property(nonatomic,copy)NSNumber *id;
@property(nonatomic,copy)NSString *type;
@property(nonatomic,copy)NSString *name;
@property(nonatomic,copy)NSString *size;
@property(nonatomic,copy)NSString *path;
@property(nonatomic,copy)NSString *date;
@end
