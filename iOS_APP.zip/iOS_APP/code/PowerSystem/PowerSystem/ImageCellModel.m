//
//  ImageCellModel.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/15.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "ImageCellModel.h"

@implementation ImageCellModel

@end
