//
//  ChildSexView.h
//  JxbApp
//
//  Created by huhaifeng on 15/7/31.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LineDetailCellFrame.h"
@interface ChildSexView : UIView<UITableViewDataSource,UITableViewDelegate,UIGestureRecognizerDelegate,UITextFieldDelegate>

typedef NS_ENUM(NSInteger, ChildSexViewState){
    ChildSexViewServer = 0,
    ChildSexViewEditPassword = 1,
    ChildSexViewEditSlide=2,
    CHildSexViewTimeOkView=3,
};
@property (nonatomic,assign) ChildSexViewState statye;
@property (nonatomic,copy) void(^ServerBlock)(NSString *ServerString,NSString *two,NSString *three);

-(instancetype)initWithBlock:(void(^)(NSString *str,NSString *two,NSString *three))block Type:(ChildSexViewState)type;
-(void)show:(int)man IDControl:(id)Id;
-(void)dissshow;

@property (nonatomic,copy) void(^cellDateNumBlock)(int dateNum);

@property (nonatomic,copy) void(^cellDateOkNumberBlock)(int dateNum);

-(void)getSliderViewModel:(LineDetailCellFrame *)frame block:(void(^)(int num))dateBlock;

-(void)getTimeOkViewModel:(LineDetailCellFrame *)frames block:(void(^)(int num))dateBlock;
@end
