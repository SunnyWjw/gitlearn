//
//  imageViewCell.h
//  JxbApp
//
//  Created by huhaifeng on 15/7/20.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface imageViewCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UILabel *imageName;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@end
