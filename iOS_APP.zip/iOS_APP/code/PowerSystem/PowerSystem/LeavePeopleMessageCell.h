//
//  LeavePeopleMessageCell.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/18.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@class LeavePeopleCellFrame;

@interface LeavePeopleMessageCell : UITableViewCell<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>

@property (nonatomic, strong) LeavePeopleCellFrame *cellFrame;
@property (nonatomic, strong) NSArray *imagesArray;
@property (nonatomic, strong) NSMutableArray *imagesURLArray;
@property (nonatomic, strong) NSMutableArray *CellImagesArray;
@end
