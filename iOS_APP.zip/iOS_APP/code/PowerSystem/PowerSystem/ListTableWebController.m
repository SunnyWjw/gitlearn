//
//  ListTableWebController.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/17.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "ListTableWebController.h"
#import "AFNetworking.h"
@interface ListTableWebController (){
    LineProjectModel *projectModel;
    UIActivityIndicatorView *activityIndicatorView;
    int num;
    UIButton *buttonleft;
}

@end

@implementation ListTableWebController

- (void)viewDidLoad {
    [super viewDidLoad];
    //[self getHtmlWebView];

    
   
    


}
-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    [self getWebViewFile];
    
    [self initWebViewRequest:num];
    
    [self initButtonBack];

    [[UIAccelerometer sharedAccelerometer]setDelegate:self];
}

-(void)initButtonBack{
    buttonleft= [[UIButton alloc]init];
    buttonleft.backgroundColor=[UIColor grayColor];
    buttonleft.alpha=0.3;
    [buttonleft setBackgroundImage:[UIImage imageNamed:@"tablelist_back"] forState:UIControlStateNormal];
    [buttonleft addTarget:self action:@selector(LeftButtonBack) forControlEvents:UIControlEventTouchDown];
    buttonleft.frame=CGRectMake(5, 5, 50, 50);
    UIWindow *mainWindow = [[UIApplication sharedApplication] keyWindow];
    [mainWindow addSubview:buttonleft];
}

-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    [[UIAccelerometer sharedAccelerometer] setDelegate:nil];
}
-(void)LeftButtonBack
{
    [buttonleft removeFromSuperview];
    [self dismissViewControllerAnimated:YES
                             completion:^{
                              
                             }];
    
}
-(void)accelerometer:(UIAccelerometer *)accelerometer didAccelerate:(UIAcceleration *)acceleration{
    
    if (fabs(acceleration.x)>2.0 ||fabs(acceleration.y)>2.0 ||fabs(acceleration.z)>2.0) {
         [buttonleft removeFromSuperview];
                [self dismissViewControllerAnimated:YES
                                         completion:^{
                                            
                                         }];
        
        NSLog(@"检测到晃动");
    }
//    if (self.interfaceOrientation==UIInterfaceOrientationLandscapeLeft){
//        buttonleft.frame=CGRectMake(5, kScreenH-55, 50, 50);
//    }else if (self.interfaceOrientation==UIInterfaceOrientationPortrait){
//        buttonleft.frame = CGRectMake(kScreenW-55, kScreenH-55, 50, 50);
//    }
}
- (BOOL)shouldAutorotate
{
    return NO;
}

-(UIInterfaceOrientation)preferredInterfaceOrientationForPresentation
{
    return UIInterfaceOrientationLandscapeLeft;
}

-(NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskLandscapeLeft;
}
-(void)getExcelNumber:(int)number{
    num=number;
}
-(void)getProjectId:(LineProjectModel *)model{
    projectModel=model;
}

-(void)initWebViewRequest :(int)numer{
    NSString *str;
    
    if (numer>0) {
        if (numer==1) {
            //预计
            str= [NSString stringWithFormat:@"http://%@/report/export.html?type=plan",IPAddress];
        }
        else
        {
            str= [NSString stringWithFormat:@"http://%@/report/export.html?type=shiji",IPAddress];
        }
    }
    else
    {
        int idnum=[projectModel.id intValue];
        str= [NSString stringWithFormat:@"http://%@/Mobile/PlanVSReal?id=%d",IPAddress,idnum];
    }

    NSString *strurl=[str stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURL *url=[NSURL URLWithString:strurl];
    [self.web_view loadRequest:[NSURLRequest requestWithURL:url]];
}
-(void)getHtmlWebView{
    int idnum=[projectModel.id intValue];
    NSString *str= [NSString stringWithFormat:@"http://%@/Mobile/PlanVSReal?id=%d",IPAddress,idnum];
    NSURL *url=[NSURL URLWithString:str];
    NSURLRequest *request = [[NSURLRequest alloc]initWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:10];
    NSURLConnection *connection = [[NSURLConnection alloc]initWithRequest:request delegate:self];
//    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
//    [manager GET:str parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
//        NSLog(@"--%@",[operation responseString]);
//        NSNumber *status=[responseObject objectForKey:@"status"];
//        if ([status intValue]==1){
//
//        }else{
//            [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:[responseObject objectForKey:@"info"]];
//        }
//    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
//        NSLog(@"error*___%@",[error localizedDescription]);
//        [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"网络错误"];
//    }];
    if (connection) {
        
    }
    
}

-(void)getWebViewFile{
    activityIndicatorView = [[UIActivityIndicatorView alloc]
                             initWithFrame : CGRectMake(0 ,0, 32.0f, 32.0f)] ;
    [activityIndicatorView setCenter: self.view.center] ;
    [activityIndicatorView setActivityIndicatorViewStyle: UIActivityIndicatorViewStyleWhiteLarge] ;
    activityIndicatorView.color=[UIColor grayColor];
    [self.view addSubview : activityIndicatorView] ;
    self.web_view.scalesPageToFit =YES;
    self.web_view.delegate =self;
}
#pragma --mark  webView
// 如果返回NO，代表不允许加载这个请求
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
    return YES;
}
//开始加载的时候执行该方法。
- (void)webViewDidStartLoad:(UIWebView *)webView
{
    [activityIndicatorView startAnimating] ;
    [self.view bringSubviewToFront:activityIndicatorView];
    
}
//加载完成的时候执行该方法。
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [activityIndicatorView stopAnimating] ;
    [activityIndicatorView removeFromSuperview];
}
//加载出错的时候执行该方法。
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    
    [buttonleft removeFromSuperview];
    [self dismissViewControllerAnimated:YES
                             completion:^{
                              
                             }];
    [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"加载出错"];
}
#pragma --mark  connection
//接收到服务器回应的时候调用此方法

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response

{
    NSHTTPURLResponse *res = (NSHTTPURLResponse *)response;
    
    NSLog(@"%@",[res allHeaderFields]);
    
    
}

//接收到服务器传输数据的时候调用，此方法根据数据大小执行若干次

-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data

{
    NSLog(@"data:%@",data);
}

//数据传完之后调用此方法

-(void)connectionDidFinishLoading:(NSURLConnection *)connection

{
    
}

//网络请求过程中，出现任何错误（断网，连接超时等）会进入此方法

-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error

{
    
    NSLog(@"%@",[error localizedDescription]);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
