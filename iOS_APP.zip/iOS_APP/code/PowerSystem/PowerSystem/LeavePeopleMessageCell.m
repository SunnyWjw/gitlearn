//
//  LeavePeopleMessageCell.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/18.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "LeavePeopleMessageCell.h"
#import "imageViewCell.h"
#import "LeavePeopleCellFrame.h"
#import "LeavePeopleCellModel.h"
#import "UIImage+ResizeImage.h"
#import "UIImageView+MJWebCache.h"
#import "MJPhoto.h"
#import "MJPhotoBrowser.h"
@interface LeavePeopleMessageCell(){

    UILabel *_timeLabel;
    UIImageView *_iconView;
    UILabel *_nameLabel;
    UILabel *_connectLabel;
    UICollectionView *_CollectionView;
    
    UIImageView *_backImage;
}
@end
static NSString * const CollreuseIdentifier = @"Cell";
@implementation LeavePeopleMessageCell
@synthesize imagesArray,CellImagesArray,imagesURLArray;
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.backgroundView = nil;
        self.backgroundColor = [UIColor clearColor];
        imagesArray=[NSArray new];
        CellImagesArray=[NSMutableArray new];
        imagesURLArray=[NSMutableArray new];
        _timeLabel = [[UILabel alloc] init];
        _timeLabel.textAlignment = NSTextAlignmentCenter;
        _timeLabel.textColor = [UIColor grayColor];
        //_timeLabel.alpha=0.4;
        _timeLabel.font = [UIFont systemFontOfSize:14];
       // _timeLabel.backgroundColor=[UIColor whiteColor];
        [self.contentView addSubview:_timeLabel];
    
        _iconView = [[UIImageView alloc] init];
        [self.contentView addSubview:_iconView];
    
        _nameLabel = [[UILabel alloc] init];
        _nameLabel.textAlignment = NSTextAlignmentCenter;
        _nameLabel.textColor = [UIColor grayColor];
        _nameLabel.font = [UIFont systemFontOfSize:15];
        [self.contentView addSubview:_nameLabel];
        
        _backImage = [[UIImageView alloc] init];
        _backImage.userInteractionEnabled=YES;
        //_backImage.backgroundColor=[UIColor grayColor];
        [self.contentView addSubview:_backImage];
        
        _connectLabel = [[UILabel alloc] init];
        _connectLabel.font = [UIFont systemFontOfSize:17];
        _connectLabel.textAlignment = NSTextAlignmentLeft;
        _connectLabel.numberOfLines=0;
        _connectLabel.lineBreakMode = NSLineBreakByWordWrapping;
        [_backImage addSubview:_connectLabel];
        
        UICollectionViewFlowLayout *flowlayout=[[UICollectionViewFlowLayout alloc]init];
        _CollectionView=[[UICollectionView alloc]initWithFrame:CGRectMake(0, 0, 0, 0) collectionViewLayout:flowlayout];
        _CollectionView.delegate=self;
        _CollectionView.dataSource=self;
        _CollectionView.tag=101;
        _CollectionView.backgroundColor=[UIColor clearColor];
        [_CollectionView registerClass:[imageViewCell class] forCellWithReuseIdentifier:CollreuseIdentifier];
        [_backImage addSubview:_CollectionView];
        
    }
    return self;
}

- (void)setCellFrame:(LeavePeopleCellFrame *)cellFrame{
    _cellFrame=cellFrame;
    LeavePeopleCellModel *message=cellFrame.message;
    _timeLabel.frame=_cellFrame.timeFrame;
    _timeLabel.text=message.time;
    
    _iconView.frame=_cellFrame.iconFrame;
    _iconView.layer.masksToBounds=YES;
    _iconView.layer.cornerRadius=_iconView.bounds.size.width*0.5;
    _iconView.layer.borderWidth=2.0;
    _iconView.layer.borderColor=[UIColor whiteColor].CGColor;
    NSString *iconStr = message.is_self ? @"defaultHeader":@"defaultHeader";
    _iconView.image = [UIImage imageNamed:iconStr];
    
    _nameLabel.frame=_cellFrame.nameFrame;
    _nameLabel.text=message.user_name;

    _backImage.frame=_cellFrame.backImageFrame;
    NSString *textBg = message.is_self ? @"bubbleSelf":@"bubble" ;
    UIImage *backimage=[UIImage imageNamed:textBg];
    _backImage.image=[backimage stretchableImageWithLeftCapWidth:20 topCapHeight:14];
    
    _connectLabel.frame=_cellFrame.textFrame;
    _connectLabel.text=message.content;
    
    _CollectionView.frame=_cellFrame.collectionFrame;
    imagesArray=message.image_list;
    [_CollectionView reloadData];
    
}

#pragma mark <UICollectionViewDataSource>
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}
//item个数
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return [imagesArray count];
}
// The view that is returned must be retrieved from a call to -dequeueReusableSupplementaryViewOfKind:withReuseIdentifier:forIndexPath:
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section
{
    return CGSizeMake(0, 0);
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    
    if ([imagesArray count]==4||[imagesArray count]==2) {
        return CGSizeMake((collectionView.frame.size.width-2)/2, (collectionView.frame.size.width-2)/2);
    }
    else if ([imagesArray count]==1){
        return CGSizeMake((collectionView.frame.size.width), (collectionView.frame.size.height));
    }
    return CGSizeMake((collectionView.frame.size.width-4)/3, (collectionView.frame.size.width-4)/3);
    
    
}
//定义每个UICollectionView 的 margin
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(0, 0, 0, 0);
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{
    
    return 1.0;
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return 1;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    UIImage *placeholder = [UIImage imageNamed:@"timeline_image_loading.png"];
    imageViewCell *cell = (imageViewCell*)[collectionView dequeueReusableCellWithReuseIdentifier:CollreuseIdentifier forIndexPath:indexPath];
    cell.imageView.backgroundColor=[UIColor grayColor];
    NSDictionary *dict=[imagesArray objectAtIndex:indexPath.row];
    NSString *imagePath=[NSString stringWithFormat:@"http://%@/%@",IPAddress,[dict objectForKey:@"raw"]];
    [imagesURLArray addObject:imagePath];
    [cell.imageView setImageURLStr:imagePath placeholder:placeholder];
    [CellImagesArray addObject:cell.imageView];
    return cell;
}
//选择了某个cell
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    NSMutableArray *photos = [NSMutableArray arrayWithCapacity:[imagesURLArray count]];
    for (int i = 0; i<[imagesURLArray count]; i++) {
        // 替换为中等尺寸图片
        NSString *url = [imagesURLArray[i] stringByReplacingOccurrencesOfString:@"thumbnail" withString:@"bmiddle"];
        MJPhoto *photo = [[MJPhoto alloc] init];
        photo.url = [NSURL URLWithString:url]; // 图片路径
        photo.srcImageView = [CellImagesArray objectAtIndex:indexPath.row]; // 来源于哪个UIImageView
        [photos addObject:photo];
    }
    // 2.显示相册
    MJPhotoBrowser *browser = [[MJPhotoBrowser alloc] init:nil];
    browser.currentPhotoIndex = indexPath.row; // 弹出相册时显示的第一张图片是？
    browser.photos = photos; // 设置所有的图片
    [browser show];
}
//取消选择了某个cell
- (void)collectionView:(UICollectionView *)collectionView didDeselectItemAtIndexPath:(NSIndexPath *)indexPath
{
    
}
-(BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    //不可点
    return YES;
}


@end
