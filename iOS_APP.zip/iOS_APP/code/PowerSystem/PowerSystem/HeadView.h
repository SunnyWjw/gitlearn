//
//  HeadView.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/18.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <UIKit/UIKit.h>
@class LeaveGroup;

@protocol HeadViewDelegate <NSObject>

@optional
- (void)clickHeadView;
@end

@interface HeadView : UITableViewHeaderFooterView

@property (nonatomic, strong)NSString *nameName;

@property (nonatomic,strong)LeaveGroup *leaveGroup;

@property (nonatomic, weak) id<HeadViewDelegate> delegate;
+ (instancetype)headViewWithTableView:(UITableView *)tableView;

@end
