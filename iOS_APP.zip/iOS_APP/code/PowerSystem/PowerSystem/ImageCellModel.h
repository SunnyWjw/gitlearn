//
//  ImageCellModel.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/15.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ImageCellModel : NSObject
@property(nonatomic,copy)NSNumber *id;
@property(nonatomic,copy)NSString *name;
@property(nonatomic,copy)NSNumber *size;
@property(nonatomic,copy)NSString *path;
@property(nonatomic,copy)NSString *date;
@end
