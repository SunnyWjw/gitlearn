//
//  PlanManagerModel.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/11.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PlanManagerModel : NSObject
@property(nonatomic,copy)NSString *value;
@property(nonatomic,copy)NSString *text;
@end
