//
//  SearchWebController.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/18.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "SearchWebController.h"

@interface SearchWebController (){
    UIActivityIndicatorView *activityIndicatorView;
    SearchFileModel *model;
}

@end

@implementation SearchWebController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self viewForWebView];
}
-(void)getWebUrl:(NSString *)url model:(SearchFileModel *)fileModel{

    model=fileModel;
}

-(void)viewForWebView{
    activityIndicatorView = [[UIActivityIndicatorView alloc]
                             initWithFrame : CGRectMake((kScreenW-32)/2, (kScreenH-32)/2, 32.0f, 32.0f)] ;
    [activityIndicatorView setCenter: self.view.center] ;
    [activityIndicatorView setActivityIndicatorViewStyle: UIActivityIndicatorViewStyleWhite] ;
    [self.view addSubview : activityIndicatorView] ;
    self.web_view.scalesPageToFit =YES;
    self.web_view.delegate =self;
    
    if ([[DataFormatterSingle shareCore] retrieveFileData:nil Name:model.name]) {
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *docDir = [paths objectAtIndex:0];
        NSString *filePath = [docDir stringByAppendingPathComponent:model.name];
        NSURL *url = [NSURL fileURLWithPath:filePath];
        NSURLRequest *request = [NSURLRequest requestWithURL:url];
        [self.web_view loadRequest:request];
    }
    else
    {
        NSString *str=[NSString stringWithFormat:@"http://%@/%@",IPAddress,model.path];
        NSString *strurl=[str stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSURL *url=[NSURL URLWithString:strurl];
        [self.web_view loadRequest:[NSURLRequest requestWithURL:url]];
    }
}
#pragma --mark  webView
// 如果返回NO，代表不允许加载这个请求
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
    return YES;
}
//开始加载的时候执行该方法。
- (void)webViewDidStartLoad:(UIWebView *)webView
{
    [activityIndicatorView startAnimating] ;
}
//加载完成的时候执行该方法。
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [activityIndicatorView stopAnimating] ;
}
//加载出错的时候执行该方法。
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"提示" message:@"网络错误或文件类型不支持!" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
    [alert show];
}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
