//
//  MMCTableViewController.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/14.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "MMCTableViewController.h"
#import "AFNetworking.h"
#import "MMControllerModel.h"
#import "MMCTableListController.h"
@interface MMCTableViewController ()

@end

@implementation MMCTableViewController
@synthesize MMCTableArray;
- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView setTableFooterView:[[UIView alloc] initWithFrame:CGRectZero]];
    self.navigationItem.title=@"多媒体管理";
    //dispatch_async(dispatch_get_global_queue(0, 0), ^{
        [self getMMCData];
    //});

}

-(void)getMMCData{
    NSString *str= [NSString stringWithFormat:@"http://%@/Mobile/MediaTypeList",IPAddress];
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:str parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"--%@",[operation responseString]);
        NSNumber *status=[responseObject objectForKey:@"status"];
        if ([status intValue]==1){
            MMCTableArray =[NSMutableArray new];
            NSArray *arrays=[responseObject objectForKey:@"data"];
            for(NSDictionary *dic in arrays){
                MMControllerModel *MMCModel=[[MMControllerModel alloc]init];
                [MMCModel setValuesForKeysWithDictionary:dic];
                [MMCTableArray addObject:MMCModel];
            }
            [self.tableView reloadData];
            
        }else{
            [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:[responseObject objectForKey:@"info"]];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"error*___%@",[error localizedDescription]);
        [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"网络错误"];
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    // Return the number of rows in the section.
    NSInteger a=[MMCTableArray count];
    return a;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellId=@"LineCell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    MMControllerModel *MMC=[MMCTableArray objectAtIndex:indexPath.row];
    cell.textLabel.text=MMC.text;
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    UIStoryboard *sb=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    MMCTableListController *view=(MMCTableListController *)[sb instantiateViewControllerWithIdentifier:@"MMCTableList"];
    [view getindex:(int)indexPath.row];
    [self.navigationController pushViewController:view animated:YES];
}

@end
