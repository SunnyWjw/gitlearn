//
//  WainingTableViewController.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/20.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "WainingTableViewController.h"
#import "WainingModel.h"
#import "WainingConnectController.h"
@interface WainingTableViewController ()
{

}
@end

@implementation WainingTableViewController
@synthesize array;
- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView setTableFooterView:[[UIView alloc] initWithFrame:CGRectZero]];
    self.navigationItem.title=@"提醒警告";
    
    __weak WainingTableViewController *wain = self;
    _blockWainingReloadData=^(){
       // dispatch_async(dispatch_get_global_queue(0, 0), ^{
            [wain getWainingData];
       // });
    };
    //dispatch_async(dispatch_get_global_queue(0, 0), ^{
        [self getWainingData];
    //});
    
    
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
}

-(void)getWainingData{
    NSString *str=[NSString stringWithFormat:@"http://%@/Mobile/AlertTypeCount",IPAddress];
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    NSDictionary *parameter=@{@"token":[[DataFormatterSingle shareCore]getInfoToken]};
    [manager GET:str parameters:parameter success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"--%@",[operation responseString]);
        NSNumber *status=[responseObject objectForKey:@"status"];
        if ([status intValue]==1){
            array=[NSMutableArray new];
            NSArray *arrays=[responseObject objectForKey:@"data"];
            for(NSDictionary *dic in arrays){
                WainingModel *model=[[WainingModel alloc]init];
                [model setValuesForKeysWithDictionary:dic];
                [array addObject:model];
            }
            [self.tableView reloadData];
        }
        else{
            [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:[responseObject objectForKey:@"info"]];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"error*___%@",[error localizedDescription]);
        [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"网络错误"];
    }];

}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    // Return the number of rows in the section.
    return [array count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellId=@"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    WainingModel *Model=[array objectAtIndex:indexPath.row];
    cell.textLabel.text=Model.text;
    
    
    
    UILabel *notiNumLabel=[[UILabel alloc]init];
    UIView *notiNumberView=[[UIView alloc]init];
    notiNumLabel.frame= CGRectMake(0, 0, 26, 26);
    notiNumberView.frame= CGRectMake(tableView.frame.size.width-50, 7, 26, 26);
    [notiNumLabel setTextAlignment:NSTextAlignmentCenter];
    notiNumberView.layer.cornerRadius=notiNumberView.bounds.size.width*0.5;
    notiNumberView.layer.borderWidth=2.0;
    notiNumberView.layer.borderColor=[UIColor whiteColor].CGColor;
    notiNumLabel.textColor=[UIColor whiteColor];
    notiNumLabel.text=[NSString stringWithFormat:@"%d",[Model.count intValue]];
    [notiNumberView addSubview:notiNumLabel];
    if (indexPath.row==3) {
        notiNumberView.backgroundColor=[UIColor blueColor];
    }
    else if (indexPath.row==2)
    {
        notiNumberView.backgroundColor=RGBColorAlpha(254, 67, 101, 0.8);
    }
    else if (indexPath.row==1)
    {
        notiNumberView.backgroundColor=[UIColor redColor];
    }
    else
    {
        notiNumberView.backgroundColor=[UIColor blackColor];
    }

    [cell.contentView addSubview:notiNumberView];
    
    if ([Model.count intValue]>0) {
        
        notiNumberView.hidden=NO;
    }
    else
    {
        while ([cell.contentView.subviews lastObject] != nil) {
            [(UIView*)[cell.contentView.subviews lastObject] removeFromSuperview];
        }
        notiNumberView.hidden=YES;
    }
    
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    WainingModel *model=[array objectAtIndex:indexPath.row];
    UIStoryboard *sb=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    WainingConnectController *view=(WainingConnectController *)[sb instantiateViewControllerWithIdentifier:@"WainingConnect"];
    [view getWainingModel:model block:_blockWainingReloadData];
    [self.navigationController pushViewController:view animated:YES];
}
//定义header
//- (UIView *) tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
//
//}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 40;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
