//
//  ReplayLeaveMessageController.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/19.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LeaveMessageModel.h"
@interface ReplayLeaveMessageController : UIViewController<UITextViewDelegate,UIGestureRecognizerDelegate,UIActionSheetDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate>

@property (weak, nonatomic) IBOutlet UITextView *textView;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (nonatomic,copy) void(^cellDeleteImageBlock)(UIImage *image);
@property (nonatomic,copy) void(^PeopleMessageReloadDataBlock)();

-(void)getLeaveMessageModel:(LeaveMessageModel *)model block:(void(^)())peopleMessageBlock;
@end
