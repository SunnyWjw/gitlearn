//
//  LineDetailTableCell.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/11.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//
#define DATEFONT [UIFont fontWithName:@"Arial" size:12]
#define FONT [UIFont fontWithName:@"Arial" size:15]
#define TITLEFONT [UIFont fontWithName:@"Arial" size:17]

#import "LineDetailTableCell.h"
#import "AFNetworking.h"
@implementation LineDetailTableCell
@synthesize cellDataBlock,cellDateNumBlock,cellDateOkNumberBlock;
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier block:(void(^)())BLOCK twoBlock:(void(^)(int num))blocks{
    self=[super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        cellDataBlock=BLOCK;
        cellDateNumBlock=blocks;
        
        _backImage=[[UIImageView alloc]init];
        UITapGestureRecognizer *backImagepan = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(backImagehandlePanFrom:)];
        backImagepan.numberOfTapsRequired = 1;
        backImagepan.delegate = self;
        _backImage.userInteractionEnabled=YES;
        [_backImage addGestureRecognizer:backImagepan];
        [self.contentView addSubview:_backImage];
        
        _projectTitle=[[UILabel alloc]init];
        _projectTitle.font=TITLEFONT;
        [self.contentView addSubview:_projectTitle];
        
        
        _start_date=[[UILabel alloc]init];
        _start_date.font=DATEFONT;
        [self.contentView addSubview:_start_date];
        
        
        _fengefu=[[UILabel alloc]init];
        _fengefu.font=DATEFONT;
        [self.contentView addSubview:_fengefu];
        
        
        _end_date=[[UILabel alloc]init];
        _end_date.font=DATEFONT;
        [self.contentView addSubview:_end_date];
        
        _line=[[UILabel alloc]init];
        
        [self.contentView addSubview:_line];
        
        _circleImageView=[[UIImageView alloc]init];
        UITapGestureRecognizer *panRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(circlehandlePanFrom:)];
        panRecognizer.numberOfTapsRequired = 1;
        panRecognizer.delegate = self;
        [_circleImageView addGestureRecognizer:panRecognizer];
        [self.contentView addSubview:_circleImageView];
        
        _responNameLabel=[[UILabel alloc]init];
        _responNameLabel.font=FONT;
        [self.contentView addSubview:_responNameLabel];
        
        _dateLabel=[[UILabel alloc]init];
        _dateLabel.font=FONT;
        [self.contentView addSubview:_dateLabel];
        
        _complete_std=[[UILabel alloc]init];
        _complete_std.numberOfLines=0;
        _complete_std.font=FONT;
        [self.contentView addSubview:_complete_std];
    }
    return self;
}

- (void)backImagehandlePanFrom:(UITapGestureRecognizer *)recognizer{
    
    //if (![cellFrame.weibo.complete_date length]) {
    __weak LineDetailTableCell *cell=self;
    
    cellDateOkNumberBlock=^(int number){
        [cell cellWithNum:number];
    };
    
    
    ServerView=[[ChildSexView alloc]initWithBlock:nil Type:CHildSexViewTimeOkView];
    [ServerView getTimeOkViewModel:cellFrame block:cellDateOkNumberBlock];
//    }
//    else{
//        [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"此节点已确认"];
//    }
    
}
-(void)cellWithNum:(int)daysNum{
    
    cellDateNumBlock(daysNum);
}
- (void)circlehandlePanFrom:(UITapGestureRecognizer *)recognizer{
    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"警告" message:@"确认此节点已完成?" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    [alert show];
   }
- (LineDetailTableCell *)cellWithInformWeiboFrames:(LineDetailCellFrame *)weiboFrames{
    
    cellFrame=weiboFrames;
    
    _projectTitle.text=weiboFrames.weibo.projectTitleString;
    _start_date.text=weiboFrames.weibo.start_dateString;
    _fengefu.text=@"~";
    _end_date.text=weiboFrames.weibo.end_dateString;
    _line.backgroundColor=[UIColor grayColor];
    _responNameLabel.text=weiboFrames.weibo.responNameLabelString;
    NSString *str=[NSString stringWithFormat:@"%@天",weiboFrames.weibo.dateLabelString];
    _dateLabel.text=str;
    _complete_std.text=weiboFrames.weibo.complete_stdString;
    
    [self getCellFramesWithWeiboFrames:weiboFrames];
    return self;
}
-(void)getCellFramesWithWeiboFrames:(LineDetailCellFrame*)weiboFrames{
    _circleImageView.frame=weiboFrames.circleImageFrame;
    _circleImageView.layer.masksToBounds=YES;
    if (![weiboFrames.weibo.is_complete intValue]==1) {
        _backImage.image=[UIImage imageNamed:@"bubbleWhite"];
        _circleImageView.backgroundColor=[UIColor whiteColor];
        _circleImageView.layer.cornerRadius=_circleImageView.bounds.size.width*0.5;
        _circleImageView.layer.borderWidth=2.0;
        _circleImageView.layer.borderColor=[UIColor greenColor].CGColor;
        _circleImageView.userInteractionEnabled=YES;
    }else{
        _backImage.image=[UIImage imageNamed:@"bubbleBlue"];
        _circleImageView.backgroundColor=RGBColor(54, 149, 187);
        _circleImageView.layer.cornerRadius=_circleImageView.bounds.size.width*0.5;
        _circleImageView.layer.borderWidth=0;
        _circleImageView.userInteractionEnabled=NO;
    }
    _backImage.frame=weiboFrames.backImageFrame;
    _projectTitle.frame=weiboFrames.projectTitleFrame;
    _start_date.frame=weiboFrames.start_dateFrame;
    _fengefu.frame=weiboFrames.fengefuFrame;
    _end_date.frame=weiboFrames.end_dateFrame;
    
    _line.frame=weiboFrames.lineFrame;
    _responNameLabel.frame=weiboFrames.responNameLabelFrame;
    _dateLabel.frame=weiboFrames.dateLabelFrame;
    _complete_std.frame=weiboFrames.complete_stdFrame;
    
}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex) {
        case 0:
            
            break;
        case 1:
        {
            [self AlertClickSure];
        }
            break;
        default:
            break;
    }
}
//确认节点完成
-(void)AlertClickSure{
    NSString *str= [NSString stringWithFormat:@"http://%@/Mobile/ProjectNodeComplete",IPAddress];
    
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    NSDictionary *parameters=@{@"node_id":cellFrame.weibo.id,@"token":[[DataFormatterSingle shareCore]getInfoToken]};
    [manager GET:str parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"--%@",[operation responseString]);
        NSNumber *status=[responseObject objectForKey:@"status"];
        if ([status intValue]==1){
            cellDataBlock();
        }else{
            [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:[responseObject objectForKey:@"info"]];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"error*___%@",[error localizedDescription]);
        [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"网络错误"];
    }];

}
@end