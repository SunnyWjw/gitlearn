//
//  imageViewCell.m
//  JxbApp
//
//  Created by huhaifeng on 15/7/20.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "imageViewCell.h"

@implementation imageViewCell

- (void)awakeFromNib {
    // Initialization code
}
- (id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        NSArray *arr = [[NSBundle mainBundle] loadNibNamed:@"imageViewCell" owner:self options:nil];
        if (arr.count<1) {
            return nil;
        }
        if (![[arr objectAtIndex:0] isKindOfClass:[UICollectionViewCell class]]) {
            return nil;
        }
        self = [arr firstObject];
    }
    return self;
}
@end
