//
//  ChildSexView.m
//  JxbApp
//
//  Created by huhaifeng on 15/7/31.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "ChildSexView.h"
#import "Animations.h"
#import "DataFormatterSingle.h"

#import "UUDatePicker.h"
#define kAlertWidth 245.0f
#define kAlertHeight 160.0f

#define TIMEOKFONT  [UIFont systemFontOfSize:15.0]
#define TIMEOKVALUECOLOR [UIColor grayColor]
#define TIMEOKCOLOR [UIColor blackColor]
@interface ChildSexView(){
    UIView *head_view;
    UITableView *table_view;
    NSMutableArray *array;
    CGFloat keyboardOfset;
    CGFloat yOffset;
    
    UITextField *serverAddressTextField;
    UITextField *portTextField;
    
    UITextField *oldPasswordTextField;
    UITextField *newPasswordTextField;
    UITextField *againPasswordTextField;
    
    LineDetailCellFrame *cellFrame;
    UILabel *maxDateLabel;
    UILabel *startDateLabel;
    UILabel *endDateLabel;
    NSString *YYLabel;
    NSString *MMLabel;
    NSString *DDLabel;
    int DDnum;
    int MMnum;
    int YYnum;
    int maxValue;
    int ValueNow;
    UISlider *slider;
    
    UITextField *filed;
}
@end
static BOOL selectOK=NO;
@implementation ChildSexView
@synthesize statye,ServerBlock,cellDateNumBlock,cellDateOkNumberBlock;

-(instancetype)initWithBlock:(void(^)(NSString *str,NSString *two,NSString *three))block Type:(ChildSexViewState)type{
    CGFloat height=0;
    CGFloat width=0;
    CGFloat origX=0;
    statye=type;
    if (statye==ChildSexViewServer) {
        origX=40;
        height=150;
        width=kScreenW-80;
    }else if (statye==ChildSexViewEditPassword){
        origX=40;
        height=180;
        width=kScreenW-80;
    }else if (statye==ChildSexViewEditSlide){
        origX=15;
        height=150;
        width=kScreenW-30;
    }else if (CHildSexViewTimeOkView){
        origX=15;
        height=250;
        width=kScreenW-30;
        
    }
    self = [super initWithFrame:CGRectMake(origX, (kScreenH-height)/2, width, height)];
    if (self) {
        ServerBlock=block;
        switch (statye) {
            case ChildSexViewServer:
            {
                [self creatConfigServerView];
            }
                break;
            case ChildSexViewEditPassword:
            {
                [self creatEditPasswordView];
            }
                break;
             case ChildSexViewEditSlide:
            {
                [self createSlideView];
            }
                break;
            case CHildSexViewTimeOkView:
            {
                [self creatTimeOkView];
            }
                break;
            default:
                break;
        }
    }
    return self;
}

-(void)defaultView{
    UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
    UIImageView *dimView = [[UIImageView alloc] initWithFrame:keyWindow.bounds];
    dimView.image = [self backgroundGradientImageWithSize:keyWindow.bounds.size];
    dimView.userInteractionEnabled = YES;
    UITapGestureRecognizer *panRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handlePanFrom:)];
    [dimView addGestureRecognizer:panRecognizer];//关键语句，给self.view添加一个手势监测；
    panRecognizer.numberOfTapsRequired = 1;
    panRecognizer.delegate = self;
    [keyWindow addSubview:dimView];
    if (statye==ChildSexViewEditSlide||statye==CHildSexViewTimeOkView){
        self.backgroundColor=RGBColor(240, 240, 240);
    }else{
        self.backgroundColor=[UIColor blackColor];
    }
    self.userInteractionEnabled=YES;
    UITapGestureRecognizer *selfRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(selfhandlePanFrom:)];
    selfRecognizer.numberOfTapsRequired = 1;
    selfRecognizer.delegate = self;
    [self addGestureRecognizer:selfRecognizer];
    
    self.layer.masksToBounds=YES;
    self.layer.cornerRadius=10.0;
    [dimView addSubview:self];
    self.superview.alpha = 1;
    self.userInteractionEnabled=YES;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillChangeFrame:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardDidChangeFrame:) name:UIKeyboardWillHideNotification object:nil];
}
- (void)handlePanFrom:(UITapGestureRecognizer *)recognizer{
    [self dissshow];
}
- (void)selfhandlePanFrom:(UITapGestureRecognizer *)recognizer{
    //NSLog(@"self------is me");
}
-(void)creatEditPasswordView{
    [self defaultView];
    UILabel *oldpass=[[UILabel alloc]init];
    oldpass.frame=CGRectMake(2, 10, 68, 40);
    oldpass.textColor=[UIColor whiteColor];
    oldpass.textAlignment=NSTextAlignmentLeft;
    oldpass.text=@"原密码:";
    oldpass.font=[UIFont systemFontOfSize:14.0];
    [self addSubview:oldpass];
    
    oldPasswordTextField=[[UITextField alloc]init];
    oldPasswordTextField.backgroundColor=[UIColor whiteColor];
    oldPasswordTextField.frame=CGRectMake(CGRectGetMaxX(oldpass.frame)+5, oldpass.frame.origin.y+5, self.frame.size.width-CGRectGetMaxX(oldpass.frame)-10, 30);
    oldPasswordTextField.textAlignment=NSTextAlignmentLeft;
    oldPasswordTextField.textColor=[UIColor blackColor];
    oldPasswordTextField.delegate=self;
    oldPasswordTextField.secureTextEntry=YES;
    [self addSubview:oldPasswordTextField];
    
    UILabel *newpass=[[UILabel alloc]init];
    newpass.frame=CGRectMake(2, CGRectGetMaxY(oldpass.frame), 68, 40);
    newpass.textColor=[UIColor whiteColor];
    newpass.textAlignment=NSTextAlignmentLeft;
    newpass.text=@"新密码:";
    newpass.font=[UIFont systemFontOfSize:14.0];
    [self addSubview:newpass];
    
    newPasswordTextField=[[UITextField alloc]init];
    newPasswordTextField.backgroundColor=[UIColor whiteColor];
    newPasswordTextField.frame=CGRectMake(CGRectGetMaxX(newpass.frame)+5, newpass.frame.origin.y+5, self.frame.size.width-CGRectGetMaxX(newpass.frame)-10, 30);
    newPasswordTextField.textAlignment=NSTextAlignmentLeft;
    newPasswordTextField.textColor=[UIColor blackColor];
    newPasswordTextField.delegate=self;
    newPasswordTextField.secureTextEntry=YES;
    [self addSubview:newPasswordTextField];
    
    UILabel *againpass=[[UILabel alloc]init];
    againpass.frame=CGRectMake(2, CGRectGetMaxY(newpass.frame), 68, 40);
    againpass.textColor=[UIColor whiteColor];
    againpass.textAlignment=NSTextAlignmentLeft;
    againpass.text=@"确认密码:";
    againpass.font=[UIFont systemFontOfSize:14.0];
    [self addSubview:againpass];
    
    againPasswordTextField=[[UITextField alloc]init];
    againPasswordTextField.backgroundColor=[UIColor whiteColor];
    againPasswordTextField.frame=CGRectMake(CGRectGetMaxX(againpass.frame)+5, againpass.frame.origin.y+5, self.frame.size.width-CGRectGetMaxX(againpass.frame)-10, 30);
    againPasswordTextField.textAlignment=NSTextAlignmentLeft;
    againPasswordTextField.textColor=[UIColor blackColor];
    againPasswordTextField.delegate=self;
    againPasswordTextField.secureTextEntry=YES;
    [self addSubview:againPasswordTextField];
    
    UIButton *upButton=[[UIButton alloc]init];
    upButton.frame=CGRectMake(0, self.frame.size.height-30, self.frame.size.width, 30);
    [upButton setTitle:@"提交" forState:UIControlStateNormal];
    [upButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    upButton.userInteractionEnabled=YES;
    [upButton addTarget:self action:@selector(editButtonClick) forControlEvents:UIControlEventTouchUpInside];
    upButton.backgroundColor=STATICBACKCOLOR;
    [self addSubview:upButton];
}
-(void)editButtonClick{
    
    [oldPasswordTextField resignFirstResponder];
    [newPasswordTextField resignFirstResponder];
    [againPasswordTextField resignFirstResponder];
    
    if (![oldPasswordTextField.text length]||![newPasswordTextField.text length]||![againPasswordTextField.text length]) {
        [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"密码输入不能为空!"];
        return;
    }
    NSString *oldPass=[[DataFormatterSingle shareCore]getInfoPassword];
    if (![oldPasswordTextField.text isEqualToString:oldPass]) {
        [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"旧密码输入错误!"];
        return;
    }
    if (![newPasswordTextField.text isEqualToString:againPasswordTextField.text]) {
        [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"新密码输入不一致!"];
        return;
    }
    
    ServerBlock(oldPasswordTextField.text,newPasswordTextField.text,againPasswordTextField.text);
    [self dissshow];
}
-(void)creatConfigServerView{
    [self defaultView];
    UILabel *titleLabel=[[UILabel alloc]init];
    titleLabel.frame=CGRectMake(0, 0, self.frame.size.width, 30);
    titleLabel.textColor=[UIColor whiteColor];
    titleLabel.textAlignment=NSTextAlignmentCenter;
    titleLabel.text=@"电网项目工程进度管控终端";
    [self addSubview:titleLabel];
    
    UILabel *serverAddressLabel=[[UILabel alloc]init];
    serverAddressLabel.frame=CGRectMake(2, CGRectGetMaxY(titleLabel.frame), 70, 40);
    serverAddressLabel.textColor=[UIColor whiteColor];
    serverAddressLabel.textAlignment=NSTextAlignmentLeft;
    serverAddressLabel.text=@"服务器地址";
    serverAddressLabel.font=[UIFont systemFontOfSize:14.0];
    [self addSubview:serverAddressLabel];
    
    serverAddressTextField=[[UITextField alloc]init];
    serverAddressTextField.backgroundColor=[UIColor whiteColor];
    serverAddressTextField.frame=CGRectMake(CGRectGetMaxX(serverAddressLabel.frame)+5, serverAddressLabel.frame.origin.y+5, self.frame.size.width-CGRectGetMaxX(serverAddressLabel.frame)-10, 30);
    serverAddressTextField.textAlignment=NSTextAlignmentCenter;
    serverAddressTextField.textColor=[UIColor blackColor];
    serverAddressTextField.delegate=self;
    if (![[[DataFormatterSingle shareCore]getInfoServeString] length]) {
        serverAddressTextField.text=@"192.168.1.159";
    }else{
        serverAddressTextField.text=[[DataFormatterSingle shareCore]getInfoServeString];
    }
    
    //serverAddressTextField.keyboardType=UIKeyboardTypeNumberPad;
    [serverAddressTextField becomeFirstResponder];
    [self addSubview:serverAddressTextField];
    
    UILabel *portLabel=[[UILabel alloc]init];
    portLabel.frame=CGRectMake(2, CGRectGetMaxY(serverAddressLabel.frame), 68, 40);
    portLabel.textColor=[UIColor whiteColor];
    portLabel.textAlignment=NSTextAlignmentLeft;
    portLabel.text=@"端口号";
    portLabel.font=[UIFont systemFontOfSize:14.0];
    [self addSubview:portLabel];
    
    portTextField=[[UITextField alloc]init];
    portTextField.backgroundColor=[UIColor whiteColor];
    portTextField.frame=CGRectMake(CGRectGetMaxX(portLabel.frame)+5, portLabel.frame.origin.y+5, 60, 30);
    portTextField.textAlignment=NSTextAlignmentCenter;
    portTextField.textColor=[UIColor blackColor];
    portTextField.delegate=self;
    if (![[[DataFormatterSingle shareCore]getInfoPortString] length]) {
        portTextField.text=@"827";
    }else{
        portTextField.text=[[DataFormatterSingle shareCore]getInfoPortString];
    }
    //portTextField.keyboardType=UIKeyboardTypeNumberPad;
    [self addSubview:portTextField];
    
    UIButton *upButton=[[UIButton alloc]init];
    upButton.frame=CGRectMake(0, self.frame.size.height-30, self.frame.size.width, 30);
    [upButton setTitle:@"提交" forState:UIControlStateNormal];
    [upButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    upButton.userInteractionEnabled=YES;
    [upButton addTarget:self action:@selector(upButtonClick) forControlEvents:UIControlEventTouchUpInside];
    upButton.backgroundColor=STATICBACKCOLOR;
    [self addSubview:upButton];
    
}
-(void)upButtonClick{
    [[DataFormatterSingle shareCore]ServeString:serverAddressTextField.text];
    [[DataFormatterSingle shareCore]PortString:portTextField.text];
    NSString *str=[serverAddressTextField.text stringByAppendingString:@":"];
    NSString *serverStr=[str stringByAppendingString:portTextField.text];
    ServerBlock(serverStr,nil,nil);
    [self dissshow];
}

-(void)createSlideView{
    [self defaultView];
    UILabel *titleLabel=[[UILabel alloc]init];
    titleLabel.frame=CGRectMake((self.frame.size.width-140)/2, 0, 140, 30);
    titleLabel.text=@"初步设计工时压缩";
    [self addSubview:titleLabel];
    
    UILabel *line=[[UILabel alloc]init];
    line.frame=CGRectMake(0, CGRectGetMaxY(titleLabel.frame), self.frame.size.width, 2);
    line.backgroundColor=[UIColor blackColor];
    [self addSubview:line];
    
    startDateLabel=[[UILabel alloc]init];
    startDateLabel.frame=CGRectMake(5, CGRectGetMaxY(line.frame)+10, 68, 21);
    
    startDateLabel.textColor=[UIColor grayColor];
    startDateLabel.font=[UIFont systemFontOfSize:12.0];
    [self addSubview:startDateLabel];
    
    maxDateLabel=[[UILabel alloc]init];
    maxDateLabel.frame=CGRectMake((self.frame.size.width-98)/2, CGRectGetMaxY(line.frame)+15, 98, 21);
    maxDateLabel.text=@"0天";
    maxDateLabel.hidden=YES;
    maxDateLabel.textColor=[UIColor grayColor];
    maxDateLabel.font=[UIFont systemFontOfSize:12.0];
    [self addSubview:maxDateLabel];
    
    endDateLabel=[[UILabel alloc]init];
    endDateLabel.frame=CGRectMake(self.frame.size.width-68-5, CGRectGetMaxY(line.frame)+10, 68, 21);
    endDateLabel.textColor=[UIColor grayColor];
    endDateLabel.font=[UIFont systemFontOfSize:12.0];
    [self addSubview:endDateLabel];
    
    slider=[[UISlider alloc]initWithFrame:CGRectMake(5, CGRectGetMaxY(endDateLabel.frame)+10,self.frame.size.width-10, 25)];
    //slider.tag=100;
    UIImage *stetchLeftTrack = [[UIImage imageNamed:@"slideMax.png"] stretchableImageWithLeftCapWidth:0 topCapHeight:0.0];
    UIImage *stetchRightTrack = [[UIImage imageNamed:@"slideMin.png"] stretchableImageWithLeftCapWidth:0 topCapHeight:0.0];
    [slider setMinimumTrackImage:stetchLeftTrack forState:UIControlStateNormal];
    [slider setMaximumTrackImage:stetchRightTrack forState:UIControlStateNormal];
    
    [slider setThumbImage:[UIImage imageNamed:@"slider_on"] forState:UIControlStateHighlighted];
    [slider setThumbImage:[UIImage imageNamed:@"slider_off"] forState:UIControlStateNormal];
    //slider.continuous = YES ;
    [slider addTarget:self action:@selector(sliderValueChanged:) forControlEvents:UIControlEventValueChanged];
    [self addSubview:slider];
    
    UIButton *SlideViewLeftButton=[[UIButton alloc]init];
    SlideViewLeftButton.layer.masksToBounds=YES;
    SlideViewLeftButton.frame=CGRectMake(-2, self.frame.size.height-40, self.frame.size.width/2+2, 42);
    [SlideViewLeftButton setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    [SlideViewLeftButton setTitleColor:[UIColor blackColor] forState:UIControlStateHighlighted];
    SlideViewLeftButton.layer.borderWidth=1.0;
    SlideViewLeftButton.layer.borderColor=[UIColor blackColor].CGColor;
    [SlideViewLeftButton setTitle:@"确定" forState:UIControlStateNormal];
    [SlideViewLeftButton addTarget:self action:@selector(SliderViewLeftClick) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:SlideViewLeftButton];
    
    UIButton *SlideViewRightButton=[[UIButton alloc]init];
    SlideViewRightButton.layer.masksToBounds=YES;
    SlideViewRightButton.frame=CGRectMake(self.frame.size.width/2, self.frame.size.height-40, self.frame.size.width/2+2, 42);
    [SlideViewRightButton setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    [SlideViewRightButton setTitleColor:[UIColor blackColor] forState:UIControlStateHighlighted];
    
    SlideViewRightButton.layer.borderWidth=1.0;
    SlideViewRightButton.layer.borderColor=[UIColor blackColor].CGColor;
    [SlideViewRightButton setTitle:@"取消" forState:UIControlStateNormal];
    [SlideViewRightButton addTarget:self action:@selector(SliderViewRightClick) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:SlideViewRightButton];
}
-(int) compressDaysValue{
    int days=0;
    NSDate *dateA = [[DataFormatterSingle shareCore]dateWithStrings:cellFrame.weibo.end_dateString];
    NSDate *dateB = [[DataFormatterSingle shareCore]dateWithStrings:cellFrame.weibo.start_dateString];
    days=[[DataFormatterSingle shareCore]timeInterval:dateA olddata:dateB];
    if ([cellFrame.weibo.projectTitleString isEqualToString:@"初设内审"]||
        [cellFrame.weibo.projectTitleString isEqualToString:@"土建主体结构施工"]||
        [cellFrame.weibo.projectTitleString isEqualToString:@"电气安装"]||
        [cellFrame.weibo.projectTitleString isEqualToString:@"电气调试"]
        )
    {
        if ([cellFrame.weibo.projectTitleString isEqualToString:@"初设内审"]){
            days-=20;
        }
        else if ([cellFrame.weibo.projectTitleString isEqualToString:@"土建主体结构施工"]){
            days-=45;
        }
        else if ([cellFrame.weibo.projectTitleString isEqualToString:@"电气安装"]){
            days-=50;
        }
        else {
            days-=20;
        }
    }
    else if ([cellFrame.weibo.projectTitleString isEqualToString:@"土建扫尾施工"])
    {
        days-=45;
    }
    else if ([cellFrame.weibo.projectTitleString isEqualToString:@"初步设计"])
    {
        days-=40;
    }
    else{
        days=0;
    }
    
    return days;
}
- (void) sliderValueChanged:(id)sender{
    //UISlider* control = (UISlider*)sender;
    int slideValue=slider.value;
    int slideMaxValue=slider.maximumValue;
//    if (slideValue == slideMaxValue) {
//        return;
//    }
    NSUInteger index = (NSUInteger)(slider.value + 0.5);
    [slider setValue:index animated:NO];
    
    int days=[self compressDaysValue];
    if (slideValue<(slideMaxValue-days)) {
        slider.value=slideMaxValue-days;
        maxDateLabel.hidden=NO;
        maxDateLabel.text=[NSString stringWithFormat:@"最多可以压缩%d天",days];
    }
    else{
        maxDateLabel.hidden=YES;
        [self getEndDateLabelText:slider];
    }
}
-(void) SliderViewLeftClick{
    
    NSDate *dateA = [[DataFormatterSingle shareCore]dateWithStrings:cellFrame.weibo.end_dateString];
    NSDate *dateB = [[DataFormatterSingle shareCore]dateWithStrings:endDateLabel.text];
    int days=[[DataFormatterSingle shareCore]timeInterval:dateA olddata:dateB];

    cellDateNumBlock(days);
    [self dissshow];
}

-(void) SliderViewRightClick{

    [self dissshow];
}
-(void) getEndDateLabelText :(UISlider *)control{
    int yasuotian= maxValue-slider.value;
    NSLog(@"DDnum:%d  yasuotian:%d  ",DDnum,yasuotian);
    if (MMnum==1||
        MMnum==3||
        MMnum==5||
        MMnum==7||
        MMnum==8||
        MMnum==10||
        MMnum==12)
    {
        //NSLog(@"DDnum:%d  yasuotian:%d  ",DDnum,yasuotian);
        if ((DDnum-yasuotian<1)) {
                //前推一个月
            [self qiantuiMM];
        }
        else if(DDnum-yasuotian>31){
            [self houtuiMM];
        }
        else{
            DDLabel=[NSString stringWithFormat:@"%d",DDnum-yasuotian];
        }
    }
    else if (MMnum==2)
    {
        if (YYnum%4==0)
        {
            if ((DDnum-yasuotian<1)) {
                [self qiantuiMM];
            }
            else if(DDnum-yasuotian>29){
                [self houtuiMM];
            }
            else{
                DDLabel=[NSString stringWithFormat:@"%d",DDnum-yasuotian];
            }

        }
        else
        {
            if ((DDnum-yasuotian<1)) {
                [self qiantuiMM];
            }
            else if(DDnum-yasuotian>28){
                [self houtuiMM];
            }
            else{
                DDLabel=[NSString stringWithFormat:@"%d",DDnum-yasuotian];
            }

        }
    }
    else
    {
        //NSLog(@"DDnum:%d  yasuotian:%d  ",DDnum,yasuotian);
        if ((DDnum-yasuotian<1))
        {
            [self qiantuiMM];
        }
        else if(DDnum-yasuotian>30)
        {
            [self houtuiMM];
    
        }
        else
        {
             DDLabel=[NSString stringWithFormat:@"%d",DDnum-yasuotian];
        }
    }

    MMLabel=[NSString stringWithFormat:@"%d",MMnum];
    YYLabel=[NSString stringWithFormat:@"%d",YYnum];
    
    if ([DDLabel intValue]<10) {
        DDLabel=[NSString stringWithFormat:@"0%@",DDLabel];
    }
    if ([MMLabel intValue]<10) {
        MMLabel=[NSString stringWithFormat:@"0%@",MMLabel];
    }
    
    endDateLabel.text=[NSString stringWithFormat:@"%@-%@-%@",YYLabel,MMLabel,DDLabel];

    if ([MMLabel hasPrefix:@"0"]&&[MMLabel length]>1) {
        MMLabel=[MMLabel substringWithRange:NSMakeRange(1, 1)];
    }
    if ([DDLabel hasPrefix:@"0"]&&[DDLabel length]>1) {
        DDLabel=[DDLabel substringWithRange:NSMakeRange(1, 1)];
    }
    
}
NSString *YY;
NSString *MM;
NSString *DD;
BOOL sliNowStatus;
int zhuanbianzhi=0;
//前推一个月
-(void)qiantuiMM{
    MMnum-=1;
    if (MMnum>12) {
        MMnum=1;
        YYnum+=1;
    }
    else if(MMnum<1)
    {
        MMnum=12;
        YYnum-=1;
    }
    MMLabel=[NSString stringWithFormat:@"%d",MMnum];
    if ([MMLabel isEqualToString:@"1"]||
        [MMLabel isEqualToString:@"3"]||
        [MMLabel isEqualToString:@"5"]||
        [MMLabel isEqualToString:@"7"]||
        [MMLabel isEqualToString:@"8"]||
        [MMLabel isEqualToString:@"10"]||
        [MMLabel isEqualToString:@"12"])
    {
        DDLabel=[NSString stringWithFormat:@"%d",31];
        DDnum+=31;
        ValueNow=31;
    }
    else if ([MMLabel isEqualToString:@"2"])
    {
        int runnian=0;
        if (YYnum%4==0) {
            runnian=29;
        }
        else
        {
            runnian=28;
        }
        DDLabel=[NSString stringWithFormat:@"%d",runnian];
        DDnum+=runnian;
        ValueNow=runnian;
    }
    else
    {
        DDLabel=[NSString stringWithFormat:@"%d",30];
        DDnum+=30;
        ValueNow=30;
    }

}

-(void)houtuiMM{
    MMnum+=1;
    if (MMnum>12) {
        MMnum=1;
        YYnum+=1;
    }
    else if(MMnum<1)
    {
        MMnum=12;
        YYnum-=1;
    }
    MMLabel=[NSString stringWithFormat:@"%d",MMnum];
    
    DDLabel=[NSString stringWithFormat:@"%d",1];
    DDnum-=ValueNow;
    
}
-(void)getSliderViewModel:(LineDetailCellFrame *)frame block:(void(^)(int num))dateBlock{
    cellFrame=frame;
    cellDateNumBlock=dateBlock;
    
    ValueNow=0;
    sliNowStatus=YES;
    startDateLabel.text=cellFrame.weibo.start_dateString;
    endDateLabel.text=cellFrame.weibo.end_dateString;
    //UISlider *slide=(UISlider *)[self viewWithTag:100];
    YY=[[DataFormatterSingle shareCore]dateformatterYY:cellFrame.weibo.end_dateString];
    MM=[[DataFormatterSingle shareCore]dateformatterMM:cellFrame.weibo.end_dateString];
    DD=[[DataFormatterSingle shareCore]dateformatterDD:cellFrame.weibo.end_dateString];
    DDnum=[DD intValue];
    MMnum=[MM intValue];
    YYnum=[YY intValue];
    NSLog(@"----DDnum:%d,MMnum:%d,YYnum:%d",DDnum,MMnum,YYnum);
    slider.minimumValue = 0.0;
    slider.maximumValue = [cellFrame.weibo.dateLabelString intValue];
    slider.value=slider.maximumValue;
    maxValue=slider.maximumValue;
}
-(void)getTimeOkViewModel:(LineDetailCellFrame *)frames block:(void(^)(int num))dateBlock{
    cellFrame=frames;
    cellDateOkNumberBlock=dateBlock;
    CGFloat allHeight=21.0;
    UILabel *IDLabel=[[UILabel alloc]init];
    IDLabel.frame=CGRectMake(2, 2, 20, allHeight);
    IDLabel.text=@"ID";
    IDLabel.textColor=TIMEOKCOLOR;
    IDLabel.font=TIMEOKFONT;
    [self addSubview:IDLabel];
    
    UILabel *IDValueLabel=[[UILabel alloc]init];
    IDValueLabel.frame=CGRectMake(CGRectGetMaxX(IDLabel.frame)+5, IDLabel.frame.origin.y, self.frame.size.width-CGRectGetMaxX(IDLabel.frame)-5-2, allHeight);
    IDValueLabel.text=[NSString stringWithFormat:@"%@",cellFrame.weibo.id];
    IDValueLabel.textColor=TIMEOKVALUECOLOR;
    IDValueLabel.font=TIMEOKFONT;
    [self addSubview:IDValueLabel];
    
    UILabel *important_point=[[UILabel alloc]init];
    important_point.frame=CGRectMake(2, CGRectGetMaxY(IDLabel.frame), 90, allHeight);
    important_point.text=@"关键路线事项";
    important_point.textColor=TIMEOKCOLOR;
    important_point.font=TIMEOKFONT;
    [self addSubview:important_point];
    
    UILabel *important_value=[[UILabel alloc]init];
    important_value.frame=CGRectMake(CGRectGetMaxX(important_point.frame)+5, important_point.frame.origin.y, self.frame.size.width-CGRectGetMaxX(important_point.frame)-5-2, allHeight);
    important_value.text=cellFrame.weibo.projectTitleString;
    important_value.textColor=TIMEOKVALUECOLOR;
    important_value.font=TIMEOKFONT;
    [self addSubview:important_value];
    
    UILabel *cycleLabel=[[UILabel alloc]init];
    cycleLabel.frame=CGRectMake(2, CGRectGetMaxY(important_point.frame), 70, allHeight);
    cycleLabel.text=@"周期(天数)";
    cycleLabel.textColor=TIMEOKCOLOR;
    cycleLabel.font=TIMEOKFONT;
    [self addSubview:cycleLabel];
    
    UILabel *cycleValueLabel=[[UILabel alloc]init];
    cycleValueLabel.frame=CGRectMake(CGRectGetMaxX(cycleLabel.frame)+5, cycleLabel.frame.origin.y, self.frame.size.width-CGRectGetMaxX(cycleLabel.frame)-5-2, allHeight);
    cycleValueLabel.text=cellFrame.weibo.dateLabelString;
    cycleValueLabel.textColor=TIMEOKVALUECOLOR;
    cycleValueLabel.font=TIMEOKFONT;
    [self addSubview:cycleValueLabel];
    
    UILabel *startData=[[UILabel alloc]init];
    startData.frame=CGRectMake(2, CGRectGetMaxY(cycleLabel.frame), 90, allHeight);
    startData.text=@"计划开始日期";
    startData.textColor=TIMEOKCOLOR;
    startData.font=TIMEOKFONT;
    [self addSubview:startData];
    
    UILabel *startValueData=[[UILabel alloc]init];
    startValueData.frame=CGRectMake(CGRectGetMaxX(startData.frame)+5, startData.frame.origin.y, self.frame.size.width-CGRectGetMaxX(startData.frame)-5-2, allHeight);
    startValueData.text=cellFrame.weibo.start_dateString;
    startValueData.textColor=TIMEOKVALUECOLOR;
    startValueData.font=TIMEOKFONT;
    [self addSubview:startValueData];
    
    UILabel *startOkData=[[UILabel alloc]init];
    startOkData.frame=CGRectMake(2, CGRectGetMaxY(startData.frame), 90, allHeight);
    startOkData.text=@"计划完成日期";
    startOkData.textColor=TIMEOKCOLOR;
    startOkData.font=TIMEOKFONT;
    [self addSubview:startOkData];
    
    UILabel *startOkValueData=[[UILabel alloc]init];
    startOkValueData.frame=CGRectMake(CGRectGetMaxX(startOkData.frame)+5, startOkData.frame.origin.y, self.frame.size.width-CGRectGetMaxX(startOkData.frame)-5-2, allHeight);
    startOkValueData.text=cellFrame.weibo.end_dateString;
    startOkValueData.textColor=TIMEOKVALUECOLOR;
    startOkValueData.font=TIMEOKFONT;
    [self addSubview:startOkValueData];
    
    UILabel *shiJiOkValue=[[UILabel alloc]init];
    shiJiOkValue.frame=CGRectMake(2, CGRectGetMaxY(startOkValueData.frame), 90, allHeight);
    shiJiOkValue.text=@"实际完成日期";
    shiJiOkValue.textColor=TIMEOKCOLOR;
    shiJiOkValue.font=TIMEOKFONT;
    [self addSubview:shiJiOkValue];
    
    UILabel *shiJiOkValueData=[[UILabel alloc]init];
    shiJiOkValueData.frame=CGRectMake(CGRectGetMaxX(shiJiOkValue.frame)+5, shiJiOkValue.frame.origin.y, self.frame.size.width-CGRectGetMaxX(shiJiOkValue.frame)-5-2, allHeight);
    shiJiOkValueData.text=cellFrame.weibo.complete_date;
    shiJiOkValueData.textColor=TIMEOKVALUECOLOR;
    shiJiOkValueData.font=TIMEOKFONT;
    [self addSubview:shiJiOkValueData];
    
    UILabel *completeStand=[[UILabel alloc]init];
    completeStand.frame=CGRectMake(2, CGRectGetMaxY(shiJiOkValueData.frame), 60, allHeight);
    completeStand.text=@"完成标准";
    completeStand.textColor=TIMEOKCOLOR;
    completeStand.font=TIMEOKFONT;
    [self addSubview:completeStand];
    
    UILabel *completeStandValue=[[UILabel alloc]init];
    completeStandValue.frame=CGRectMake(CGRectGetMaxX(completeStand.frame)+5, completeStand.frame.origin.y, self.frame.size.width-CGRectGetMaxX(completeStand.frame)-5-2, 21);
    completeStandValue.text=cellFrame.weibo.complete_stdString;
    completeStandValue.textColor=TIMEOKVALUECOLOR;
    completeStandValue.font=TIMEOKFONT;
    [self addSubview:completeStandValue];
    
    UILabel *responsible_name=[[UILabel alloc]init];
    responsible_name.frame=CGRectMake(2, CGRectGetMaxY(completeStandValue.frame), 75, allHeight);
    responsible_name.text=@"负责人姓名";
    responsible_name.textColor=TIMEOKCOLOR;
    responsible_name.font=TIMEOKFONT;
    [self addSubview:responsible_name];
    
    UILabel *responsible_nameValue=[[UILabel alloc]init];
    responsible_nameValue.frame=CGRectMake(CGRectGetMaxX(responsible_name.frame)+5, responsible_name.frame.origin.y, self.frame.size.width-CGRectGetMaxX(responsible_name.frame)-5-2, allHeight);
    responsible_nameValue.text=cellFrame.weibo.responNameLabelString;
    responsible_nameValue.textColor=TIMEOKVALUECOLOR;
    responsible_nameValue.font=TIMEOKFONT;
    [self addSubview:responsible_nameValue];
    
    UILabel *remind=[[UILabel alloc]init];
    remind.frame=CGRectMake(2, CGRectGetMaxY(responsible_nameValue.frame), 60, allHeight);
    remind.text=@"提醒工作";
    remind.textColor=TIMEOKCOLOR;
    remind.font=TIMEOKFONT;
    [self addSubview:remind];
    
    UILabel *remindValue=[[UILabel alloc]init];
    remindValue.frame=CGRectMake(CGRectGetMaxX(remind.frame)+5, remind.frame.origin.y, self.frame.size.width-CGRectGetMaxX(remind.frame)-5-2, allHeight);
    remindValue.text=[NSString stringWithFormat:@"%@",cellFrame.weibo.remind];
    remindValue.textColor=TIMEOKVALUECOLOR;
    remindValue.font=TIMEOKFONT;
    [self addSubview:remindValue];
    
    UILabel *returnTime=[[UILabel alloc]init];
    returnTime.frame=CGRectMake(2, CGRectGetMaxY(remindValue.frame)+2, 60, allHeight);
    returnTime.text=@"确认时间";
    returnTime.textColor=TIMEOKCOLOR;
    returnTime.font=TIMEOKFONT;
    [self addSubview:returnTime];
    
    //选择时间
    
    UIButton *SlideViewLeftButton=[[UIButton alloc]init];
    SlideViewLeftButton.layer.masksToBounds=YES;
    SlideViewLeftButton.frame=CGRectMake(-2, self.frame.size.height-30, self.frame.size.width/2+2, 32);
    [SlideViewLeftButton setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    [SlideViewLeftButton setTitleColor:[UIColor blackColor] forState:UIControlStateHighlighted];
    SlideViewLeftButton.layer.borderWidth=1.0;
    SlideViewLeftButton.layer.borderColor=[UIColor blackColor].CGColor;
    [SlideViewLeftButton setTitle:@"确定" forState:UIControlStateNormal];
    [SlideViewLeftButton addTarget:self action:@selector(TimeOkLeftClick) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:SlideViewLeftButton];
    
    UIButton *SlideViewRightButton=[[UIButton alloc]init];
    SlideViewRightButton.layer.masksToBounds=YES;
    SlideViewRightButton.frame=CGRectMake(self.frame.size.width/2, self.frame.size.height-30, self.frame.size.width/2+2, 32);
    [SlideViewRightButton setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    [SlideViewRightButton setTitleColor:[UIColor blackColor] forState:UIControlStateHighlighted];
    
    SlideViewRightButton.layer.borderWidth=1.0;
    SlideViewRightButton.layer.borderColor=[UIColor blackColor].CGColor;
    [SlideViewRightButton setTitle:@"取消" forState:UIControlStateNormal];
    [SlideViewRightButton addTarget:self action:@selector(TimeOkRightClick) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:SlideViewRightButton];
    filed=[[UITextField alloc]init];
    
    filed.frame=CGRectMake(CGRectGetMaxX(returnTime.frame)+5, returnTime.frame.origin.y-2, 200, allHeight+4);
    NSDate *now = [NSDate date];
    NSLog(@"now date is: %@", now);
   
   NSCalendar *calendar = [NSCalendar currentCalendar];
   NSUInteger unitFlags = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit;
   NSDateComponents *dateComponent = [calendar components:unitFlags fromDate:now];
    NSString *dateMonth;
    NSString *dateDay;
    if ([dateComponent day]<10) {
        dateDay=[NSString stringWithFormat:@"0%ld",(long)[dateComponent day]];
    }else{
        dateDay=[NSString stringWithFormat:@"%ld",(long)[dateComponent day]];
    }
    if ([dateComponent month]<10) {
        dateMonth=[NSString stringWithFormat:@"0%ld",(long)[dateComponent month]];
    }else{
        dateDay=[NSString stringWithFormat:@"%ld",(long)[dateComponent day]];
    }
    if (![cellFrame.weibo.complete_date length]) {
        filed.borderStyle=UITextBorderStyleRoundedRect;
        filed.backgroundColor=[UIColor whiteColor];
        [filed setTextColor:[UIColor blackColor]];
        filed.userInteractionEnabled=YES;
        filed.text=[NSString stringWithFormat:@"%ld-%@-%@",(long)[dateComponent year],dateMonth,dateDay];
    }else{
        filed.borderStyle=UITextBorderStyleNone;
        [filed setTextColor:[UIColor grayColor]];
        filed.backgroundColor=[UIColor clearColor];
        filed.userInteractionEnabled=NO;
        filed.text=cellFrame.weibo.complete_date;
    }
    
    [self addSubview:filed];
    UUDatePicker *datePicker = [[UUDatePicker alloc]initWithframe:CGRectMake(0, 0, kScreenW, 216)
                             PickerStyle:1
                             didSelected:^(NSString *year,
                                           NSString *month,
                                           NSString *day,
                                           NSString *hour,
                                           NSString *minute,
                                           NSString *weekDay) {
                                 

                                         filed.text = [NSString stringWithFormat:@"%@-%@-%@",year,month,day];
                                 
                             }];
    filed.inputView=datePicker;
}
-(void)TimeOkLeftClick{
    
    if (![cellFrame.weibo.complete_date length])
    {
        if ([cellFrame.weibo.is_complete intValue]==1){
            //可确认时间
            [self timeIsCompare];
        }
        else
        {
            [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"请先确认该节点完成"];
            [self endEditing:YES];
            return;
        }
        
    }
    
    [self endEditing:YES];
    [self dissshow];
}
-(void)timeIsCompare{
    //NSComparisonResult result = [dateA compare:dateB];
    
    NSDate *dateA = [[DataFormatterSingle shareCore]dateWithStrings:filed.text];
    NSDate *dateB = [[DataFormatterSingle shareCore]dateWithStrings:cellFrame.weibo.start_dateString];
    NSDate *dateC = [[DataFormatterSingle shareCore]dateWithStrings:cellFrame.weibo.end_dateString];
    int ABdays=[[DataFormatterSingle shareCore]timeInterval:dateA olddata:dateB];
    int ACdays=[[DataFormatterSingle shareCore]timeInterval:dateA olddata:dateC];
    if (ABdays>0)
    {
        if (ACdays>75) {
            [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"超过计划完成时间太多"];
        }
        else
        {
            cellDateOkNumberBlock(ACdays);
        }
    }
    else
    {
        [self endEditing:YES];
        [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"确认时间小于计划时间"];
        return;
    }

}

-(void)TimeOkRightClick{
    [self endEditing:YES];
    [self dissshow];
}
//hide keyboard
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [super touchesBegan:touches withEvent:event];
    [self endEditing:YES];
}
-(void)creatTimeOkView{
    [self defaultView];
}

- (UIImage *)backgroundGradientImageWithSize:(CGSize)size
{
    CGPoint center = CGPointMake(size.width * 0.5, size.height * 0.5);
    CGFloat innerRadius = 0;
    CGFloat outerRadius = sqrtf(size.width * size.width + size.height * size.height) * 0.5;
    
    BOOL opaque = NO;
    UIGraphicsBeginImageContextWithOptions(size, opaque, [[UIScreen mainScreen] scale]);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    const size_t locationCount = 2;
    CGFloat locations[locationCount] = { 0.0, 1.0 };
    CGFloat components[locationCount * 4] = {
        0.0, 0.0, 0.0, 0.1, // More transparent black
        0.0, 0.0, 0.0, 0.7  // More opaque black
    };
    
    CGColorSpaceRef colorspace = CGColorSpaceCreateDeviceRGB();
    CGGradientRef gradient = CGGradientCreateWithColorComponents(colorspace, components, locations, locationCount);
    
    CGContextDrawRadialGradient(context, gradient, center, innerRadius, center, outerRadius, 0);
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    CGColorSpaceRelease(colorspace);
    CGGradientRelease(gradient);
    
    return image;
}
//- (void)layoutSubviews {
//    [super layoutSubviews];
//    table_view=[[UITableView alloc]initWithFrame:fr];
//    table_view.delegate=self;
//    table_view.dataSource=self;
//    array =[NSMutableArray new];
//    array =[NSMutableArray arrayWithObjects:@"男",@"女",nil];
//    head_view=[[UIView alloc]initWithFrame:CGRectMake(0, 0, table_view.frame.size.width, 40)];
//    UILabel *label=[[UILabel alloc]initWithFrame:CGRectMake((table_view.frame.size.width-40)/2, 5, 40, 30)];
//    label.text=@"性别";
//    [head_view addSubview:label];
//    table_view.tableHeaderView=head_view;
//    table_view.scrollEnabled=NO;
//    CGRect newBounds = CGRectMake(fr.origin.x, fr.origin.y, fr.size.width, fr.size.height);
//    self.bounds = newBounds;
//    self.layer.cornerRadius=8;
//    table_view.layer.cornerRadius=8;
//    [self addSubview:table_view];
//    NSLog(@"----size-%@",NSStringFromCGRect(self.frame));
//}
#pragma mark - UITextfield delegate

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
- (void)keyboardDidChangeFrame:(NSNotification *)notification{
    NSDictionary *info = [notification userInfo];
    CGFloat duration = [[info objectForKey:UIKeyboardAnimationDurationUserInfoKey] floatValue];
    CGRect inputFieldRect = self.frame;
    CGRect moreBtnRect = self.frame;
    [UIView animateWithDuration:duration animations:^{
        self.frame = inputFieldRect;
        self.frame = moreBtnRect;
    }];
}
- (void)keyboardWillChangeFrame:(NSNotification *)notification
{
    NSDictionary *info = [notification userInfo];
    CGFloat duration = [[info objectForKey:UIKeyboardAnimationDurationUserInfoKey] floatValue];
//    CGRect beginKeyboardRect = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue];
    CGRect endKeyboardRect = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue];

    CGFloat endY=endKeyboardRect.origin.y-self.frame.size.height;
//    yOffset = endKeyboardRect.origin.y - beginKeyboardRect.origin.y;
//    keyboardOfset=kScreenH- CGRectGetMaxY(self.frame);
//    yOffset+=keyboardOfset;
    CGRect inputFieldRect = self.frame;
//    CGRect moreBtnRect = self.frame;
//    
    inputFieldRect.origin.y = endY;
//    moreBtnRect.origin.y += yOffset;
    [UIView animateWithDuration:duration animations:^{
        self.frame = inputFieldRect;
//        self.frame = moreBtnRect;
        NSLog(@"--endKeyboardRectframe--%@:",NSStringFromCGRect(endKeyboardRect));
        NSLog(@"--\n-self.frame--%@:",NSStringFromCGRect(self.frame));
    }];
    
}
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
//    CGRect frame = textField.frame;
//    int offset = frame.origin.y + Move_Height - (self.frame.size.height - 216.0);//键盘高度216
//    NSTimeInterval animationDuration = 0.30f;
//    [UIView beginAnimations:@"ResizeForKeyBoard" context:nil];
//    [UIView setAnimationDuration:animationDuration];
//    float width = self.frame.size.width;
//    float height = self.frame.size.height;
//    if(offset > 0)
//    {
//        CGRect rect = CGRectMake(0.0f, -offset,width,height);
//        self.frame = rect;
//        
//    }
//    [UIView commitAnimations];
    
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)strin
{
    NSString * toBeString = [textField.text stringByReplacingCharactersInRange:range withString:strin];
    if ([toBeString length] > 30) {
        return NO;
    }
    return YES;
}


#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    // Return the number of sections.
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 5;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return [array count];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    return 40;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellId=@"CellIdentfier";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (cell==nil) {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    if (indexPath.row==0) {
        if (selectOK) {
            cell.accessoryType=UITableViewCellAccessoryCheckmark;
        }else{
            cell.accessoryType=UITableViewCellSelectionStyleNone;
        }
    }else{
        if (selectOK) {
            cell.accessoryType=UITableViewCellSelectionStyleNone;
        }else{
            cell.accessoryType=UITableViewCellAccessoryCheckmark;
        }
    }
    cell.textLabel.text=[array objectAtIndex:indexPath.row];
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self dissshow];
}
-(void)show:(int)man IDControl:(id)Id{
    if (man==0) {
        selectOK=YES;
        //男
    }else{
        selectOK=NO;
    }
    UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
    UIImageView *dimView = [[UIImageView alloc] initWithFrame:keyWindow.bounds];
    dimView.image = [self backgroundGradientImageWithSize:keyWindow.bounds.size];
    dimView.userInteractionEnabled = YES;
    [keyWindow addSubview:dimView];
    [dimView addSubview:self];
    self.superview.alpha = 1;
    
    [Animations zoomIn:self andAnimationDuration:0.25 andWait:YES];
    [table_view reloadData];
//    [UIView animateWithDuration:0.4
//                          delay:0.0
//                        options:UIViewAnimationOptionCurveEaseInOut
//                     animations:^
//     {
//         self.superview.alpha = 1;
//         
//     }
//                     completion:nil];
}
-(void)dissshow{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [UIView animateWithDuration:0.25
                          delay:0.0
                        options:UIViewAnimationOptionCurveEaseInOut
                     animations:^
     {
         self.superview.alpha = 0;
     }
                     completion:^(BOOL finished) {
                         [self.superview removeFromSuperview];
                         [self removeFromSuperview];
                     }];

}
- (UIViewController *)appRootViewController
{
    UIViewController *appRootVC = [UIApplication sharedApplication].keyWindow.rootViewController;
    UIViewController *topVC = appRootVC;
    while (topVC.presentedViewController) {
        topVC = topVC.presentedViewController;
    }
    return topVC;
}

@end
