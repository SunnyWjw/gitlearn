//
//  FileDataTableController.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/17.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "FileDataTableController.h"
#import "AFNetworking.h"
#import "PlanManagerModel.h"
#import "SearchTableController.h"
@interface FileDataTableController ()

@end

@implementation FileDataTableController
@synthesize array;

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView setTableFooterView:[[UIView alloc] initWithFrame:CGRectZero]];
    self.navigationItem.title=@"资源列表";
    //dispatch_async(dispatch_get_global_queue(0, 0), ^{
        [self getFileData];
   // });
    
}
-(void)getFileData{
    NSString *str=[NSString stringWithFormat:@"http://%@/Mobile/FileTypeList",IPAddress];
        AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
        [manager GET:str parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSLog(@"--%@",[operation responseString]);
            NSNumber *status=[responseObject objectForKey:@"status"];
            if ([status intValue]==1){
                array=[NSMutableArray new];
                
                NSArray *arrays=[responseObject objectForKey:@"data"];
                for(NSDictionary *dic in arrays){
                    PlanManagerModel *model=[[PlanManagerModel alloc]init];
                    [model setValuesForKeysWithDictionary:dic];
                    [array addObject:model];
                }
                [self.tableView reloadData];
            }
            else{
                [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:[responseObject objectForKey:@"info"]];
            }
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            NSLog(@"error*___%@",[error localizedDescription]);
            [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"网络错误"];
        }];
}




#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    // Return the number of rows in the section.
    return 2;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellId=@"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    PlanManagerModel *planModel=[array objectAtIndex:indexPath.row];
    cell.textLabel.text=planModel.text;
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    PlanManagerModel *plan=[array objectAtIndex:indexPath.row];
    UIStoryboard *sb=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    SearchTableController *view=(SearchTableController *)[sb instantiateViewControllerWithIdentifier:@"SearchTable"];
    [view getFileDataType:plan];
    [self.navigationController pushViewController:view animated:NO];
}
//定义header
//- (UIView *) tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
//
//}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 40;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
