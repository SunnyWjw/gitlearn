//
//  LineProjectTableController.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/11.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "MJRefreshFooter.h"
#import "LineProjectTableController.h"
#import "LineProjectTableCell.h"
#import "AFNetworking.h"
#import "LineProjectModel.h"
#import "LineDetailController.h"
#import "ListTableWebController.h"
@interface LineProjectTableController (){
    PlanManagerModel *PlanModel;
    int page;
    BOOL ListTable;

}

@end
@implementation LineProjectTableController
@synthesize LineMutableArray;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    page=0;
    self.navigationItem.title=@"工程列表";
    [self.tableView setTableFooterView:[[UIView alloc] initWithFrame:CGRectZero]];
    
//    __weak UITableView *tableView = self.tableView;
//    // 下拉刷新
//    tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
//        //刷新数据
//        [self getProjectData];
//        // 模拟延迟加载数据，因此2秒后才调用（真实开发中，可以移除这段gcd代码）
//        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//            // 结束刷新
//            [tableView.header endRefreshing];
//            [self.tableView reloadData];
//        });
//    }];
    
    //dispatch_async(dispatch_get_global_queue(0, 0), ^{
        [self getProjectData];
   // });
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];

}
-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
}
-(void)getPeopleToken:(PlanManagerModel *)lineModel listbool:(BOOL)listTable report:(BOOL)startReport report:(BOOL)endReport{
    PlanModel=lineModel;
    ListTable=listTable;

}

-(void)getProjectData{
    //page ++;
    NSString *str= [NSString stringWithFormat:@"http://%@/Mobile/ProjectList?proj_type=%@&token=%@",IPAddress,PlanModel.value,[[DataFormatterSingle shareCore] getInfoToken]];
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:str parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"--%@",[operation responseString]);
        NSNumber *status=[responseObject objectForKey:@"status"];
        if ([status intValue]==1){
            LineMutableArray =[NSMutableArray new];
            NSArray *arrays=[responseObject objectForKey:@"data"];
            for(NSDictionary *dic in arrays){
                LineProjectModel *lineModel=[[LineProjectModel alloc]init];
                [lineModel setValuesForKeysWithDictionary:dic];
                [LineMutableArray addObject:lineModel];
            }
            [self.tableView reloadData];
        }else{
            [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:[responseObject objectForKey:@"info"]];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"error*___%@",[error localizedDescription]);
        [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"网络错误"];
    }];
}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    // Return the number of rows in the section.
    NSInteger a=[LineMutableArray count];
    return a;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellId=@"LineCell";
    
    LineProjectTableCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (cell == nil) {
        cell = [[LineProjectTableCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    LineProjectModel *lineModel=[LineMutableArray objectAtIndex:indexPath.row];
    
    cell.projectImage.image=[UIImage imageNamed:@"folder"];
    cell.projectName.text=lineModel.name;
    cell.projectPeople.text=lineModel.responsible_name;
    cell.startDate.text=lineModel.start_date;
    cell.endDate.text=lineModel.end_date;
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    LineProjectModel *lineModel=[LineMutableArray objectAtIndex:indexPath.row];
    UIStoryboard *sb=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    if (ListTable) {
        ListTableWebController *view=(ListTableWebController *)[sb instantiateViewControllerWithIdentifier:@"ListTableWeb"];
        [view getProjectId:lineModel];
        [self.navigationController presentViewController:view animated:NO completion:^{
        }];
    }
    else
    {
        LineDetailController *view=(LineDetailController *)[sb instantiateViewControllerWithIdentifier:@"LineDetail"];
        [view getProjectId:lineModel];
        [self.navigationController pushViewController:view animated:YES];
    }
    
}
//定义header
//- (UIView *) tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
//
//}

//- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
//    return 0;
//}
//- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    return 75;
//}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
