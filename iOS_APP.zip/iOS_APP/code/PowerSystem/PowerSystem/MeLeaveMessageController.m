//
//  MeLeaveMessageController.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/19.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "MeLeaveMessageController.h"
#import "LeaveGroup.h"
#import "LeaveMessageModel.h"
#import "LeaveMessageController.h"
#import "LeavePeopleMessageController.h"
#import "HeadView.h"
@interface MeLeaveMessageController ()<HeadViewDelegate>
{
    NSString *today;
    NSDate *date;
    NSDate *oldDate;
}
@end

@implementation MeLeaveMessageController
@synthesize ModelArrays,headNames,todayArrays,oneWeekArrays,oldOneWeekArrays;
- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView setTableFooterView:[[UIView alloc]initWithFrame:CGRectZero]];
    
    self.navigationItem.title=@"我的留言";
    headNames=[NSMutableArray new];
    date=[NSDate date];
    oldDate = [NSDate dateWithTimeIntervalSinceNow:-(25*60*60)];
    today=[[DataFormatterSingle shareCore]dateFormStrings:date ];
    headNames=@[@"最近一天",@"一周内",@"一周前"];
    
    ModelArrays=[NSMutableArray new];
    //dispatch_async(dispatch_get_global_queue(0, 0), ^{
        [self getMeLeaveMessageData];
    //});
}

-(void)getMeLeaveMessageData{
    NSString *str=[NSString stringWithFormat:@"http://%@/Mobile/MessageList",IPAddress];
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    NSNumber* meIdNum=@1;
//    NSNumber* num=@0;
//    NSNumber* number=@10;
//    NSDictionary *parameter=@{@"only_self":meIdNum,@"token":[[DataFormatterSingle shareCore] getInfoToken],@"page":num,@"page_size":number};
        NSDictionary *parameter=@{@"only_self":meIdNum,@"token":[[DataFormatterSingle shareCore] getInfoToken]};
    [manager GET:str parameters:parameter success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"--%@",[operation responseString]);
        NSNumber *status=[responseObject objectForKey:@"status"];
        if ([status intValue]==1){
            todayArrays=[NSMutableArray new];
            oneWeekArrays=[NSMutableArray new];
            oldOneWeekArrays=[NSMutableArray new];
            
            NSArray *arrays=[responseObject objectForKey:@"data"];
            NSDictionary *todaydic;
            NSDictionary *oneWeekdaydic;
            NSDictionary *oldOneWeekdaydic;
            for(NSDictionary *dic in arrays){
                
                //                LeaveMessageModel *model=[[LeaveMessageModel alloc]init];
                //                [model setValuesForKeysWithDictionary:dic];
                //                [ModelArrays addObject:model];
                NSString *dateTime=[dic objectForKey:@"time"];
                dateTime=[dateTime substringWithRange:NSMakeRange(0, 10)];
                
                NSDate *datedate=[[DataFormatterSingle shareCore]dateWithStrings:dateTime];
                
                int timedays=[[DataFormatterSingle shareCore]timeInterval:oldDate olddata:datedate];
                if ([today isEqualToString:dateTime]) {
                    
                    [todayArrays addObject:dic];
                }
                else
                {
                    if (timedays>7)
                    {
                        [oldOneWeekArrays addObject:dic];
                    }
                    else
                    {
                        [oneWeekArrays addObject:dic];
                    }
                }
            }
            todaydic=@{@"array":todayArrays};
            oneWeekdaydic=@{@"array":oneWeekArrays};
            oldOneWeekdaydic=@{@"array":oldOneWeekArrays};
            NSArray *arr=@[todaydic,oneWeekdaydic,oldOneWeekdaydic];
            NSMutableArray *fgArray = [NSMutableArray array];
            for(NSDictionary *diction in arr){
                LeaveGroup *leaveGroup=[LeaveGroup leaveGroupWithDict:diction];
                [fgArray addObject:leaveGroup];
            }
            ModelArrays=fgArray;
            [self.tableView reloadData];
        }
        else{
            [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:[responseObject objectForKey:@"info"]];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"error*___%@",[error localizedDescription]);
        [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"网络错误"];
    }];

}
#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    
    return [ModelArrays count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    // Return the number of rows in the section.
    LeaveGroup *leaveGroup = ModelArrays[section];
    NSInteger count = leaveGroup.isOpened ? leaveGroup.leaveArrays.count : 0;
    return count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellId=@"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellId];
    }
    LeaveGroup *leaveGroup = ModelArrays[indexPath.section];
    LeaveMessageModel *leaveModel=leaveGroup.leaveArrays[indexPath.row];
    cell.textLabel.text = leaveModel.title;
    cell.detailTextLabel.text = leaveModel.time;
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    LeaveGroup *leaveGroup = ModelArrays[indexPath.section];
    LeaveMessageModel *leaveModel=leaveGroup.leaveArrays[indexPath.row];
    UIStoryboard *sb=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    LeavePeopleMessageController *view=(LeavePeopleMessageController *)[sb instantiateViewControllerWithIdentifier:@"LeavePeopleMessage"];
    [view getMessageId:leaveModel];
    [self.navigationController pushViewController:view animated:NO];
}
//定义header
- (UIView *) tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    HeadView *headView = [HeadView headViewWithTableView:tableView];
    headView.nameName=[headNames objectAtIndex:section];
    headView.leaveGroup=ModelArrays[section];
    headView.delegate = self;
    return headView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 40;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}

- (void)clickHeadView
{
    [self.tableView reloadData];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
