//
//  LineDetailCellModel.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/12.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LineDetailCellModel : NSObject

@property(nonatomic,copy)NSNumber *id;
@property(nonatomic,copy)NSNumber *sort;
@property(nonatomic,copy)NSString *complete_date;
@property(nonatomic,copy)NSNumber *responsible;
@property(nonatomic,copy)NSNumber *remind;
@property(nonatomic,copy)NSString *confirm_date;

@property(nonatomic,copy)NSString *projectTitleString;
@property(nonatomic,copy)NSString *start_dateString;
@property(nonatomic,copy)NSString *end_dateString;
@property(nonatomic,copy)NSString *responNameLabelString;
@property(nonatomic,copy)NSString *dateLabelString;
@property(nonatomic,copy)NSString *complete_stdString;
@property(nonatomic,copy)NSNumber *is_complete;
+(LineDetailCellModel*)rewriteModel:(NSDictionary *)dict;
-(LineDetailCellModel*)initWithDict:(NSDictionary *)dict;
@end
