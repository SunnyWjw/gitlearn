//
//  PeopleMessageController.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/10.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "peopleMessageModel.h"
@interface PeopleMessageController : UIViewController<UITableViewDataSource,UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UITableView *table_view;
@property (nonatomic,strong )NSMutableArray *mutableArray;

@property (nonatomic,copy) void(^newPasswordBlock)(NSString *oldPasswordString,NSString *newPasswordString,NSString *againPasswordString);
-(void)getPeopleMessageModel:(peopleMessageModel *)model;
@end
