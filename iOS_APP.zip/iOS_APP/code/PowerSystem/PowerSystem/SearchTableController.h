//
//  SearchTableController.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/18.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PlanManagerModel.h"
@interface SearchTableController : UITableViewController<UIDocumentInteractionControllerDelegate,UIActionSheetDelegate>
@property (nonatomic,strong)NSMutableArray *array;
@property (nonatomic,strong)NSMutableArray *arrayName;
@property (nonatomic, strong) UIDocumentInteractionController *docInteractionController;

@property (nonatomic,copy)void(^cellButtonBlock)(UIButton *sender);

-(void)getFileDataType:(PlanManagerModel *)model;

- (void)downloadFileURL:(NSString *)aUrl savePath:(NSString *)aSavePath fileName:(NSString *)aFileName tag:(NSInteger)aTag pro:(UIProgressView *)proView;
@end
