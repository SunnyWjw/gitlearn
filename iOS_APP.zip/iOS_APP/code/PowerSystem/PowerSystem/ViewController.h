//
//  ViewController.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/10.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AFNetworking.h"
#import "peopleMessageModel.h"
@interface ViewController : UIViewController<UIGestureRecognizerDelegate>


@property (weak, nonatomic) IBOutlet UIButton *planManage;
@property (weak, nonatomic) IBOutlet UIButton *waining;
@property (weak, nonatomic) IBOutlet UIButton *mMC;
@property (weak, nonatomic) IBOutlet UIButton *leaveMessage;
@property (weak, nonatomic) IBOutlet UIButton *fileData;

@property (weak, nonatomic) IBOutlet UIButton *report;

-(void)getPeopleMessageModel:(peopleMessageModel*)model;
- (IBAction)planManagerClick:(id)sender;
- (IBAction)playMMClick:(id)sender;
- (IBAction)pushReportFormsController:(id)sender;
- (IBAction)LeaveMessageClick:(id)sender;
- (IBAction)pushFileDataClick:(id)sender;
- (IBAction)pushWainingClick:(id)sender;

-(void)abcde;
@end

