//
//  ReportFormsController.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/17.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "ReportFormsController.h"
#import "PlanManagerViewController.h"
#import "ListTableWebController.h"
@interface ReportFormsController ()

@end

@implementation ReportFormsController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationItem.title=@"报表类型";
}
- (IBAction)chartButtonClick:(id)sender {
    UIStoryboard *sb=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    PlanManagerViewController *view=(PlanManagerViewController *)[sb instantiateViewControllerWithIdentifier:@"PlanManager"];
    [view getTokenModel:YES report:NO reportend:NO];
    [self.navigationController pushViewController:view animated:NO];
}

- (IBAction)excelPlanClick:(id)sender {
    UIStoryboard *sb=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    ListTableWebController *view=(ListTableWebController *)[sb instantiateViewControllerWithIdentifier:@"ListTableWeb"];
    [view getExcelNumber:1];
    [self.navigationController presentViewController:view animated:NO completion:^{
        
    }];
}

- (IBAction)actualClick:(id)sender {
    UIStoryboard *sb=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    ListTableWebController *view=(ListTableWebController *)[sb instantiateViewControllerWithIdentifier:@"ListTableWeb"];
    [view getExcelNumber:2];
    [self.navigationController presentViewController:view animated:NO completion:^{
        
    }];
}









- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


@end
