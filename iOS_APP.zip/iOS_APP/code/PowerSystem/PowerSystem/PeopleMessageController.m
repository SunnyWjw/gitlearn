//
//  PeopleMessageController.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/10.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "PeopleMessageController.h"
#import "PeopleMessageCell.h"
#import "clickheaderMessageModel.h"
#import "AFNetworking.h"
#import "BottomView.h"
#import "ChildSexView.h"
@interface PeopleMessageController (){
    NSArray *array;
    peopleMessageModel *peopleMess;
    clickheaderMessageModel *clickMess;
    BottomView *bottView;
    ChildSexView *ServerView;
}

@end

@implementation PeopleMessageController
@synthesize table_view,mutableArray,newPasswordBlock;
- (void)viewDidLoad {
    [super viewDidLoad];
    table_view.delegate=self;
    table_view.dataSource=self;
    table_view.scrollEnabled=NO;
    array=@[@"姓名:",@"类型:",@"邮箱:",@"职位:"];
    //dispatch_async(dispatch_get_global_queue(0, 0), ^{
        [self getPeopleMessageData];
   // });
    [self bottomView];
    [self BlockEditPassword];
}
-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
}
-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [bottView removeFromSuperview];
}
-(void)BlockEditPassword{
    PeopleMessageController *peo=self;
    newPasswordBlock=^(NSString *oldPasswordString,NSString *newPasswordString,NSString *againPasswordString){
        [peo editPasswordData:oldPasswordString newpass:newPasswordString againpass:againPasswordString];
    };
}
-(void)bottomView{
    UIView *bottomView=[[UIView alloc]init];
    bottomView.frame=CGRectMake(0, kScreenH-40-64, kScreenW, 40);
    bottomView.backgroundColor=RGBColor(41, 166, 204);
    [self.view addSubview:bottomView];
    UIButton *leftbutton=[[UIButton alloc]init];
    leftbutton.frame=CGRectMake(5, 5, 68, 30);
    [leftbutton setTitle:@"密码" forState:UIControlStateNormal];
    [leftbutton setImage:[UIImage imageNamed:@"editPassword"] forState:UIControlStateNormal];
    [leftbutton addTarget:self action:@selector(editPasswords) forControlEvents:UIControlEventTouchUpInside];
    [bottomView addSubview:leftbutton];
    
    UIButton *rightbutton=[[UIButton alloc]init];
    rightbutton.frame=CGRectMake(bottomView.frame.size.width-70, 5, 68, 30);
    [rightbutton setTitle:@"退出" forState:UIControlStateNormal];
    [rightbutton setImage:[UIImage imageNamed:@"exitAccount"] forState:UIControlStateNormal];
    [rightbutton addTarget:self action:@selector(exitAccounts) forControlEvents:UIControlEventTouchUpInside];
    [bottomView addSubview:rightbutton];
    
}
-(void)editPasswords{
    ServerView=[[ChildSexView alloc]initWithBlock:newPasswordBlock Type:ChildSexViewEditPassword];
}
-(void)exitAccounts{
    self.navigationController.navigationBarHidden=YES;
    [[DataFormatterSingle shareCore]removeAccounts];
    [self.navigationController popToRootViewControllerAnimated:NO];
}
-(void)getPeopleMessageModel:(peopleMessageModel *)model{
    peopleMess=model;
}
-(void)editPasswordData:(NSString *)oldPass newpass:(NSString *)newPass againpass:(NSString *)againPass{
    NSString *str= [NSString stringWithFormat:@"http://%@/Mobile/UpdatePassword.html?token=%@",IPAddress,peopleMess.token];
    NSDictionary *parameters = @{@"src_pwd":oldPass,@"new_pwd1":newPass,@"new_pwd2":againPass};
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager POST:str parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"--%@",[operation responseString]);
        NSNumber *status=[responseObject objectForKey:@"status"];
        if ([status intValue]==1){
            [[DataFormatterSingle shareCore]remeberPassword:newPass];
        }else{
            [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:[responseObject objectForKey:@"info"]];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"error*___%@",[error localizedDescription]);
        [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"网络错误"];
    }];
}
-(void)getPeopleMessageData{
    NSString *str= [NSString stringWithFormat:@"http://%@/Mobile/UserInfo.html?token=%@",IPAddress,peopleMess.token];
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:str parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
       NSLog(@"--%@",[operation responseString]);
        NSNumber *status=[responseObject objectForKey:@"status"];
        if ([status intValue]==1){
            mutableArray=[NSMutableArray new];
            NSDictionary *dict=[responseObject objectForKey:@"data"];
            clickMess=[[clickheaderMessageModel alloc]init];
            [clickMess setValuesForKeysWithDictionary:dict];
            [mutableArray addObject:clickMess.user_name];
            [mutableArray addObject:clickMess.type];
            [mutableArray addObject:clickMess.email];
            [mutableArray addObject:clickMess.type_name];
            [table_view reloadData];
        }else{
            [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:[responseObject objectForKey:@"info"]];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"error*___%@",[error localizedDescription]);
        [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"网络错误"];
    }];
}
#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.

    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    // Return the number of rows in the section.
    return [array count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellId=@"PeopleMessageCell";
    
    PeopleMessageCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (cell == nil) {
        cell = [[PeopleMessageCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    cell.attributeLabel.text=[array objectAtIndex:indexPath.row];
    cell.attributeValueLabel.text=[mutableArray objectAtIndex:indexPath.row];
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    //cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

}
//定义header
//- (UIView *) tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
//
//}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 40;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
