//
//  WainingConnectController.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/20.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WainingModel.h"
@interface WainingConnectController : UITableViewController
@property (nonatomic,strong)NSMutableArray *array;

@property (nonatomic,copy)void(^blockReloadData)();
@property (nonatomic,copy)void(^blockWainingReloadData)();
-(void)getWainingModel:(WainingModel *)model block:(void(^)())dateBlock;
@end
