//
//  LeaveGroup.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/18.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LeaveGroup : NSObject

@property (nonatomic,strong)NSMutableArray *leaveArrays;

@property (nonatomic, assign, getter = isOpened) BOOL opened;

+ (instancetype)leaveGroupWithDict:(NSDictionary *)dict;
- (instancetype)initWithDict:(NSDictionary *)dict;
@end
