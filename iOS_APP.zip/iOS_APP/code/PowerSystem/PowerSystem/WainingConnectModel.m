//
//  WainingConnectModel.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/20.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "WainingConnectModel.h"

@implementation WainingConnectModel
+(WainingConnectModel*)rewriteModel:(NSDictionary *)dict{
    return [[self alloc]initWithDict:dict];
}
-(WainingConnectModel*)initWithDict:(NSDictionary *)dict{
    if (self==[super init]) {
        self.idStr=[dict objectForKey:@"id"];
        self.proj_idStr=[dict objectForKey:@"proj_id"];
        self.typeStr=[dict objectForKey:@"type"];
        self.contentStr=[dict objectForKey:@"content"];
        self.has_readStr=[dict objectForKey:@"has_read"];
        self.user_idStr=[dict objectForKey:@"user_id"];
        self.hashStr=[dict objectForKey:@"hash"];
    }
    return self;
}
@end
