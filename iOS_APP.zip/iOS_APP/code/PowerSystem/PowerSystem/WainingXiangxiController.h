//
//  WainingXiangxiController.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/20.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WainingConnectModel.h"
@interface WainingXiangxiController : UIViewController

@property (weak, nonatomic) IBOutlet UITextView *textView;
@property (nonatomic,copy)void(^blockReloadData)();
@property (nonatomic,copy)void(^blockWainingReloadData)();
-(void)getXiangxiModel:(WainingConnectModel *)model block:(void(^)())dateBlock  blocker:(void(^)())dateBlocker;
@end
