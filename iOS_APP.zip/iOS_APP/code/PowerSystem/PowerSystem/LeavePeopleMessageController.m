//
//  LeavePeopleMessageController.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/18.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "LeavePeopleMessageController.h"
#import "LeavePeopleCellModel.h"
#import "LeavePeopleCellFrame.h"
#import "LeavePeopleMessageCell.h"
#import "ReplayLeaveMessageController.h"
@interface LeavePeopleMessageController ()
{
    LeaveMessageModel *model;
    UIImageView *_toolBar;
    float heightt;
}
@end
#define kToolBarH 44
#define kTextFieldH 30
@implementation LeavePeopleMessageController
@synthesize cellFrameDatas;
- (void)viewDidLoad {
    [super viewDidLoad];
    heightt=0;
    [self.tableView setTableFooterView:[[UIView alloc]initWithFrame:CGRectZero]];
    self.tableView.backgroundColor=RGBColor(219, 226, 237);
    self.navigationItem.title=@"留言内容";
    
    [self navRightButton];
    
   // dispatch_async(dispatch_get_global_queue(0, 0), ^{
        [self getViewData];
   // });
    
    
    __weak LeavePeopleMessageController *leave = self;
    _PeopleMessageReloadDataBlock=^(){
        [leave blockPeopleMessage];
    };
}
-(void)blockPeopleMessage{
    //dispatch_async(dispatch_get_global_queue(0, 0), ^{
        [self getViewData];
   // });
}
-(void)navRightButton{
    UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitle:@"回复" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(RightButtonReplyMessage) forControlEvents:UIControlEventTouchUpInside];
    button.frame = CGRectMake(0, 0, 40, 40);
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.rightBarButtonItem = rightButton;
}
-(void)RightButtonReplyMessage{
    UIStoryboard *sb=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    ReplayLeaveMessageController *view=(ReplayLeaveMessageController *)[sb instantiateViewControllerWithIdentifier:@"ReplayLeaveMessage"];
    [view getLeaveMessageModel:model block:_PeopleMessageReloadDataBlock];
    [self.navigationController pushViewController:view animated:YES];
}

-(void)getMessageId:(LeaveMessageModel *)messageModel{
    model=messageModel;
}
-(void)getViewData{
    NSString *str=[NSString stringWithFormat:@"http://%@/Mobile/MessageBackList.html",IPAddress];
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    NSDictionary *parameter=@{@"message_id":model.id,@"token":[[DataFormatterSingle shareCore] getInfoToken]};
    [manager GET:str parameters:parameter success:^(AFHTTPRequestOperation *operation, id responseObject) {
        //NSLog(@"--%@",[operation responseString]);
        NSNumber *status=[responseObject objectForKey:@"status"];
        if ([status intValue]==1){
            cellFrameDatas=[NSMutableArray new];
            NSArray *arrays=[responseObject objectForKey:@"data"];
            for(NSDictionary *dic in arrays){
                LeavePeopleCellModel *message = [LeavePeopleCellModel messageModelWithDict:dic];
                LeavePeopleCellFrame *cellFrame = [[LeavePeopleCellFrame alloc] init];
                cellFrame.message=message;
                [cellFrameDatas addObject:cellFrame];
            }
            [self.tableView reloadData];
            for(LeavePeopleCellFrame *cellFrame in cellFrameDatas){
                heightt+=cellFrame.cellHeght;
            }
                NSLog(@"heightt-----:%f\n",heightt);
        }
        else{
            [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:[responseObject objectForKey:@"info"]];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"error*___%@",[error localizedDescription]);
        [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"网络错误"];
    }];

}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    // Return the number of rows in the section.
    return [cellFrameDatas count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellId=@"Cell";
    
    LeavePeopleMessageCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (cell == nil) {
        cell = [[LeavePeopleMessageCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    cell.cellFrame = cellFrameDatas[indexPath.row];
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    return cell;
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    self.tableView.contentSize = CGSizeMake(0,heightt);
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

}
//定义header
//- (UIView *) tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
//
//}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    LeavePeopleCellFrame *cellFrame = cellFrameDatas[indexPath.row];

    return cellFrame.cellHeght;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
