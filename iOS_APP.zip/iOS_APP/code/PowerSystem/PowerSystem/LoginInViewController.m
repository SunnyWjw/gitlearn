//
//  LoginInViewController.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/10.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "LoginInViewController.h"
#import "AFNetworking.h"
#import "peopleMessageModel.h"
#import "ViewController.h"
#import "ChildSexView.h"
#import "DataFormatterSingle.h"
#import "APService.h"
@interface LoginInViewController ()
{
    peopleMessageModel *peopleMessage;
    ChildSexView *ServerView;
}
@end

@implementation LoginInViewController
@synthesize headerImageView,accountTextfield,passwordTextField,ServerBlock,remeberPass,remeberPassButton,loginButton;

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    accountTextfield.text=[[DataFormatterSingle shareCore]getInfoAccount];
    passwordTextField.text=[[DataFormatterSingle shareCore]getInfoPassword];
    [self automaticLogin];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBarHidden=YES;
    if (IS_IPAD) {
        
        self.view.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"LoginBackground_ipad"]];
        
    }else{
        if (IS_IPHONE_5||IS_IPHONE_4) {
            self.view.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"LoginBackground"]];
        }
        else if (IS_IPHONE_6)
        {
            self.view.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"LoginBackground_iphone6"]];
        }
        else if (IS_IPHONE_6P)
        {
            self.view.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"LoginBackground_iphone6P"]];
        }
    }
    
    [[DataFormatterSingle shareCore]portServeString:@"192.168.1.159:827"];
    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(keyboardHide:)];
    //设置成NO表示当前控件响应后会传播到其他控件上，默认为YES。
    tapGestureRecognizer.cancelsTouchesInView = NO;
    //将触摸事件添加到当前view
    [self.view addGestureRecognizer:tapGestureRecognizer];
    [self remeberButton];
    [self textfieldValue];
    [self headerImageConfig];
    [self SeverBlocker];
    
    accountTextfield.layer.cornerRadius=15;
    accountTextfield.layer.borderWidth=3.0;
    accountTextfield.layer.borderColor=RGBColor(0, 150, 117).CGColor;
    accountTextfield.backgroundColor=RGBColorAlpha(104, 205, 197,0.8);
    
    passwordTextField.layer.cornerRadius=15;
    passwordTextField.layer.borderWidth=3.0;
    passwordTextField.layer.borderColor=RGBColor(0, 150, 117).CGColor;
    passwordTextField.backgroundColor=RGBColorAlpha(104, 205, 197,0.8);
    
    loginButton.layer.cornerRadius=20;
    loginButton.layer.borderWidth=3.0;
    loginButton.layer.borderColor=RGBColor(245, 200, 170).CGColor;
    loginButton.backgroundColor=RGBColor(255, 100, 64);
}
-(void)keyboardHide:(UITapGestureRecognizer*)tap{
    [accountTextfield resignFirstResponder];
    [passwordTextField resignFirstResponder];
}
-(void)textfieldValue{
    accountTextfield.delegate=self;
    passwordTextField.delegate=self;
    passwordTextField.secureTextEntry=YES;
}
-(void)remeberButton{
    remeberPass=YES;
    [remeberPassButton setImage:[UIImage imageNamed:@"remeberPass_on"] forState:UIControlStateNormal];
    remeberPassButton.backgroundColor=[UIColor clearColor];
}

-(void)automaticLogin{
    NSString *account=[[DataFormatterSingle shareCore]getInfoAccount];
    NSString *password=[[DataFormatterSingle shareCore]getInfoPassword];
    if ([account length]&&[password length]) {
        //dispatch_async(dispatch_get_global_queue(0, 0), ^{
            [self getAccountData];
        //});
    }
}

- (IBAction)remeberPassClick:(id)sender {
    if (remeberPass) {
        remeberPass=!remeberPass;
        [remeberPassButton setImage:[UIImage imageNamed:@"remeberPass_off"] forState:UIControlStateNormal];
    }else{
        remeberPass=!remeberPass;
        [remeberPassButton setImage:[UIImage imageNamed:@"remeberPass_on"] forState:UIControlStateNormal];
    }
    
}
-(void)SeverBlocker{
    ServerBlock=^(NSString *ServerString,NSString *two,NSString *three){
        [[DataFormatterSingle shareCore]portServeString:ServerString];
    };
}
-(void)headerImageConfig{
    headerImageView.layer.masksToBounds=YES;
    headerImageView.layer.cornerRadius=headerImageView.bounds.size.width*0.5;
}
-(void)beginIgnoring{
    [[SHKActivityIndicator currentIndicator]displayActivity:@"登录中..."];
    [[UIApplication sharedApplication] beginIgnoringInteractionEvents];
}
-(void)endIgnoring{
    [[SHKActivityIndicator currentIndicator]hide];
    [[UIApplication sharedApplication] endIgnoringInteractionEvents];
}
-(void)getAccountData{
    [self beginIgnoring];
    NSString *accountStr=accountTextfield.text;
    NSString *passwordStr=passwordTextField.text;
    NSString *str= [NSString stringWithFormat:@"http://%@/Mobile/UserLogin",IPAddress];
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    NSDictionary *parameters = @{@"login_name":accountStr,@"login_password":passwordStr};
    [manager POST:str parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
        [self endIgnoring];
        NSLog(@"--%@",[operation responseString]);
        NSNumber *status=[responseObject objectForKey:@"status"];
        if ([status intValue]==1){
            
            NSSet * set = [[NSSet alloc] initWithObjects:accountStr,nil];
            //极光绑定tag
            [APService setTags:set alias:nil callbackSelector:@selector(PushCallBack:tag:ali:) target:self];
            
            if (remeberPass) {
                [[DataFormatterSingle shareCore]remeberAccount:accountStr];
                [[DataFormatterSingle shareCore]remeberPassword:passwordStr];
            }else{
                [[DataFormatterSingle shareCore]remeberDiaoyongPassword:passwordStr];
            }
            NSDictionary *dict=[responseObject objectForKey:@"data"];
             peopleMessage=[[peopleMessageModel alloc]init];
            [peopleMessage setValuesForKeysWithDictionary:dict];
            [[DataFormatterSingle shareCore]remeberToken:peopleMessage.token];
            [self pushPeopleViewController];
        }else{
            [self endIgnoring];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:[responseObject objectForKey:@"info"]];
                });
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [self endIgnoring];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"登录异常"];
        });
        
        NSLog(@"error*___%@",[error localizedDescription]);
        
    }];
}

-(void)PushCallBack:(int)code tag:(NSSet *)tags ali:(NSString *)alias{
    
    NSLog(@"----codecode-%d\n,tagstags:%@\n,aliasalias:%@\n",code,tags,alias);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)LoginPower:(id)sender {
    if ([accountTextfield.text length]&&[passwordTextField.text length]) {
        //dispatch_async(dispatch_get_global_queue(0, 0), ^{
            [self getAccountData];
        //});
    }else{
        [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"请输入用户名和密码"];
    }
   
}

- (IBAction)configServer:(id)sender {
    
    ServerView=[[ChildSexView alloc]initWithBlock:ServerBlock Type:ChildSexViewServer];
    
}


-(void)pushPeopleViewController{
    self.navigationController.navigationBarHidden=NO;
    UIStoryboard *sb=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    ViewController *view=(ViewController *)[sb instantiateViewControllerWithIdentifier:@"ViewController"];
    [view getPeopleMessageModel:peopleMessage];
    [self.navigationController pushViewController:view animated:NO];
}
#pragma mark - UITextfield delegate

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
