//
//  DataFormatterSingle.m
//  JxbApp
//
//  Created by huhaifeng on 15/7/29.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "DataFormatterSingle.h"

static DataFormatterSingle *_shareCore;
@implementation DataFormatterSingle
+(DataFormatterSingle*)shareCore{
    if (!_shareCore) {
        _shareCore=[[DataFormatterSingle alloc]init];
    }
    return _shareCore;
}
-(void)portServeString:(NSString *)serve{
    NSUserDefaults *portServeUser;
    portServeUser=[NSUserDefaults standardUserDefaults];
    [portServeUser setObject:serve forKey:@"portServeString"];
    [portServeUser synchronize];
}
-(NSString *)getInfoPortServeString{
    NSUserDefaults *userDefaults=[NSUserDefaults standardUserDefaults];
    NSString *str=[userDefaults stringForKey:@"portServeString"];
    return str;
}

-(void)ServeString:(NSString *)serve{
    NSUserDefaults *serveUser;
    serveUser=[NSUserDefaults standardUserDefaults];
    [serveUser setObject:serve forKey:@"serveString"];
    [serveUser synchronize];
}
-(NSString *)getInfoServeString{
    NSUserDefaults *userDefaults=[NSUserDefaults standardUserDefaults];
    NSString *str=[userDefaults stringForKey:@"serveString"];
    return str;
}

-(void)PortString:(NSString *)serve{
    NSUserDefaults *portUser;
    portUser=[NSUserDefaults standardUserDefaults];
    [portUser setObject:serve forKey:@"portString"];
    [portUser synchronize];
}
-(NSString *)getInfoPortString
{
    NSUserDefaults *userDefaults=[NSUserDefaults standardUserDefaults];
    NSString *str=[userDefaults stringForKey:@"portString"];
    return str;
}

-(void)remeberAccount:(NSString *)account{
    NSUserDefaults *accountUser;
    accountUser=[NSUserDefaults standardUserDefaults];
    [accountUser setObject:account forKey:@"account"];
    [accountUser synchronize];
}
-(NSString *)getInfoAccount{
    NSUserDefaults *userDefaults=[NSUserDefaults standardUserDefaults];
    NSString *str=[userDefaults stringForKey:@"account"];
    return str;
}

-(void)remeberPassword:(NSString *)password{
    NSUserDefaults *passwordUser;
    passwordUser=[NSUserDefaults standardUserDefaults];
    [passwordUser setObject:password forKey:@"password"];
    [passwordUser synchronize];
}
-(NSString *)getInfoPassword{
    NSUserDefaults *userDefaults=[NSUserDefaults standardUserDefaults];
    NSString *str=[userDefaults stringForKey:@"password"];
    return str;
}

-(void)remeberDiaoyongPassword:(NSString *)password{
    NSUserDefaults *diaoyongpasswordUser;
    diaoyongpasswordUser=[NSUserDefaults standardUserDefaults];
    [diaoyongpasswordUser setObject:password forKey:@"diaoyongpassword"];
    [diaoyongpasswordUser synchronize];
}
-(NSString *)getInfoDiaoyongPassword{
    NSUserDefaults *userDefaults=[NSUserDefaults standardUserDefaults];
    NSString *str=[userDefaults stringForKey:@"diaoyongpassword"];
    return str;
}
-(void)remeberToken:(NSString *)password{
    NSUserDefaults *remeberTokenUser;
    remeberTokenUser=[NSUserDefaults standardUserDefaults];
    [remeberTokenUser setObject:password forKey:@"token"];
    [remeberTokenUser synchronize];
}
-(NSString *)getInfoToken{
    NSUserDefaults *userDefaults=[NSUserDefaults standardUserDefaults];
    NSString *str=[userDefaults stringForKey:@"token"];
    return str;
}


-(void)removeAccounts{
    NSUserDefaults *userDefaults=[NSUserDefaults standardUserDefaults];
    [userDefaults removeObjectForKey:@"account"];
    [userDefaults removeObjectForKey:@"password"];
    [userDefaults synchronize];
}
//通过计算时间间隔
-(int)timeInterval:(NSDate *)newDate olddata:(NSDate *)oldDate{

    NSTimeInterval time=[newDate timeIntervalSinceDate:oldDate];
    int days=((int)time)/(3600*24);
    //NSLog(@"-----days:%d",days);
    return days;
}

//字符串转Date
-(NSDate *)dateWithStrings:(NSString *)dateString{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    NSDate *date = [dateFormatter dateFromString:dateString];
    
    return date;
}
//2015-05-26 16:00:00 +0000  -> 2015-05-26
-(NSString *)dateFormStrings:(NSDate *)date{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    NSString *string=[dateFormatter stringFromDate:date];
    return string;
}

//2015-05-26 16:00:00 +0000  -> 2015-05-26 12:00:00
-(NSString *)dateZhuanString:(NSDate *)date{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSString *string=[dateFormatter stringFromDate:date];
    return string;
}

-(NSDate *)datedatedate:(NSString *)string{
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    df.dateFormat = @"MM/dd/yyyy";
    NSDate *valentinesDay = [df dateFromString:string];
    return valentinesDay;
}


-(int)returnDaysfrom :(NSString *)titlestring endstring:(NSString *)end_dateString startstring:(NSString *)start_dateString{
    int days=0;
    NSDate *dateA = [[DataFormatterSingle shareCore]dateWithStrings:end_dateString];
    NSDate *dateB = [[DataFormatterSingle shareCore]dateWithStrings:start_dateString];
    days=[[DataFormatterSingle shareCore]timeInterval:dateA olddata:dateB];
    if ([titlestring isEqualToString:@"初设内审"]||
        [titlestring isEqualToString:@"土建主体结构施工"]||
        [titlestring isEqualToString:@"电气安装"]||
        [titlestring isEqualToString:@"电气调试"]
        )
    {
        if ([titlestring isEqualToString:@"初设内审"]){
            days-=20;
        }
        else if ([titlestring isEqualToString:@"土建主体结构施工"]){
            days-=45;
        }
        else if ([titlestring isEqualToString:@"电气安装"]){
            days-=50;
        }
        else {
            days-=20;
        }
    }
    else if ([titlestring isEqualToString:@"土建扫尾施工"])
    {
        days-=45;
    }
    else if ([titlestring isEqualToString:@"初步设计"])
    {
        days-=40;
    }
    else{
        days=0;
    }
    
    return days;
    
}


-(NSString *)dateFormatter:(NSString *)str{
    if (![str length]) {
        return nil;
    }
    //2010-07-08 -> 7月8日
    NSString*abc=[str substringFromIndex:5];
    NSString*Mabc=[abc substringWithRange:NSMakeRange(0, 2)];
    NSString*Dabc=[abc substringWithRange:NSMakeRange(3, 2)];
    if ([Mabc hasPrefix:@"0"]&&[Mabc length]>1) {
        Mabc=[Mabc substringWithRange:NSMakeRange(1, 1)];
    }
    if ([Dabc hasPrefix:@"0"]&&[Dabc length]>1) {
        Dabc=[Dabc substringWithRange:NSMakeRange(1, 1)];
    }
    NSString *dateStr=[NSString stringWithFormat:@"%@月%@日",Mabc,Dabc];
    return dateStr;
}

-(NSString *)dateformatterMM:(NSString *)str{
    if (![str length]) {
        return nil;
    }
    //2010-07-08 -> 7
    NSString*abc=[str substringFromIndex:5];
    NSString*Mabc=[abc substringWithRange:NSMakeRange(0, 2)];
    if ([Mabc hasPrefix:@"0"]&&[Mabc length]>1) {
        Mabc=[Mabc substringWithRange:NSMakeRange(1, 1)];
    }
    return Mabc;
}
-(NSString *)dateformatterDD:(NSString *)str{
    if (![str length]) {
        return nil;
    }
    //2010-07-08 -> 8
    //2010-07-18 -> 18
    NSString*abc=[str substringFromIndex:8];
    NSString*Dabc=[abc substringWithRange:NSMakeRange(0, 2)];
    if ([Dabc hasPrefix:@"0"]&&[Dabc length]>1) {
        Dabc=[Dabc substringWithRange:NSMakeRange(1, 1)];
    }
    return Dabc;
}

-(NSString *)dateformatterYY:(NSString *)str{
    if (![str length]) {
        return nil;
    }
    //2010-07-08 -> 2010
    NSString*abc=[str substringWithRange:NSMakeRange(0, 4)];
    return abc;
}

-(NSString *)dateYearFormatter:(NSString *)str{
    if (![str length]) {
        return nil;
    }
    //2010-07-08 -> 2010年7月8日
    NSString*Yabc=[str substringWithRange:NSMakeRange(0, 4)];
    NSString*Mabc=[str substringWithRange:NSMakeRange(5, 2)];
    NSString*Dabc=[str substringWithRange:NSMakeRange(8, 2)];
    if ([Mabc hasPrefix:@"0"]&&[Mabc length]>1) {
        Mabc=[Mabc substringWithRange:NSMakeRange(1, 1)];
    }
    if ([Dabc hasPrefix:@"0"]&&[Dabc length]>1) {
        Dabc=[Dabc substringWithRange:NSMakeRange(1, 1)];
    }
    NSString *dateStr=[NSString stringWithFormat:@"%@年%@月%@日",Yabc,Mabc,Dabc];
    return dateStr;
}
-(NSString *)weekFormatter:(NSNumber *)str{
    if (![str intValue]) {
        return nil;
    }
    NSString *week;
    if ([str intValue] ==1) {
        week=@"一";
    }else if ([str intValue] ==2){
        week=@"二";
    }else if ([str intValue] ==3){
        week=@"三";
    }else if ([str intValue] ==4){
        week=@"四";
    }else if ([str intValue] ==5){
        week=@"五";
    }else if ([str intValue] ==6){
        week=@"六";
    }else if ([str intValue] ==7){
        week=@"日";
    }
    return week;
}
-(NSString *)timeFormatter:(NSString *)str{
    if (![str length]) {
        return nil;
    }
    NSString *temp = @"-";
    NSRange rang = [str rangeOfString:temp];
    NSString *string = [str stringByReplacingCharactersInRange:rang withString:@"~"];
    return string;
}

-(NSString *)boolForType:(NSString *)str{
    NSArray *array = [str componentsSeparatedByString:@"."]; //从字符A中分隔成多个元素的数组
    
    NSString *string=[array objectAtIndex:[array count]-1];
    return string;
}
-(BOOL)retrieveFileData:(NSString *)savePath Name:(NSString *)name{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
    //文件名
    NSString *uniquePath=[[paths objectAtIndex:0] stringByAppendingPathComponent:name];
    BOOL blHave=[[NSFileManager defaultManager] fileExistsAtPath:uniquePath];
    return blHave;
}
-(void)beginIgnoring{
    [[SHKActivityIndicator currentIndicator]displayActivity:@"发送中..."];
    [[UIApplication sharedApplication] beginIgnoringInteractionEvents];
}
-(void)endIgnoring{
    [[SHKActivityIndicator currentIndicator]hide];
    [[UIApplication sharedApplication] endIgnoringInteractionEvents];
}
@end
