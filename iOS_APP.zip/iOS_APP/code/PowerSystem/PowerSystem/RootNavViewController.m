//
//  RootNavViewController.m
//  JxbApp
//
//  Created by huhaifeng on 15/7/15.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "RootNavViewController.h"
#import "ListTableWebController.h"
#import "ViewController.h"
@interface RootNavViewController ()

@end

@implementation RootNavViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.navigationBar setBackgroundImage:[UIImage imageNamed:@"navBackground"] forBarPosition:UIBarPositionTopAttached barMetrics:UIBarMetricsDefault];
    [self.navigationBar setTitleTextAttributes:@{
                                                 NSForegroundColorAttributeName :[UIColor whiteColor]
                                                 }];
    self.navigationBar.tintColor=[UIColor whiteColor];
    self.navigationBar.translucent = NO;
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(noti:) name:@"ViewController" object:nil];

}
-(void)noti:(NSNotification *)userInfo{
     dispatch_queue_t myConnectQueue;
    myConnectQueue=dispatch_queue_create("AccelerateControl.init",NULL);
    dispatch_async(myConnectQueue, ^{
    while (YES) {
        if ([self.visibleViewController isKindOfClass:[ViewController class]]) {
            break;
        }
    }
    dispatch_async(dispatch_get_main_queue(),^{
        ViewController *view=(ViewController*)self.visibleViewController;
        [view pushWainingClick:nil];
        });
    });

}
//- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation
//{
//    NSLog(@"-----");
//    return toInterfaceOrientation != UIDeviceOrientationPortraitUpsideDown;
//}

- (BOOL)shouldAutorotate
{
//    if ([self.topViewController isKindOfClass:[ListTableWebController class]]) { // 如果是这个 vc 则支持自动旋转
//        return NO;
//    }
    return NO;
}

//- (NSUInteger)supportedInterfaceOrientations
//{
//    if ([self.topViewController isKindOfClass:[ListTableWebController class]]) { // 如果是这个 vc 则支持自动旋转
//        return UIInterfaceOrientationMaskAll;
//    }
//    return UIInterfaceOrientationMaskPortrait;
//}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated{
    
    [super pushViewController:viewController animated:animated];
}
- (UIViewController *)popViewControllerAnimated:(BOOL)animated{

    return  [super popViewControllerAnimated:animated];
}
/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end