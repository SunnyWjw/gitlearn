//
//  LineDetailController.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/11.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "peopleMessageModel.h"
#import "PlanManagerModel.h"
#import "LineProjectModel.h"
@interface LineDetailController : UIViewController<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic ,strong)NSMutableArray *xiangxiArray;
@property (weak, nonatomic) IBOutlet UITableView *table_view;

@property (weak, nonatomic) IBOutlet UILabel *projectNme;

@property (weak, nonatomic) IBOutlet UILabel *projectPeopleName;
@property (weak, nonatomic) IBOutlet UILabel *projectStartDate;

@property (weak, nonatomic) IBOutlet UILabel *projectEndDate;
@property (strong, nonatomic) UILabel *responNameLabel;

@property (nonatomic,copy) void(^cellDataBlock)();


@property (nonatomic,copy) void(^cellDateOkNumberBlock)(int dateNum);
@property (nonatomic,copy) void(^cellDateNumBlock)(int dateNum);
-(void)getProjectId:(LineProjectModel *)model;
@end
