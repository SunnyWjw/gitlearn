//
//  ViewController.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/10.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "ViewController.h"
#import "AFNetworking.h"
#import "UIImageView+MJWebCache.h"
#import "PeopleMessageController.h"
#import "PlanManagerViewController.h"
#import "MMCTableViewController.h"
#import "ReportFormsController.h"
#import "LeaveMessageController.h"
#import "FileDataTableController.h"
#import "WainingTableViewController.h"
@interface ViewController ()
{
    peopleMessageModel *peopleMessage;
}
@end

@implementation ViewController
@synthesize planManage,waining,report,mMC,fileData,leaveMessage;
- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title=@"基建部办公系统";
    [self hiddenLeftBarButtonItem];
    [self customRightBarButtonItem];
    //[self buttonSetImages];
}
-(void)getPeopleMessageModel:(peopleMessageModel*)model{
    peopleMessage=model;
}

-(void)buttonSetImages{
    [planManage setImage:[UIImage imageNamed:@"PlanManageController"] forState:UIControlStateNormal];
    [waining setImage:[UIImage imageNamed:@"WainingController"] forState:UIControlStateNormal];
    [mMC setImage:[UIImage imageNamed:@"MMCController"] forState:UIControlStateNormal];
    [leaveMessage setImage:[UIImage imageNamed:@"LeaveController"] forState:UIControlStateNormal];
    [fileData setImage:[UIImage imageNamed:@"FileDataController"] forState:UIControlStateNormal];
    [report setImage:[UIImage imageNamed:@"ReportController"] forState:UIControlStateNormal];
}

- (IBAction)planManagerClick:(id)sender {
    UIStoryboard *sb=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    PlanManagerViewController *view=(PlanManagerViewController *)[sb instantiateViewControllerWithIdentifier:@"PlanManager"];
    [view getTokenModel:NO report:NO reportend:NO];
    [self navLeftButton];
    [self.navigationController pushViewController:view animated:NO];
}
-(IBAction)playMMClick:(id)sender {
    UIStoryboard *sb=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    MMCTableViewController *view=(MMCTableViewController *)[sb instantiateViewControllerWithIdentifier:@"MMCTable"];
    [self navLeftButton];
    [self.navigationController pushViewController:view animated:NO];
}

- (IBAction)pushReportFormsController:(id)sender {
    UIStoryboard *sb=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    ReportFormsController *view=(ReportFormsController *)[sb instantiateViewControllerWithIdentifier:@"ReportForms"];
    [self navLeftButton];
    [self.navigationController pushViewController:view animated:NO];
}

- (IBAction)LeaveMessageClick:(id)sender {
    UIStoryboard *sb=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    LeaveMessageController *view=(LeaveMessageController *)[sb instantiateViewControllerWithIdentifier:@"LeaveMessage"];
    [self navLeftButton];
    [self.navigationController pushViewController:view animated:NO];
    
}

- (IBAction)pushFileDataClick:(id)sender {
    UIStoryboard *sb=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    FileDataTableController *view=(FileDataTableController *)[sb instantiateViewControllerWithIdentifier:@"FileData"];
    [self navLeftButton];
    [self.navigationController pushViewController:view animated:NO];
}

- (IBAction)pushWainingClick:(id)sender {
    
    UIStoryboard *sb=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    WainingTableViewController *view=(WainingTableViewController *)[sb instantiateViewControllerWithIdentifier:@"WainingTable"];
    [self navLeftButton];
    [self.navigationController pushViewController:view animated:NO];
}
-(void)navLeftButton{
    UIBarButtonItem *backItem = [[UIBarButtonItem alloc] init];
    backItem.title = @"返回";
    self.navigationItem.backBarButtonItem = backItem;
}
-(void)hiddenLeftBarButtonItem{
    UIButton *buttonleft = [UIButton buttonWithType:UIButtonTypeCustom];
    UIBarButtonItem *leftButtonItem = [[UIBarButtonItem alloc]initWithCustomView:buttonleft];
    self.navigationItem.leftBarButtonItem = leftButtonItem;
    buttonleft.hidden=YES;
}

-(void)customRightBarButtonItem{
    UIImageView *rightImageView = [[UIImageView alloc]init];
    rightImageView.frame=CGRectMake(0, 0, 30, 30);
    if (![peopleMessage.avatar hasPrefix:@"http://"]) {
        peopleMessage.avatar=[NSString stringWithFormat:@"http://%@/%@",IPAddress,peopleMessage.avatar];
    }
    [rightImageView setImageURLStr:peopleMessage.avatar placeholder:[UIImage imageNamed:@"defaultHeader"]];
    rightImageView.layer.masksToBounds=YES;
    rightImageView.layer.cornerRadius=rightImageView.bounds.size.width*0.5;
    rightImageView.layer.borderWidth=2.0;
    rightImageView.layer.borderColor=[UIColor whiteColor].CGColor;
    
    UITapGestureRecognizer *panRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handlePanFrom:)];
    [rightImageView addGestureRecognizer:panRecognizer];//关键语句，给self.view添加一个手势监测；
    panRecognizer.numberOfTapsRequired = 1;
    panRecognizer.delegate = self;
    UIBarButtonItem *rightButtonItem = [[UIBarButtonItem alloc]initWithCustomView:rightImageView];
    self.navigationItem.rightBarButtonItem = rightButtonItem;
}
- (void)handlePanFrom:(UITapGestureRecognizer *)recognizer{
    UIStoryboard *sb=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    PeopleMessageController *view=(PeopleMessageController *)[sb instantiateViewControllerWithIdentifier:@"PeopleMessage"];
    [view getPeopleMessageModel:peopleMessage];
    [self.navigationController pushViewController:view animated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)abcde{
    NSLog(@"1111111111118888888888888888111111111111");
}
@end
