//
//  DeleteLeaveImageController.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/19.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DeleteLeaveImageController : UIViewController<UIActionSheetDelegate>

@property (nonatomic,copy) void(^cellDeleteImageBlock)(UIImage *image);
-(void)setPreviewImage:(UIImage *)image block:(void(^)(UIImage *image))Block;
@end
