//
//  MMCImageController.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/15.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LineProjectModel.h"

@interface MMCImageController : UITableViewController<UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>

@property (nonatomic ,assign)LineString style;
@property (nonatomic ,strong)NSMutableArray *imageArray;
@property (nonatomic ,strong)NSMutableArray *imagePathArray;
@property (nonatomic ,strong)NSMutableArray *imageNameArray;
@property (nonatomic ,strong)NSMutableArray *imagesPathAllArray;

-(void)getLineProjectModel:(LineProjectModel *)model style:(LineString )lineStyle;

@end
