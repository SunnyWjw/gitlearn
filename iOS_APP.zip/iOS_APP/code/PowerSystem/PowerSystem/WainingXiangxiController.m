//
//  WainingXiangxiController.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/20.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "WainingXiangxiController.h"

@interface WainingXiangxiController ()
{
    WainingConnectModel *WainModel;
    NSDictionary *dataDic;
}
@end

@implementation WainingXiangxiController

- (void)viewDidLoad {
    [super viewDidLoad];
    _textView.backgroundColor=STATICBACKCOLOR;
    _textView.editable=NO;
    self.navigationItem.title=@"详细";
    //dispatch_async(dispatch_get_global_queue(0, 0), ^{
        [self getWainingXiangxiData];
    //});
}
-(void)getXiangxiModel:(WainingConnectModel *)model block:(void(^)())dateBlock  blocker:(void(^)())dateBlocker{
    WainModel=model;
    _blockReloadData=dateBlock;
    _blockWainingReloadData=dateBlocker;
}
-(void)getWainingXiangxiData{
    NSString *str=[NSString stringWithFormat:@"http://%@/Mobile/AlertDetail",IPAddress];
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    NSDictionary *parameter=@{@"alert_id":WainModel.idStr,@"token":[[DataFormatterSingle shareCore]getInfoToken]};
    
    [manager GET:str parameters:parameter success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"--%@",[operation responseString]);
        NSNumber *status=[responseObject objectForKey:@"status"];
        if ([status intValue]==1){
            dataDic=[responseObject objectForKey:@"data"];
            _textView.text=[dataDic objectForKey:@"content"];
            
            [self ConfigHasRead];
        }
        else{
            [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:[responseObject objectForKey:@"info"]];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"error*___%@",[error localizedDescription]);
        [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"网络错误"];
    }];

}


-(void)ConfigHasRead{
    NSNumber *has_read=[dataDic objectForKey:@"has_read"];
    if ([has_read intValue]==1) {
        return;
    }
    else
    {
        NSString *str=[NSString stringWithFormat:@"http://%@/Mobile/AlertHasRead",IPAddress];
        AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
        NSDictionary *parameter=@{@"alert_id":WainModel.idStr,@"token":[[DataFormatterSingle shareCore]getInfoToken]};
        [manager GET:str parameters:parameter success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSLog(@"--%@",[operation responseString]);
            NSNumber *status=[responseObject objectForKey:@"status"];
            if ([status intValue]==1){
               // _blockReloadData();
                
                _blockWainingReloadData();
            }
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            NSLog(@"error*___%@",[error localizedDescription]);
        }];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
