//
//  BottomView.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/10.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "BottomView.h"
#import "Animations.h"
@interface BottomView(){
    CGRect fr;
}
@end
@implementation BottomView
-(id)initWithFrame:(CGRect)frame{
    self=[super initWithFrame:frame];
    if (self) {
        fr=frame;
    }
    return self;
}
- (UIImage *)backgroundGradientImageWithSize:(CGSize)size
{
    CGPoint center = CGPointMake(size.width * 0.5, size.height * 0.5);
    CGFloat innerRadius = 0;
    CGFloat outerRadius = sqrtf(size.width * size.width + size.height * size.height) * 0.5;
    
    BOOL opaque = NO;
    UIGraphicsBeginImageContextWithOptions(size, opaque, [[UIScreen mainScreen] scale]);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    const size_t locationCount = 2;
    CGFloat locations[locationCount] = { 0.0, 1.0 };
    CGFloat components[locationCount * 4] = {
        0.0, 0.0, 0.0, 0.1, // More transparent black
        0.0, 0.0, 0.0, 0.7  // More opaque black
    };
    
    CGColorSpaceRef colorspace = CGColorSpaceCreateDeviceRGB();
    CGGradientRef gradient = CGGradientCreateWithColorComponents(colorspace, components, locations, locationCount);
    
    CGContextDrawRadialGradient(context, gradient, center, innerRadius, center, outerRadius, 0);
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    CGColorSpaceRelease(colorspace);
    CGGradientRelease(gradient);
    
    return image;
}
- (void)layoutSubviews {
    [super layoutSubviews];
}
-(void)show{
    self.backgroundColor=RGBColor(41, 166, 204);
    self.superview.alpha = 1;
//    UIImageView *imageView=[[UIImageView alloc]init];
//    imageView.frame=CGRectMake(5, 5, 30, 30);
//    imageView.backgroundColor=[UIColor grayColor];
//    [self addSubview:imageView];
//    
//    UILabel *label=[[UILabel alloc]init];
//    label.frame=CGRectMake(CGRectGetMaxX(imageView.frame)+2, 5, 36, 30);
//    label.text=@"密码";
//    [self addSubview:label];
//    
//    UIImageView *backImageView=[[UIImageView alloc]init];
//    backImageView.frame=CGRectMake(self.frame.size.width-70, 5, 30, 30);
//    backImageView.backgroundColor=[UIColor grayColor];
//    [self addSubview:backImageView];
//    
//    UILabel *backLabel=[[UILabel alloc]init];
//    backLabel.frame=CGRectMake(CGRectGetMaxX(backImageView.frame)+2, 5, 36, 30);
//    backLabel.text=@"退出";
//    [self addSubview:backLabel];
    UIButton *leftbutton=[[UIButton alloc]init];
    leftbutton.frame=CGRectMake(5, 5, 68, 30);
    [leftbutton setTitle:@"密码" forState:UIControlStateNormal];
    [leftbutton addTarget:self action:@selector(editPassword) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:leftbutton];
    
    UIButton *rightbutton=[[UIButton alloc]init];
    rightbutton.frame=CGRectMake(self.frame.size.width-70, 5, 68, 30);
    [rightbutton setTitle:@"退出" forState:UIControlStateNormal];
    [rightbutton addTarget:self action:@selector(exitAccount) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:rightbutton];
    
}
-(void)editPassword{
    
}
-(void)exitAccount{
    
}
-(void)dissshow{
    [self.superview removeFromSuperview];
    [self removeFromSuperview];

}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
