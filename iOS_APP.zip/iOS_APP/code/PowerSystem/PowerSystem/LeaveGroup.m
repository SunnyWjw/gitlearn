//
//  LeaveGroup.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/18.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "LeaveGroup.h"
#import "LeaveMessageModel.h"
@implementation LeaveGroup
@synthesize leaveArrays;
+ (instancetype)leaveGroupWithDict:(NSDictionary *)dict{
    return [[self alloc] initWithDict:dict];
}
- (instancetype)initWithDict:(NSDictionary *)dict{
    if (self = [super init]) {
        leaveArrays=[NSMutableArray new];
        NSArray *array=[dict objectForKey:@"array"];
        for (NSDictionary *dict in array) {
            LeaveMessageModel *leave = [LeaveMessageModel LeaveGroupWithDict:dict];
            [leaveArrays addObject:leave];
        }
    }
    return self;
}
@end
