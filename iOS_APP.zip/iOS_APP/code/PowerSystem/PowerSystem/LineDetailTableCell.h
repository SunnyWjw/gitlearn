//
//  LineDetailTableCell.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/11.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LineDetailCellFrame.h"
#import "ChildSexView.h"
@interface LineDetailTableCell : UITableViewCell<UIGestureRecognizerDelegate,UIAlertViewDelegate>{
    UIImageView *_backImage;
    UILabel *_projectTitle;
    UILabel *_start_date;
    UILabel *_fengefu;
    UILabel *_end_date;
    UIImageView *_circleImageView;
    UILabel *_line;
    UILabel *_responNameLabel;
    UILabel *_dateLabel;
    UILabel *_complete_std;
    ChildSexView *ServerView;
    LineDetailCellFrame *cellFrame;
}
@property (nonatomic,copy) void(^cellDataBlock)();
@property (nonatomic,copy) void(^cellDateNumBlock)(int dateNum);
@property (nonatomic,copy) void(^cellDateOkNumberBlock)(int dateNum);
-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier block:(void(^)())BLOCK twoBlock:(void(^)(int num))blocks;
- (LineDetailTableCell *)cellWithInformWeiboFrames:(LineDetailCellFrame *)weiboFrames;
@end
