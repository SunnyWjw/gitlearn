//
//  LineProjectModel.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/11.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LineProjectModel : NSObject
@property(nonatomic,copy)NSNumber *id;
@property(nonatomic,copy)NSString *name;
@property(nonatomic,copy)NSString *start_date;
@property(nonatomic,copy)NSString *end_date;
@property(nonatomic,copy)NSString *responsible;
@property(nonatomic,copy)NSString *responsible_name;
@end
