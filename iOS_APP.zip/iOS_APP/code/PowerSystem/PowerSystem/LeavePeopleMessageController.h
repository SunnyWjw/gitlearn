//
//  LeavePeopleMessageController.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/18.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LeaveMessageModel.h"
@interface LeavePeopleMessageController : UITableViewController<UITextFieldDelegate>


@property (nonatomic,strong)NSMutableArray *cellFrameDatas;
@property (nonatomic,copy) void(^PeopleMessageReloadDataBlock)();
-(void)getMessageId:(LeaveMessageModel *)messageModel;
@end
