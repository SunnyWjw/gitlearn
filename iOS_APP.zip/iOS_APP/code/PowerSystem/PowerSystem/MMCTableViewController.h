//
//  MMCTableViewController.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/14.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MMCTableViewController : UITableViewController

@property (nonatomic,strong)NSMutableArray *MMCTableArray;

@end
