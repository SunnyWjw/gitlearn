//
//  BottomView.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/10.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BottomView : UIView<UIGestureRecognizerDelegate>

-(void)show;
-(void)dissshow;
@end
