//
//  ReplayLeaveMessageController.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/19.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "ReplayLeaveMessageController.h"
#import "DeleteLeaveImageController.h"
@interface ReplayLeaveMessageController (){
    UILabel *placeholder;
    BOOL imageSelect;
    LeaveMessageModel *message;
}

@end

@implementation ReplayLeaveMessageController

- (void)viewDidLoad {
    [super viewDidLoad];
    imageSelect=NO;
    [self initTextView];
    [self initImageView];
    [self navRightButton];
    UITapGestureRecognizer *selfRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(textViewHiddenPanFrom:)];
    selfRecognizer.numberOfTapsRequired = 1;
    selfRecognizer.delegate = self;
    [self.view addGestureRecognizer:selfRecognizer];
    __weak ReplayLeaveMessageController *replay=self;
    
    _cellDeleteImageBlock=^(UIImage *image){
        replay.imageView.image=[UIImage imageNamed:@"addImage.png"];
        imageSelect=NO;
    };
}
-(void)navRightButton{
    UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitle:@"发送" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(RightReplyLeaveMessage) forControlEvents:UIControlEventTouchUpInside];
    button.frame = CGRectMake(0, 0, 40, 40);
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.rightBarButtonItem = rightButton;
}
-(void)RightReplyLeaveMessage{
    if (![self.textView.text length]) {
        [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"请填写留言内容"];
        return;
    }
//    [self upload];
    [[DataFormatterSingle shareCore]beginIgnoring];
    NSString *str= [NSString stringWithFormat:@"http://%@/Mobile/MessageBack.html?message_id=%@&token=%@",IPAddress,message.id,[[DataFormatterSingle shareCore]getInfoToken]];
    NSDictionary *paramter=@{@"content":_textView.text};
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager POST:str parameters:paramter constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        NSData *data;
        //判断图片是不是png格式的文件
        NSString *fileName;
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
             // 设置时间格式
        formatter.dateFormat = @"yyyyMMddHHmmss";
        NSString *str = [formatter stringFromDate:[NSDate date]];
        
        if (UIImagePNGRepresentation(_imageView.image)) {
            //返回为png图像。
            data = UIImagePNGRepresentation(_imageView.image);
            fileName = [NSString stringWithFormat:@"%@.png", str];
        }else {
            //返回为JPEG图像。
            data = UIImageJPEGRepresentation(_imageView.image, 1.0);
          fileName = [NSString stringWithFormat:@"%@.jpg", str];
        }
        
        [formData appendPartWithFileData:data name:@"files[]" fileName:fileName mimeType:@"image/jpg/png/jpeg"];
        
    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
        [[DataFormatterSingle shareCore]endIgnoring];
        _PeopleMessageReloadDataBlock();
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:[responseObject objectForKey:@"info"]];
        });
        [self.navigationController popViewControllerAnimated:YES];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [[DataFormatterSingle shareCore]endIgnoring];
        NSLog(@"-------:%@",[error localizedDescription]);
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"上传失败"];
        });
    }];
}
- (void)upload
{
    NSString *str= [NSString stringWithFormat:@"http://%@/Mobile/MessageBack.html?message_id=%@&token=%@",IPAddress,message.id,[[DataFormatterSingle shareCore]getInfoToken]];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:str] cachePolicy:0 timeoutInterval:5.0f];
    
    [self setRequest:request];
    
    NSLog(@"开始上传...");
    [NSURLConnection sendAsynchronousRequest:request queue:[[NSOperationQueue alloc] init] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
        NSDictionary *resDict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        NSLog(@"Result--%@", [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding]);
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:[resDict objectForKey:@"info"]];
        });
        
    }];
}

- (void)setRequest:(NSMutableURLRequest *)request
{
    NSString *boundary = [NSString stringWithFormat:@"Boundary+%08X%08X", arc4random(), arc4random()];
    NSMutableData *body = [NSMutableData data];
    NSData *data;
    //判断图片是不是png格式的文件
    NSString *fileName;
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    // 设置时间格式
    formatter.dateFormat = @"yyyyMMddHHmmss";
    NSString *str = [formatter stringFromDate:[NSDate date]];
    
    if (UIImagePNGRepresentation(_imageView.image)) {
        //返回为png图像。
        data = UIImagePNGRepresentation(_imageView.image);
        fileName = [NSString stringWithFormat:@"%@.png", str];
    }else {
        //返回为JPEG图像。
        data = UIImageJPEGRepresentation(_imageView.image, 1.0);
        fileName = [NSString stringWithFormat:@"%@.jpg", str];
    }
    // 表单数据
    NSMutableDictionary *param = [[NSMutableDictionary alloc] init];
    [param setValue:_textView.text forKey:@"content"];
    [param setValue:data forKey:@"[file]"];
    
    /** 遍历字典将字典中的键值对转换成请求格式:
     --Boundary+72D4CD655314C423
     Content-Disposition: form-data; name="empId"
     
     254
     --Boundary+72D4CD655314C423
     Content-Disposition: form-data; name="shopId"
     
     18718
     */
    [param enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {
        NSMutableString *fieldStr = [NSMutableString string];
        [fieldStr appendString:[NSString stringWithFormat:@"--%@\r\n", boundary]];
        [fieldStr appendString:[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"\r\n\r\n", key]];
        [fieldStr appendString:[NSString stringWithFormat:@"%@", obj]];
        [body appendData:[fieldStr dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    }];
     NSLog(@"--param--:\n%@",param);
    
    /// 图片数据部分
    NSMutableString *topStr = [NSMutableString string];
//    NSString *path = [[NSBundle mainBundle] pathForResource:@"001.jpg" ofType:nil];
//    NSData *data = [NSData dataWithContentsOfFile:path];
    

    /**拼装成格式：
     --Boundary+72D4CD655314C423
     Content-Disposition: form-data; name="uploadFile"; filename="001.png"
     Content-Type:image/png
     Content-Transfer-Encoding: binary
     
     ... contents of boris.png ...
     */
    [topStr appendString:[NSString stringWithFormat:@"--%@\r\n", boundary]];
    [topStr appendString:[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"uploadFile\"; filename=\"%@\"\r\n",fileName]];
    [topStr appendString:@"Content-Type:image/png\r\n"];
    [topStr appendString:@"Content-Transfer-Encoding: binary\r\n\r\n"];
    [body appendData:[topStr dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:data];
    [body appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    
    // 结束部分
    NSString *bottomStr = [NSString stringWithFormat:@"--%@--", boundary];
    /**拼装成格式：
     --Boundary+72D4CD655314C423--
     */
    [body appendData:[bottomStr dataUsingEncoding:NSUTF8StringEncoding]];
    
    // 设置请求类型为post请求
    request.HTTPMethod = @"post";
    // 设置request的请求体
    request.HTTPBody = body;
    // 设置头部数据，标明上传数据总大小，用于服务器接收校验
    [request setValue:[NSString stringWithFormat:@"%ld", body.length] forHTTPHeaderField:@"Content-Length"];
    // 设置头部数据，指定了http post请求的编码方式为multipart/form-data（上传文件必须用这个）。
    [request setValue:[NSString stringWithFormat:@"multipart/form-data; boundary=%@",boundary] forHTTPHeaderField:@"Content-Type"];
    
   
    
}
- (void)textViewHiddenPanFrom:(UITapGestureRecognizer *)recognizer{
    
    [_textView resignFirstResponder];
}
-(void)getLeaveMessageModel:(LeaveMessageModel *)model block:(void(^)())peopleMessageBlock{
    message=model;
    _PeopleMessageReloadDataBlock=peopleMessageBlock;
}
-(void)initTextView{
    _textView.delegate=self;
    placeholder=[[UILabel alloc]init];
    placeholder.frame=CGRectMake(10, 2, 150, 20);
    placeholder.font=[UIFont systemFontOfSize:15.0];
    placeholder.textColor=[UIColor grayColor];
    placeholder.text=@"好想说点什么...";
    [_textView addSubview:placeholder];
}
-(void)initImageView{
    self.imageView.userInteractionEnabled=YES;
    self.imageView.image=[UIImage imageNamed:@"addImage.png"];
    UITapGestureRecognizer *panRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handlePanFromImageView:)];
    [self.imageView addGestureRecognizer:panRecognizer];//关键语句，给self.view添加一个手势监测；
    panRecognizer.numberOfTapsRequired = 1;
    panRecognizer.delegate = self;
}
- (void)handlePanFromImageView:(UITapGestureRecognizer *)recognizer{
    if (imageSelect) {
        UIStoryboard *sb=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
        DeleteLeaveImageController *view=(DeleteLeaveImageController *)[sb instantiateViewControllerWithIdentifier:@"DeleteLeaveImage"];
        [view setPreviewImage:self.imageView.image block:_cellDeleteImageBlock];
        [self.navigationController pushViewController:view animated:YES];
    }
    else{
        UIActionSheet *action=[[UIActionSheet alloc] initWithTitle:@"选取照片" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"从摄像头选取", @"从图片库选择",nil];
        [action showInView:self.view];
    }
    

}

#pragma mark <UIImagePick and sheet>
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:
            [self openCamera];
            break;
        case 1:
            [self openLibary];
            break;
        default:
            break;
    }
}
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [picker dismissViewControllerAnimated:YES completion:nil];
}
-(void)openCamera{
    //UIImagePickerControllerSourceType *type=UIImagePickerControllerSourceTypeCamera;
    if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
    {
        UIImagePickerController *picker=[[UIImagePickerController alloc] init];
        picker.delegate=self;
        picker.sourceType=UIImagePickerControllerSourceTypeCamera;
        picker.allowsEditing=YES;
        [self presentViewController:picker animated:YES completion:nil];
    }
}
-(void)openLibary{
    if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary])
    {
        UIImagePickerController *picker=[[UIImagePickerController alloc] init];
        picker.delegate=self;
        picker.sourceType=UIImagePickerControllerSourceTypePhotoLibrary;
        picker.allowsEditing=YES;
        [self presentViewController:picker animated:YES completion:nil];
    }
}
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    
    [picker dismissViewControllerAnimated:YES completion:^{
        __weak ReplayLeaveMessageController *replay=self;
        NSDictionary *dic=[[NSDictionary alloc]initWithDictionary:info];
        [replay selectImageView:dic];
    }];
    
    
    // [self saveImage:image withName:@""]
}
-(void)selectImageView:(NSDictionary *)info{
    UIImage *image=[info objectForKey:UIImagePickerControllerOriginalImage];
    self.imageView.image=image;
    imageSelect=YES;
    NSData *data;
    if (UIImagePNGRepresentation(image)) {
        //返回为png图像。
        data = UIImagePNGRepresentation(image);
    }else {
        //返回为JPEG图像。
        data = UIImageJPEGRepresentation(image, 0.5);
    }
    image=[UIImage imageWithData:data];
    
}
#pragma mark <UItextViewDelegate>
- (void)textViewDidBeginEditing:(UITextView *)textView {
    
    placeholder.hidden=YES;
}
- (void)textViewDidEndEditing:(UITextView *)textView {
    if (![textView.text length]) {
        placeholder.hidden=NO;
    }else{
        placeholder.hidden=YES;
    }
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
