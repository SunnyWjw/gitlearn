//
//  PlanManagerViewController.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/11.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "PlanManagerViewController.h"
#import "PlanManagerModel.h"
#import "AFNetworking.h"
#import "LineProjectTableController.h"
@interface PlanManagerViewController (){
    BOOL ListTable;

}

@end

@implementation PlanManagerViewController
@synthesize table_view,array;
- (void)viewDidLoad {
    [super viewDidLoad];
    table_view.delegate=self;
    table_view.dataSource=self;
    self.navigationItem.title=@"进度管理";
   // dispatch_async(dispatch_get_global_queue(0, 0), ^{
        [self getPlanManagerData];
   // });
    //去掉底部多余的cell
    [table_view setTableFooterView:[[UIView alloc] initWithFrame:CGRectZero]];
}
-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
}
-(void)getTokenModel:(BOOL)listTable report:(BOOL)reportStartForms reportend:(BOOL)reportEndForms{
    ListTable=listTable;

}
-(void)getPlanManagerData{
    NSString *str= [NSString stringWithFormat:@"http://%@/Mobile/ProjectTypeList",IPAddress];
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:str parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        //NSLog(@"--%@",[operation responseString]);
        NSNumber *status=[responseObject objectForKey:@"status"];
        if ([status intValue]==1){
            array=[NSMutableArray new];
            NSArray *arrays=[responseObject objectForKey:@"data"];
            for(NSDictionary *dic in arrays){
                PlanManagerModel *planManager=[[PlanManagerModel alloc]init];
                [planManager setValuesForKeysWithDictionary:dic];
                [array addObject:planManager];
            }
            [table_view reloadData];
        }else{
            [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:[responseObject objectForKey:@"info"]];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"error*___%@",[error localizedDescription]);
        [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"网络错误"];
    }];
}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    // Return the number of rows in the section.
    return [array count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellId=@"PeopleMessageCell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    PlanManagerModel *planmodel=[array objectAtIndex:indexPath.row];
    cell.textLabel.text=planmodel.text;
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    UIStoryboard *sb=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    PlanManagerModel *planmodel=[array objectAtIndex:indexPath.row];
    switch (indexPath.row) {
        case 0:
        {
            LineProjectTableController *view=(LineProjectTableController *)[sb instantiateViewControllerWithIdentifier:@"LineProject"];
            [view getPeopleToken:planmodel listbool:ListTable report:NO report:NO];
            [self.navigationController pushViewController:view animated:YES];
        }
            break;
        case 1:
        {
            LineProjectTableController *view=(LineProjectTableController *)[sb instantiateViewControllerWithIdentifier:@"LineProject"];
            [view getPeopleToken:planmodel listbool:ListTable report:NO report:NO];
            [self.navigationController pushViewController:view animated:YES];
        }
            break;
        case 2:
        {
            LineProjectTableController *view=(LineProjectTableController *)[sb instantiateViewControllerWithIdentifier:@"LineProject"];
            [view getPeopleToken:planmodel listbool:ListTable report:NO report:NO];
            [self.navigationController pushViewController:view animated:YES];
        }
            break;
        default:
            break;
    }
    
    
}
//定义header
//- (UIView *) tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
//
//}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 40;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
