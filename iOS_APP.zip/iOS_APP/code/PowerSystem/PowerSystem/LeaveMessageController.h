//
//  LeaveMessageController.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/17.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LeaveMessageController : UITableViewController<UIActionSheetDelegate>

@property (nonatomic,strong)NSArray *headNames;
@property (nonatomic,strong)NSMutableArray *ModelArrays;

@property (nonatomic,strong)NSMutableArray *todayArrays;
@property (nonatomic,strong)NSMutableArray *oneWeekArrays;
@property (nonatomic,strong)NSMutableArray *oldOneWeekArrays;

@property (nonatomic,copy)void(^blockReloadData)();

@end
