//
//  AppDelegate.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/10.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "AppDelegate.h"
#import "APService.h"
#import "MMCImageController.h"
#import "ViewController.h"
#import <AudioToolbox/AudioToolbox.h>
#import "WainingTableViewController.h"
@interface AppDelegate (){
    UIAlertView *notifiAlert;
    BOOL alertShow;
}

@end
static SystemSoundID shake_sound_male_id = 1007;
@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    [NSThread sleepForTimeInterval:2.0];
    alertShow=NO;
    self.noti=NO;
    NSDictionary *dictt=[launchOptions objectForKey:UIApplicationLaunchOptionsRemoteNotificationKey];
    if (dictt) {
        self.noti=YES;
    }
    // Required
#if __IPHONE_OS_VERSION_MAX_ALLOWED > __IPHONE_7_1
        if ([[UIDevice currentDevice].systemVersion floatValue] >= 8.0) {
            //categories
            [APService
             registerForRemoteNotificationTypes:(UIUserNotificationTypeBadge |
                                                 UIUserNotificationTypeSound |
                                                 UIUserNotificationTypeAlert)
             categories:nil];
        } else {
            //categories nil
            [APService
             registerForRemoteNotificationTypes:(UIRemoteNotificationTypeBadge |
                                                 UIRemoteNotificationTypeSound |
                                                 UIRemoteNotificationTypeAlert)
#else
             //categories nil
             categories:nil];
            [APService
             registerForRemoteNotificationTypes:(UIRemoteNotificationTypeBadge |
                                                 UIRemoteNotificationTypeSound |
                                                 UIRemoteNotificationTypeAlert)
#endif
             // Required
             categories:nil];
        }
    
   
    [APService setupWithOption:launchOptions];
//本地通知注册
//    [APService setLocalNotification:[NSDate dateWithTimeIntervalSinceNow:10]
//                          alertBody:@"收到应用内消息"
//                              badge:1
//                        alertAction:@"打开"
//                      identifierKey:@"notiKey"
//                           userInfo:nil
//                          soundName:nil
//                             region:nil
//                 regionTriggersOnce:YES
//                           category:nil];
//本地通知显示
//[APService showLocalNotificationAtFront:notification identifierKey:@"notiKey"];
    
    return YES;
}
- (void)JPReceivedMessage:(NSNotification *)noti
{
    //收到由极光服务器发送的推送消息（应用内消息--不通过APNS）
    NSLog(@"--收到应用内消息:%@",noti);
    //在这里将应用内消息通过极光SDK转换成本地通知

}
//- (NSUInteger)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window
//{
//    return UIInterfaceOrientationMaskPortrait;
//}

- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
    
    NSLog(@"regisger success:%@\n",deviceToken);
    [APService registerDeviceToken:deviceToken];
    
//注册成功，将deviceToken保存到应用服务器数据库中
//    AVInstallation *currentInstallation = [AVInstallation currentInstallation];
//    [currentInstallation setDeviceTokenFromData:deviceToken];
//    [currentInstallation saveInBackground];
}
- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void(^)(UIBackgroundFetchResult))completionHandler {

    NSLog(@"userinfo,userinfo,userinfo,userinfo:%@\n",userInfo);
    [APService handleRemoteNotification:userInfo];
    
    
    // 处理推送消息
    if (application.applicationState == UIApplicationStateActive) {
        
            AudioServicesPlaySystemSound(shake_sound_male_id);
            AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
        
            if (alertShow) {
                [notifiAlert dismissWithClickedButtonIndex:[notifiAlert cancelButtonIndex] animated:YES];
            }
            notifiAlert=[[UIAlertView alloc]initWithTitle:@"提示" message:@"有新的警告信息" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"查看", nil];
            alertShow=YES;
            [notifiAlert show];
        
    }
    else if (application.applicationState == UIApplicationStateInactive){
        
        
        if (self.noti) {
            [[NSNotificationCenter defaultCenter]postNotificationName:@"ViewController" object:nil];
            self.noti=NO;
            
        }else{
            //后台恢复前台
            
            [self backInActive];
        }
        
    }
   


    completionHandler(UIBackgroundFetchResultNewData);
}
#pragma mark --AlertDelegate
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    alertShow=NO;
    switch (buttonIndex) {
        case 0:
            
            break;
        case 1:
        {
            [self backInActive];
        }
            break;
        default:
            break;
    }
}
-(void)backInActive{
    RootNavViewController *rootView=(RootNavViewController*)self.window.rootViewController;
    if (![rootView.visibleViewController isKindOfClass:[WainingTableViewController class]]) {
        [rootView popToViewController:[rootView.viewControllers objectAtIndex:1]  animated:NO];
        ViewController *view=(ViewController*)rootView.visibleViewController;
        [view pushWainingClick:nil];
    }
}
- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo{


}

//本地通知实现回调
- (void)application:(UIApplication *)application didReceiveLocalNotification:(UILocalNotification *)notification {
    
    


}
-(void)addDeviceToken:(NSData *)deviceToken{
    NSString *tokeStr = [NSString stringWithFormat:@"%@",deviceToken];
    if ([tokeStr length]==0) {
        return;
    }
    NSString *key=@"DeviceToken";
    NSString *oldToken= [[NSUserDefaults standardUserDefaults]objectForKey:key];
    //如果偏好设置中的已存储设备令牌和新获取的令牌不同则存储新令牌并且发送给服务器端
    if (![oldToken isEqualToString:tokeStr]) {
        [[NSUserDefaults standardUserDefaults] setObject:tokeStr forKey:key];
        [self sendDeviceTokenWidthOldDeviceToken:tokeStr newDeviceToken:deviceToken];
    }
}
-(void)sendDeviceTokenWidthOldDeviceToken:(NSString *)oldToken newDeviceToken:(NSData *)newToken{
    //    NSString *str=[NSString stringWithFormat:@"http://%@/Mobile/FileList",IPAddress];
    //    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    //    NSDictionary *parameter=@{@"token":tokeStr,@"appid":@"com.iyoungsun.PowerSystem"};
    //    [manager POST:str parameters:parameter success:^(AFHTTPRequestOperation *operation, id responseObject) {
    //        NSLog(@"--%@",[operation responseString]);
    //        NSNumber *status=[responseObject objectForKey:@"status"];
    //        if ([status intValue]==1){
    //
    //        }
    //        else{
    //            NSLog(@"regisger --- faild :%@",[responseObject objectForKey:@"info"]);
    //        }
    //    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
    //        NSLog(@"error*___%@",[error localizedDescription]);
    //        
    //    }];
}
- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error {
    NSLog(@"Registfail%@",error);
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    application.applicationIconBadgeNumber = 0;
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
