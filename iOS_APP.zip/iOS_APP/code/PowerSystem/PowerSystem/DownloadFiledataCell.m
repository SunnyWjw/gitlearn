//
//  DownloadFiledataCell.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/21.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "DownloadFiledataCell.h"

@implementation DownloadFiledataCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
