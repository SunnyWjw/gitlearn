//
//  MMCTableViewCellFrame.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/15.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MMCTableViewCellModel.h"
@interface MMCTableViewCellFrame : NSObject

@property(nonatomic,strong)MMCTableViewCellModel *weibo;
@end
