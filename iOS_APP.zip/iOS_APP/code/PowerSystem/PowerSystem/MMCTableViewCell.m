//
//  MMCTableViewCell.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/15.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "MMCTableViewCell.h"
#import "imageViewCell.h"
#import "UIImageView+MJWebCache.h"
#import "MJPhotoBrowser.h"
#import "MJPhoto.h"
@implementation MMCTableViewCell
@synthesize imgsArrayOne,ImCollArrayCell,imgsArrayName;
static NSString * const CollreuseIdentifier = @"Cell";
- (void)awakeFromNib {
    // Initialization code
}
-(void)getImagePathArray:(NSMutableArray *)image name:(NSMutableArray *)nameArray{
    imgsArrayOne=[NSMutableArray new];
    imgsArrayName=[NSMutableArray new];
    imgsArrayOne=image;
    imgsArrayName=nameArray;
    CGFloat height=([imgsArrayOne count]/4)*((kScreenW-3)/4);
    if ([imgsArrayOne count]%4>0) {
        height+=(kScreenW-3)/4;
    }
    if (([imgsArrayOne count]/4)<1) {
        height=(kScreenW-3)/4;
    }
    _CollectionViewOne.frame=CGRectMake(0, 0, kScreenW, height);
    [_CollectionViewOne reloadData];
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{

    self=[super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        NSLog(@"----NSString frame :%@",NSStringFromCGRect(self.frame));
        UICollectionViewFlowLayout *flowlayout=[[UICollectionViewFlowLayout alloc]init];
        _CollectionViewOne=[[UICollectionView alloc]initWithFrame:CGRectMake(0, 0, kScreenW, self.frame.size.height) collectionViewLayout:flowlayout];
        _CollectionViewOne.delegate=self;
        _CollectionViewOne.dataSource=self;
        _CollectionViewOne.tag=101;

        _CollectionViewOne.backgroundColor=STATICBACKCOLOR;
        [_CollectionViewOne registerClass:[imageViewCell class] forCellWithReuseIdentifier:CollreuseIdentifier];
        [self.contentView addSubview:_CollectionViewOne];
    }
    return self;
}
#pragma mark <UICollectionViewDataSource>
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}
//item个数
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return [imgsArrayOne count];
}
// The view that is returned must be retrieved from a call to -dequeueReusableSupplementaryViewOfKind:withReuseIdentifier:forIndexPath:
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section
{
    return CGSizeMake(0, 0);
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    
//    if ([imgsArrayOne count]==4) {
//        return CGSizeMake((collectionView.frame.size.width-2)/2, (collectionView.frame.size.width-2)/2);
//    }else if ([imgsArrayOne count]==1){
//        return CGSizeMake((collectionView.frame.size.width), (collectionView.frame.size.height));
//    }
    NSLog(@"size:%f----%f",(collectionView.frame.size.width-3)/4,(collectionView.frame.size.width-3)/4);
    return CGSizeMake((collectionView.frame.size.width-3)/4, (collectionView.frame.size.width-3)/4);
    
    
}
//定义每个UICollectionView 的 margin
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(0, 0, 0, 0);
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{
    
    return 1.0;
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return 1;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    UIImage *placeholder = [UIImage imageNamed:@"timeline_image_loading.png"];
    imageViewCell *cell = (imageViewCell*)[collectionView dequeueReusableCellWithReuseIdentifier:CollreuseIdentifier forIndexPath:indexPath];
    [cell.imageView setImageURLStr:[imgsArrayOne objectAtIndex:indexPath.row] placeholder:placeholder];
    cell.imageName.textColor=STATICBACKCOLOR;
    cell.imageName.text=[imgsArrayName objectAtIndex:indexPath.row];
    [ImCollArrayCell addObject:cell.imageView];
    cell.backgroundColor=[UIColor grayColor];
    return cell;
}
//选择了某个cell
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSMutableArray *photos = [NSMutableArray arrayWithCapacity:[imgsArrayOne count]];
    for (int i = 0; i<[imgsArrayOne count]; i++) {
        // 替换为中等尺寸图片
        NSString *url = [imgsArrayOne[i] stringByReplacingOccurrencesOfString:@"thumbnail" withString:@"bmiddle"];
        MJPhoto *photo = [[MJPhoto alloc] init];
        photo.url = [NSURL URLWithString:url]; // 图片路径
        photo.srcImageView = [ImCollArrayCell objectAtIndex:indexPath.row]; // 来源于哪个UIImageView
        [photos addObject:photo];
    }
    // 2.显示相册
    MJPhotoBrowser *browser = [[MJPhotoBrowser alloc] init:imgsArrayName];
    browser.currentPhotoIndex = indexPath.row; // 弹出相册时显示的第一张图片是？
    browser.photos = photos; // 设置所有的图片
    [browser show];
    
}
//取消选择了某个cell
- (void)collectionView:(UICollectionView *)collectionView didDeselectItemAtIndexPath:(NSIndexPath *)indexPath
{
    
}
-(BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    //不可点
    return YES;
}
@end
