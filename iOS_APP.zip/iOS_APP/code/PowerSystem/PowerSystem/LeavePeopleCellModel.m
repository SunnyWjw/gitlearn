//
//  LeavePeopleCellModel.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/18.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "LeavePeopleCellModel.h"

@implementation LeavePeopleCellModel

+ (instancetype)messageModelWithDict:(NSDictionary *)dict
{
    LeavePeopleCellModel *message = [[self alloc] init];
    message.user_id = dict[@"user_id"];
    message.user_name = dict[@"user_name"];
    message.content = dict[@"content"];
    message.image_list = dict[@"image_list"];
    message.time = dict[@"time"];
    message.is_self = [dict[@"is_self"] intValue];
    
    return message;
}
@end
