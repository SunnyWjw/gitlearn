//
//  WainingConnectController.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/20.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "WainingConnectController.h"
#import "WainingConnectModel.h"
#import "WainingXiangxiController.h"
@interface WainingConnectController ()
{
    WainingModel *wainModel;
    NSNumber* num;
    NSNumber *total;
    BOOL arrayCount;
}
@end

@implementation WainingConnectController
@synthesize array;
- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title=wainModel.text;
    [self.tableView setTableFooterView:[[UIView alloc] initWithFrame:CGRectZero]];
    num=@1;
    __weak WainingConnectController *Waining=self;
    _blockReloadData=^(){
       // dispatch_async(dispatch_get_global_queue(0, 0), ^{
            [Waining getConnectData];
       // });
    };
    
    array=[NSMutableArray new];
//上拉加载
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
       
        [self getConnectData];
        arrayCount=YES;
        while (arrayCount) {
            
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            
            __weak UITableView *tableView = self.tableView;
         
                tableView.footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
                    int page=[num intValue];
                    page++;
                    
                    int sizeMax=0;
                    if ([total intValue]%30>0) {
                        sizeMax=[total intValue]/30+1;
                    }else{
                        sizeMax=[total intValue]/30;
                    }
                    if (page > sizeMax) {
                        [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"没有更多数据"];
                        [tableView.footer endRefreshing];
                        return ;
                    }
                    num=[NSNumber numberWithInt:page];
                    [self getConnectData];
                    [tableView.footer endRefreshing];
                    [tableView reloadData];
                }];
            [tableView reloadData];
        });
    });
}
-(void)getWainingModel:(WainingModel *)model block:(void(^)())dateBlock{
    wainModel=model;
    _blockWainingReloadData=dateBlock;
}

-(void)getConnectData{
    NSString *str=[NSString stringWithFormat:@"http://%@/Mobile/AlertList",IPAddress];
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    
    NSNumber* number=@30;
    NSDictionary *parameter=@{@"type":wainModel.value,@"token":[[DataFormatterSingle shareCore]getInfoToken],@"page":num,@"page_size":number};
    [manager GET:str parameters:parameter success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"--%@",[operation responseString]);
        NSNumber *status=[responseObject objectForKey:@"status"];
        if ([status intValue]==1){
            
            NSDictionary *dict=[responseObject objectForKey:@"data"];
            total=[dict objectForKey:@"total"];
            NSArray *arrays=[dict objectForKey:@"list"];
            for(NSDictionary *dic in arrays){
                WainingConnectModel *model=[WainingConnectModel rewriteModel:dic];
                [array addObject:model];
            }
            [self.tableView reloadData];
            arrayCount=NO;
        }
        else{
            arrayCount=NO;
            [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:[responseObject objectForKey:@"info"]];
            //[self.navigationController popViewControllerAnimated:YES];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"error*___%@",[error localizedDescription]);
        [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"网络错误"];
        arrayCount=NO;
    }];
}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [array count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellId=@"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    WainingConnectModel *model;
    if ([array count]>0) {
        model=[array objectAtIndex:indexPath.row];
    }
    cell.textLabel.textColor=[UIColor blackColor];
    
    
    if ([model.has_readStr intValue]==0) {
        
        cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    }else{
        cell.accessoryType=UITableViewCellAccessoryCheckmark;
    }
    
    cell.textLabel.text=model.contentStr;
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    WainingConnectModel *model=[array objectAtIndex:indexPath.row];
//配合上拉加载，取消回调刷新
    UITableViewCell *cell=(UITableViewCell*)[tableView cellForRowAtIndexPath:indexPath];
    cell.accessoryType=UITableViewCellAccessoryCheckmark;
    model.has_readStr=[NSNumber numberWithInt:1];

    UIStoryboard *sb=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    WainingXiangxiController *view=(WainingXiangxiController *)[sb instantiateViewControllerWithIdentifier:@"WainingXiangxi"];
    [view getXiangxiModel:model block:_blockReloadData blocker:_blockWainingReloadData];
    [self.navigationController pushViewController:view animated:YES];

}
//定义header
//- (UIView *) tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
//
//}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 40;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
