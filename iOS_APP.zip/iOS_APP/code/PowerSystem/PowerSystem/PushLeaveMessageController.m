//
//  PushLeaveMessageController.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/19.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "PushLeaveMessageController.h"
#import "imageViewCell.h"
#import "DeleteLeaveImageController.h"
@interface PushLeaveMessageController (){
    UICollectionView *_collectionView;
    UILabel *placeholder;
}

@end
static NSMutableArray *imagesArray;
static NSString * const CollreuseIdentifier = @"Cell";

@implementation PushLeaveMessageController
- (void)viewDidLoad {
    [super viewDidLoad];
    imagesArray=[NSMutableArray new];
    [self initCollectionView];
    [self initTextView];
    [self initTitleField];
    [self navRightButton];
    UITapGestureRecognizer *selfRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(texthandlePanFrom:)];
    selfRecognizer.numberOfTapsRequired = 1;
    selfRecognizer.delegate = self;
    [self.view addGestureRecognizer:selfRecognizer];
    
    __weak PushLeaveMessageController * push =self;
    _cellDeleteImageBlock=^(UIImage *image){
        if (imagesArray!=nil) {
            [imagesArray removeObject:image];
        }
        [push collectionViewReloadData];
    };
}
-(void)collectionViewReloadData{

    
    [_collectionView reloadData];
}
-(void)getLeaveMessageBlock:(void(^)())block{
    _blockReloadData=block;
}
-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
}
+(void) deleteSelectedImageWithImage:(UIImage*)image{

}

-(void)navRightButton{
    UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitle:@"发送" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(RightButtonPushMessage) forControlEvents:UIControlEventTouchUpInside];
    button.frame = CGRectMake(0, 0, 40, 40);
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.rightBarButtonItem = rightButton;
}
-(void)RightButtonPushMessage{
    if (![_textView.text length]) {
        [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"请填写留言内容"];
        return;
    }
    if (![_titleField.text length]) {
        [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"请填写留言标题"];
        return;
    }
    [[DataFormatterSingle shareCore]beginIgnoring];
    NSString *str= [NSString stringWithFormat:@"http://%@/Mobile/MessageAdd.html?token=%@",IPAddress,[[DataFormatterSingle shareCore]getInfoToken]];
    
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    NSDictionary *paramter=@{@"title":_titleField.text,@"content":_textView.text};
    [manager POST:str parameters:paramter constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        for (int i =0; i<[imagesArray count]; i++) {
            UIImage *imageView=[imagesArray objectAtIndex:i];
            NSData *data;
            //判断图片是不是png格式的文件
            NSString *fileName;
            NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
            // 设置时间格式
            formatter.dateFormat = @"yyyyMMddHHmmss";
            NSString *str = [formatter stringFromDate:[NSDate date]];
            
            if (UIImagePNGRepresentation(imageView)) {
                //返回为png图像。
                data = UIImagePNGRepresentation(imageView);
                fileName = [NSString stringWithFormat:@"%@.png", str];
            }else {
                //返回为JPEG图像。
                data = UIImageJPEGRepresentation(imageView, 1.0);
                fileName = [NSString stringWithFormat:@"%@.jpg", str];
            }

            
            [formData appendPartWithFileData:data name:@"files[]" fileName:fileName mimeType:@"image/jpg/png/jpeg"];
        }
    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
        [[DataFormatterSingle shareCore]endIgnoring];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:[responseObject objectForKey:@"info"]];
        });
        _blockReloadData();
        [self.navigationController popViewControllerAnimated:YES];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [[DataFormatterSingle shareCore]endIgnoring];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"上传失败"];
        });
        
    }];

}

- (void)texthandlePanFrom:(UITapGestureRecognizer *)recognizer{
    
    [_textView resignFirstResponder];
}

-(void)initTitleField{
    NSDate *date=[NSDate date];
    NSString *dateString=[[DataFormatterSingle shareCore]dateZhuanString:date];
    _timeField.text=dateString;
    _timeField.userInteractionEnabled=NO;
    
    _titleField.delegate=self;
}

-(void)initTextView{
    _textView.delegate=self;
    placeholder=[[UILabel alloc]init];
    placeholder.frame=CGRectMake(10, 2, 150, 20);
    placeholder.font=[UIFont systemFontOfSize:15.0];
    placeholder.textColor=[UIColor grayColor];
    placeholder.text=@"好想说点什么...";
    [_textView addSubview:placeholder];
}

-(void)initCollectionView{
    UICollectionViewFlowLayout *flowlayout=[[UICollectionViewFlowLayout alloc]init];
    if (IS_IPAD) {
            _collectionView=[[UICollectionView alloc]initWithFrame:CGRectMake(10, CGRectGetMaxY(self.textView.frame)+10, IPhone6PWidth-20, IPhone6PHeight-CGRectGetMaxY(self.textView.frame)-64-10) collectionViewLayout:flowlayout];
    }else{
            _collectionView=[[UICollectionView alloc]initWithFrame:CGRectMake(10, CGRectGetMaxY(self.textView.frame)+10, self.view.frame.size.width-20, self.view.frame.size.height-CGRectGetMaxY(self.textView.frame)-64-10) collectionViewLayout:flowlayout];
    }

    _collectionView.delegate=self;
    _collectionView.dataSource=self;
    _collectionView.tag=101;
    _collectionView.backgroundColor=[UIColor clearColor];
    [_collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:CollreuseIdentifier];
    [self.view addSubview:_collectionView];
}
#pragma mark <UItextFieldDelegate>
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

#pragma mark <UItextViewDelegate>
- (void)textViewDidBeginEditing:(UITextView *)textView {
    
    placeholder.hidden=YES;
}
- (void)textViewDidEndEditing:(UITextView *)textView {
    if (![textView.text length]) {
        placeholder.hidden=NO;
    }else{
        placeholder.hidden=YES;
    }
    
}

#pragma mark <UIImagePick and sheet>
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:
            [self openCamera];
            break;
        case 1:
            [self openLibary];
            break;
        default:
            break;
    }
}
- (UIImage *)image:(UIImage*)image byScalingToSize:(CGSize)targetSize {
    UIImage *sourceImage = image;
    UIImage *newImage = nil;
    
    UIGraphicsBeginImageContext(targetSize);
    
    CGRect thumbnailRect = CGRectZero;
    thumbnailRect.origin = CGPointZero;
    thumbnailRect.size.width  = targetSize.width;
    thumbnailRect.size.height = targetSize.height;
    
    [sourceImage drawInRect:thumbnailRect];
    
    newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return newImage ;
}
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    UIImage *image=[info objectForKey:UIImagePickerControllerOriginalImage];
    [picker dismissViewControllerAnimated:YES completion:^{
        __weak PushLeaveMessageController *push=self;
        NSDictionary *dic=[[NSDictionary alloc]initWithDictionary:info];
        [push selectImageView:dic];
    }];
    
    if (picker.sourceType == UIImagePickerControllerSourceTypeCamera)
    {
                UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil);
    }

    // [self saveImage:image withName:@""]
}
-(void)selectImageView:(NSDictionary *)info{
    UIImage *image=[info objectForKey:UIImagePickerControllerOriginalImage];
        NSData *data;
//        if (UIImagePNGRepresentation(image)) {
//            //返回为png图像。
//            data = UIImagePNGRepresentation(image);
//        }else {
//            //返回为JPEG图像。
//            data = UIImageJPEGRepresentation(image, 0.5);
//        }
        data = UIImageJPEGRepresentation(image, 0.2);
        image=[UIImage imageWithData:data];
        if(imagesArray ==nil)
        {
            imagesArray=[[NSMutableArray alloc] init];
        }
        [imagesArray addObject:image];
    
    [self collectionViewReloadData];
}
-(void)dealloc{

    imagesArray=NULL;
    
    _collectionView=NULL;
    
    placeholder=NULL;
    
    _cellImageButtonBlock=NULL;
}
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [picker dismissViewControllerAnimated:YES completion:nil];
}
-(void)openCamera{
    //UIImagePickerControllerSourceType *type=UIImagePickerControllerSourceTypeCamera;
    if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
    {
        UIImagePickerController *picker=[[UIImagePickerController alloc] init];
        picker.delegate=self;
        picker.sourceType=UIImagePickerControllerSourceTypeCamera;
        picker.allowsEditing=YES;
        [self presentViewController:picker animated:YES completion:nil];
    }
}
-(void)openLibary{
    if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary])
    {
        UIImagePickerController *picker=[[UIImagePickerController alloc] init];
        picker.delegate=self;
        picker.sourceType=UIImagePickerControllerSourceTypePhotoLibrary;
        picker.allowsEditing=YES;
        
        [self presentViewController:picker animated:YES completion:nil];
    }
}

#pragma mark <UICollectionViewDataSource>
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}
//item个数
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    if (imagesArray.count==0)
    {
        return 1;
    }
    else if (imagesArray.count<9)
    {
        return imagesArray.count+1;
    }
    return imagesArray.count;
}
// The view that is returned must be retrieved from a call to -dequeueReusableSupplementaryViewOfKind:withReuseIdentifier:forIndexPath:
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section
{
    return CGSizeMake(0, 0);
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    
//    if ([imagesArray count]==4||[imagesArray count]==2) {
//        return CGSizeMake((collectionView.frame.size.width-2)/2, (collectionView.frame.size.width-2)/2);
//    }
//    else if ([imagesArray count]==1){
//        return CGSizeMake((collectionView.frame.size.width), (collectionView.frame.size.height));
//    }
    return CGSizeMake((collectionView.frame.size.width-2)/3, (collectionView.frame.size.width-2)/3);
    
    
}
//定义每个UICollectionView 的 margin
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(0, 0, 0, 0);
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{
    
    return 1.0;
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return 1;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    //UIImage *placeholder = [UIImage imageNamed:@"timeline_image_loading.png"];
    UICollectionViewCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:CollreuseIdentifier forIndexPath:indexPath];
    

    UIButton *imageView=[[UIButton alloc] initWithFrame:CGRectMake(0, 0, (_collectionView.frame.size.width-2)/3, (_collectionView.frame.size.width-2)/3)];
    imageView.tag=indexPath.row;
    __weak PushLeaveMessageController *push=self;
    _cellImageButtonBlock=^(UIButton *sender){
        [push.titleField resignFirstResponder];
        [push.textView resignFirstResponder];
        if(sender.tag==imagesArray.count)
        {
            UIActionSheet *action=[[UIActionSheet alloc] initWithTitle:@"选取照片" delegate:push cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"拍照", @"从相册中选择",nil];
            [action showInView:push.view];
        }
        else{
            [push buttonClickpushImage:sender.tag];
        }
    };
    [imageView addTarget:self action:@selector(imageButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    
    if((imagesArray.count==0||indexPath.row==imagesArray.count))
    {
        [imageView setBackgroundImage:[UIImage imageNamed:@"addImage.png"] forState:UIControlStateNormal];
    }
    else{
        while ([cell.contentView.subviews lastObject] != nil) {
            [(UIView*)[cell.contentView.subviews lastObject] removeFromSuperview];
        }
     
        [imageView setBackgroundImage:imagesArray[indexPath.row] forState:UIControlStateNormal];
       
        
    }
    imageView.contentMode=UIViewContentModeScaleAspectFill;
    [cell.contentView addSubview:imageView];

    return cell;
}

-(void)imageButtonClick:(UIButton *)sender{
    
    _cellImageButtonBlock(sender);
}

-(void)buttonClickpushImage:(NSInteger)integer{
     NSLog(@"is block---");
    UIImage *image=imagesArray[integer];
    UIStoryboard *sb=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    DeleteLeaveImageController *view=(DeleteLeaveImageController *)[sb instantiateViewControllerWithIdentifier:@"DeleteLeaveImage"];
    [view setPreviewImage:image block:_cellDeleteImageBlock];
    [self.navigationController pushViewController:view animated:YES];
}

//选择了某个cell
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    
}
//取消选择了某个cell
- (void)collectionView:(UICollectionView *)collectionView didDeselectItemAtIndexPath:(NSIndexPath *)indexPath
{
    
}
-(BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    //不可点
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
