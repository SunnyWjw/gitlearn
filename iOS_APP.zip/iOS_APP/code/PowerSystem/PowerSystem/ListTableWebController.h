//
//  ListTableWebController.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/17.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LineProjectModel.h"
@interface ListTableWebController : UIViewController<NSURLConnectionDelegate,NSURLConnectionDataDelegate,UIWebViewDelegate,UIAccelerometerDelegate>

@property (weak, nonatomic) IBOutlet UIWebView *web_view;

-(void)getExcelNumber:(int)number;
-(void)getProjectId:(LineProjectModel *)model;
@end
