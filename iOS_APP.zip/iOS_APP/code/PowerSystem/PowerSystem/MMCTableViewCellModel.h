//
//  MMCTableViewCellModel.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/15.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MMCTableViewCellModel : NSObject
@property(nonatomic,copy)NSMutableArray *collectionImageArray;

+(MMCTableViewCellModel*)rewriteModel:(NSMutableArray *)dict;
-(MMCTableViewCellModel*)initWithDict:(NSMutableArray *)dict;
@end
