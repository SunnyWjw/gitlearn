//
//  DataFormatterSingle.h
//  JxbApp
//
//  Created by huhaifeng on 15/7/29.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DataFormatterSingle : NSObject{
    
}
typedef NS_ENUM(NSInteger, LineString){
    lineONE=0,
    lineTwo=1,
};
+(DataFormatterSingle*)shareCore;

-(void)portServeString:(NSString *)serve;
-(NSString *)getInfoPortServeString;

-(void)ServeString:(NSString *)serve;
-(NSString *)getInfoServeString;

-(void)PortString:(NSString *)serve;
-(NSString *)getInfoPortString;

-(void)remeberAccount:(NSString *)account;
-(NSString *)getInfoAccount;

-(void)remeberPassword:(NSString *)password;
-(NSString *)getInfoPassword;

-(void)remeberToken:(NSString *)password;
-(NSString *)getInfoToken;

-(void)removeAccounts;//删除帐号密码

-(void)remeberDiaoyongPassword:(NSString *)password;//用于后面调用
-(NSString *)getInfoDiaoyongPassword;

-(NSDate *)datedatedate:(NSString *)string;

-(NSString *)dateFormStrings:(NSDate *)date;//2015-05-26 16:00:00 +0000  -> 2015-05-26


-(NSString *)dateZhuanString:(NSDate *)date;//2015-05-26 16:00:00 +0000  -> 2015-05-26 12:00:00

-(NSString *)dateFormatter:(NSString *)str;//2010-07-08 -> 7月8日
-(NSString *)dateYearFormatter:(NSString *)str;//2010-07-08 -> 2010年7月8日

-(NSString *)dateformatterYY:(NSString *)str;
-(NSString *)dateformatterMM:(NSString *)str;//2010-07-08 -> 7  //2010-11-08 -> 11
-(NSString *)dateformatterDD:(NSString *)str;//2010-07-08 -> 8  //2010-11-18 -> 18

-(NSString *)weekFormatter:(NSNumber *)str;
-(NSString *)timeFormatter:(NSString *)str;

-(NSString *)boolForType:(NSString *)str; //abcd.png ---->   .png

-(BOOL)retrieveFileData:(NSString *)savePath Name:(NSString *)name; //查找沙盒中是否有该文件

-(void)beginIgnoring;

-(void)endIgnoring;
//通过计算时间间隔
-(int)timeInterval:(NSDate *)newDate olddata:(NSDate *)oldDate;

//字符串转Date
-(NSDate *)dateWithStrings:(NSString *)dateString;

-(int)returnDaysfrom :(NSString *)titlestring endstring:(NSString *)end_dateString startstring:(NSString *)start_dateString;
@end
