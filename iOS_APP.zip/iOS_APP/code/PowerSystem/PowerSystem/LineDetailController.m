//
//  LineDetailController.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/11.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "LineDetailController.h"
#import "AFNetworking.h"
#import "LineDetailTableCell.h"
#import "LineXiangxiModel.h"
#import "LineDetailCellFrame.h"
#import "LineDetailCellModel.h"
#import "ChildSexView.h"
#import "JSONKit.h"
@interface LineDetailController ()
{
    LineProjectModel*lineModel;
    int page;
    ChildSexView *ServerView;
    NSNumber *idNumber;
}
@end

@implementation LineDetailController
@synthesize table_view,xiangxiArray,projectEndDate,projectNme,projectPeopleName,projectStartDate,cellDataBlock,cellDateNumBlock,cellDateOkNumberBlock;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    page=0;
    table_view.dataSource=self;
    table_view.delegate=self;
    [self rightButton];
   // dispatch_async(dispatch_get_global_queue(0, 0), ^{
        [self getData];
   // });
    __weak UITableView *tableView = table_view;
    // 下拉刷新
    tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        //刷新数据
        //dispatch_async(dispatch_get_global_queue(0, 0), ^{
            [self getData];
       // });
        // 模拟延迟加载数据，因此2秒后才调用（真实开发中，可以移除这段gcd代码）
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            // 结束刷新
            [tableView.header endRefreshing];
            [table_view reloadData];
        });
    }];
    


    
   __weak LineDetailController *linedetail=self;
    
    cellDataBlock=^{
        [linedetail getData];
        NSLog(@"----刷新");
    };
    
    //NSLog(@"----刷新:%@",[self dateCut:@"2015-07-21" num:10]);
//     NSLog(@"----刷新:%d",[[DataFormatterSingle shareCore]timeInterval:[[DataFormatterSingle shareCore]dateWithStrings:@"2015-07-20"] olddata:[[DataFormatterSingle shareCore]dateWithStrings:@"2015-06-21"]]);
    
}
-(void)rightButton{
    UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitle:@"提交" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(RightButtonPressed) forControlEvents:UIControlEventTouchUpInside];
    button.frame = CGRectMake(0, 0, 40, 40);
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.rightBarButtonItem = rightButton;
}
-(void)RightButtonPressed{
    NSString *str= [NSString stringWithFormat:@"http://%@/Mobile/ProjectNodeDateChange?token=%@",IPAddress,[[DataFormatterSingle shareCore] getInfoToken]];
    NSMutableArray *mutable=[NSMutableArray new];
    
    for (int i=0; i<[xiangxiArray count]; i++) {
        LineDetailCellFrame *reframe=[xiangxiArray objectAtIndex:i];
        NSDictionary *par=
                         @{
                           @"id":reframe.weibo.id,
                           @"plan_start_date":reframe.weibo.start_dateString,
                           @"plan_end_date":reframe.weibo.end_dateString,
                           @"complete_date":reframe.weibo.complete_date,
                           };
        [mutable addObject:par];
    }
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    NSDictionary *parameters = @{@"id":lineModel.id,@"node_list":mutable};
    NSString *jsonStr=[parameters JSONString];
    NSDictionary *parer = @{@"data":jsonStr};
    [manager POST:str parameters:parer success:^(AFHTTPRequestOperation *operation, id responseObject) {
        //NSLog(@"--%@",[operation responseString]);
    [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:[responseObject objectForKey:@"info"]];
        
    }
    failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"error*___%@",[error localizedDescription]);
        [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"网络错误"];
    }];
}
-(void)getProjectId:(LineProjectModel *)model{
    lineModel=model;
}
-(void)getData{
    //page ++;
    NSString *str= [NSString stringWithFormat:@"http://%@/Mobile/ProjectDetail?token=%@&project_id=%d",IPAddress,[[DataFormatterSingle shareCore] getInfoToken],[lineModel.id intValue]];
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:str parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"--%@",[operation responseString]);
        NSNumber *status=[responseObject objectForKey:@"status"];
        if ([status intValue]==1){
            xiangxiArray=[NSMutableArray new];
            NSDictionary *dict=[responseObject objectForKey:@"data"];
            NSArray *arrays=[dict objectForKey:@"node_list"];
            for(NSDictionary *dic in arrays){
                LineDetailCellFrame *reframe=[[LineDetailCellFrame alloc]init];
                reframe.weibo=[LineDetailCellModel rewriteModel:dic];
                [xiangxiArray addObject:reframe];
            }
            self.navigationItem.title=projectNme.text=[dict objectForKey:@"name"];
            projectPeopleName.text=[dict objectForKey:@"responsible_name"];
            projectStartDate.text=[dict objectForKey:@"start_date"];
            projectEndDate.text=[dict objectForKey:@"end_date"];
            [table_view reloadData];
            
        }else{
            [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:[responseObject objectForKey:@"info"]];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"error*___%@",[error localizedDescription]);
        [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"网络错误"];
    }];

}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    // Return the number of rows in the section.
    return [xiangxiArray count];
}
//CGSize weight = [str sizeWithAttributes:@{NSFontAttributeName:[UIFont fontWithName:@"Arial" size:17]}];

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    __weak LineDetailController *lineself=self;
    cellDateOkNumberBlock=^(int num){
        NSLog(@"que  ren  ---天数 :%d",num);
        [lineself querenTime:num index:(int)indexPath.row];
    };
    static NSString *cellId=@"Cell";
    LineDetailTableCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (cell == nil) {
        cell = [[LineDetailTableCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId block:cellDataBlock twoBlock:cellDateOkNumberBlock];
    }
//    else{
//        while ([cell.contentView.subviews lastObject] != nil) {
//            [(UIView *)[cell.contentView.subviews lastObject] removeFromSuperview];
//        }
//    }
    
    //去掉分隔线
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    //table_view.bounces=YES;
    
    LineDetailCellFrame *reframe=[xiangxiArray objectAtIndex:indexPath.row];
    cell=(id)[cell cellWithInformWeiboFrames:reframe];
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    //cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    LineDetailCellFrame *reframe=[xiangxiArray objectAtIndex:indexPath.row];
    //NSString *str=[NSString stringWithFormat:@"%@",reframe.weibo.complete_date];
    
    if(([reframe.weibo.projectTitleString hasPrefix:@"初步"]||
       [reframe.weibo.projectTitleString hasPrefix:@"初设"]||
       [reframe.weibo.projectTitleString hasPrefix:@"电"]||
       [reframe.weibo.projectTitleString hasPrefix:@"土建主"]||
       [reframe.weibo.projectTitleString hasPrefix:@"土建扫"]))
    {
        if (![reframe.weibo.complete_date length]) {
          __weak LineDetailController *lineself=self;
            cellDateNumBlock=^(int num){
                [lineself jisuanProjectTime:num index:(int)indexPath.row];
            };
            ServerView=[[ChildSexView alloc]initWithBlock:nil Type:ChildSexViewEditSlide];
            [ServerView getSliderViewModel:reframe block:cellDateNumBlock];
        }
        else
        {
        [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"此节点已完成"];
        }
        
        
    }else{
        [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"此节点不可压缩"];
    }

}

-(void)querenTime:(int)numdate index:(int)indexrow{
    //int yanchiNum=numdate;
    NSLog(@"-num-num---num-num:%d  index:%d ",numdate, indexrow);
    LineDetailCellFrame *reframe=[xiangxiArray objectAtIndex:indexrow];
    reframe.weibo.complete_date=[self dateCut:reframe.weibo.end_dateString num:numdate];
    NSString *jiedianString=reframe.weibo.complete_date;
    for(int i=indexrow+1;i<[xiangxiArray count];i++){
        LineDetailCellFrame *reframe=[xiangxiArray objectAtIndex:i];
        reframe.weibo.start_dateString=[self dateCut:jiedianString num:1];
        reframe.weibo.end_dateString=[self dateCut:reframe.weibo.end_dateString num:(numdate)];
        jiedianString=reframe.weibo.end_dateString;
    }
//    if (numdate>0) {//比计划时间延迟确认  //自动压缩
//
//        for(int i=indexrow+1;i<[xiangxiArray count];i++){
//            LineDetailCellFrame *reframe=[xiangxiArray objectAtIndex:i];
//            if (yanchiNum>0) {
//                int days= [[DataFormatterSingle shareCore]returnDaysfrom:reframe.weibo.projectTitleString endstring:reframe.weibo.end_dateString startstring:reframe.weibo.start_dateString];
//                
//                if (days==0) {
//                    reframe.weibo.start_dateString=[self dateCut:jiedianString num:1];
//                    reframe.weibo.end_dateString=[self dateCut:reframe.weibo.start_dateString num:([reframe.weibo.dateLabelString intValue])];
//                    jiedianString=reframe.weibo.end_dateString;
//                }
//                else
//                {
//                    reframe.weibo.start_dateString=[self dateCut:jiedianString num:1];
//                    if (yanchiNum-days>=0) {
//                        reframe.weibo.end_dateString=[self dateCut:reframe.weibo.start_dateString num:([reframe.weibo.dateLabelString intValue]-days)];
//                        yanchiNum-=days;
//                        jiedianString=reframe.weibo.end_dateString;
//                    }
//                    else
//                    {
//                        reframe.weibo.end_dateString=[self dateCut:reframe.weibo.start_dateString num:((numdate-yanchiNum)+[reframe.weibo.dateLabelString intValue])];
//                        yanchiNum=0;
//                        jiedianString=reframe.weibo.end_dateString;
//                    }
//                    
//                }
//
//            }
//            else
//            {
//                reframe.weibo.start_dateString=[self dateCut:jiedianString num:1];
//                reframe.weibo.end_dateString=[self dateCut:reframe.weibo.start_dateString num:([reframe.weibo.dateLabelString intValue])];
//                jiedianString=reframe.weibo.end_dateString;
//            }
//        }
//    }
//    else{
//        for(int i=indexrow+1;i<[xiangxiArray count];i++){
//            LineDetailCellFrame *reframe=[xiangxiArray objectAtIndex:i];
//            reframe.weibo.start_dateString=[self dateCut:jiedianString num:1];
//            reframe.weibo.end_dateString=[self dateCut:reframe.weibo.end_dateString num:(numdate)];
//            jiedianString=reframe.weibo.end_dateString;
//        }
//       
//    }
     [table_view reloadData];
}

-(void)jisuanProjectTime:(int)numdate index:(int )indexrow{
    numdate=-numdate;
    NSLog(@"-num-num---num-num:%d  index:%d ",numdate, indexrow);
    LineDetailCellFrame *reframe=[xiangxiArray objectAtIndex:indexrow];
    reframe.weibo.end_dateString=[self dateCut:reframe.weibo.end_dateString num:numdate];
    NSString *jiedianEndString=reframe.weibo.end_dateString;
    
    for(int i=indexrow+1;i<[xiangxiArray count];i++){
        LineDetailCellFrame *reframe=[xiangxiArray objectAtIndex:i];
        reframe.weibo.start_dateString=[self dateCut:jiedianEndString num:1];
        reframe.weibo.end_dateString=[self dateCut:reframe.weibo.end_dateString num:numdate];
        jiedianEndString=reframe.weibo.end_dateString;
    }
    [table_view reloadData];
}
//加剪天数
-(NSString *)dateCut:(NSString *)string num:(int)dateNum {
    NSDate *date=[[DataFormatterSingle shareCore]dateWithStrings:string];
    NSDateComponents *DateComponents = [[NSDateComponents alloc] init];
    DateComponents.weekday=(dateNum);
    NSDate *vDayShoppingDay = [[NSCalendar currentCalendar]
                               dateByAddingComponents:DateComponents
                               toDate:date
                               options:0];
    NSString *dateString= [[DataFormatterSingle shareCore]dateFormStrings:vDayShoppingDay];
    return dateString;
}
//加减天数
-(NSString *)dateCutdate:(NSString *)string num:(int)dateNum{
    NSDate *date=[[DataFormatterSingle shareCore]dateWithStrings:string];
    NSDate *newDate = [date dateByAddingTimeInterval:60 * 60 * 24 * (dateNum)];
    NSString *dateString= [[DataFormatterSingle shareCore]dateFormStrings:newDate];
    return dateString;
}
//定义header
//- (UIView *) tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
//
//}

//- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
//    return 0;
//}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    LineDetailCellFrame *reframe=[xiangxiArray objectAtIndex:indexPath.section];
    return reframe.maxHeight;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
