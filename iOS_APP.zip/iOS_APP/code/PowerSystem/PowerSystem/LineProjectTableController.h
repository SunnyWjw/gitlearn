//
//  LineProjectTableController.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/11.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "peopleMessageModel.h"
#import "PlanManagerModel.h"
@interface LineProjectTableController : UITableViewController


@property(nonatomic ,strong)NSMutableArray *LineMutableArray;
-(void)getPeopleToken:(PlanManagerModel *)lineModel listbool:(BOOL)listTable report:(BOOL)startReport report:(BOOL)endReport;
@end
