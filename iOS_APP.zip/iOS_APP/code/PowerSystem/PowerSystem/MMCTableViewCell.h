//
//  MMCTableViewCell.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/15.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MMCTableViewCell : UITableViewCell<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>
{
    UICollectionView *_CollectionViewOne;
}
@property(strong,nonatomic)NSMutableArray *imgsArrayOne;
@property(strong,nonatomic)NSMutableArray *imgsArrayName;
@property(strong,nonatomic)NSMutableArray *ImCollArrayCell;
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier;
-(void)getImagePathArray:(NSMutableArray *)image name:(NSMutableArray *)nameArray;
@end
