//
//  PushLeaveMessageController.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/19.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PushLeaveMessageController : UIViewController<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,UITextViewDelegate,UITextFieldDelegate,UIGestureRecognizerDelegate,UIActionSheetDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate>

@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UITextField *timeField;
@property (weak, nonatomic) IBOutlet UITextField *titleField;
@property (weak, nonatomic) IBOutlet UITextView *textView;

@property (nonatomic,copy)void(^blockReloadData)();
@property (nonatomic,copy) void(^cellDeleteImageBlock)(UIImage *image);
@property (nonatomic,copy) void(^cellImageButtonBlock)(UIButton *sender);

+(void) deleteSelectedImageWithImage:(UIImage*)image;

-(void)getLeaveMessageBlock:(void(^)())block;

@end
