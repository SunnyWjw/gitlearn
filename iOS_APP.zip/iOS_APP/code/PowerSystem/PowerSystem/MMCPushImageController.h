//
//  MMCPushImageController.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/17.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ImageCellModel.h"
#import "LineProjectModel.h"
@interface MMCPushImageController : UIViewController<UITextFieldDelegate,UIGestureRecognizerDelegate>

-(void)getPushImage:(UIImage *)image model:(LineProjectModel *)imageCellmodel style:(LineString )lineStyle;
@end
