//
//  LineXiangxiModel.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/11.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LineXiangxiModel : NSObject
@property(nonatomic,copy)NSNumber *id;
@property(nonatomic,copy)NSNumber *sort;
@property(nonatomic,copy)NSString *important_point;
@property(nonatomic,copy)NSString *cycle;
@property(nonatomic,copy)NSString *plan_start_date;
@property(nonatomic,copy)NSString *plan_end_date;
@property(nonatomic,copy)NSString *complete_date;
@property(nonatomic,copy)NSString *complete_std;
@property(nonatomic,copy)NSNumber *responsible;
@property(nonatomic,copy)NSString *responsible_name;
@property(nonatomic,copy)NSNumber *remind;
@property(nonatomic,assign)BOOL is_complete;
@property(nonatomic,copy)NSString *confirm_date;
@end
