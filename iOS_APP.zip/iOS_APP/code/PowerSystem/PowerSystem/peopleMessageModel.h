//
//  peopleMessageModel.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/10.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface peopleMessageModel : NSObject
@property(nonatomic,copy)NSString *token;
@property(nonatomic,copy)NSString *expires_in;
@property(nonatomic,copy)NSString *expires_date;
@property(nonatomic,copy)NSString *type;
@property(nonatomic,copy)NSString *type_name;
@property(nonatomic,copy)NSString *login_name;
@property(nonatomic,copy)NSString *avatar;
@end
