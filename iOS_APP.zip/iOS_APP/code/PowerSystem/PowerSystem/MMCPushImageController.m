//
//  MMCPushImageController.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/17.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "MMCPushImageController.h"
#import "MJPhotoBrowser.h"
#import "MJPhoto.h"
#import "SJAvatarBrowser.h"
#import "AFNetworking.h"

@interface MMCPushImageController (){
    UIImageView *imageView;
    UITextField *textFielder;
    NSMutableArray *array;
    BOOL keyBoard;
    UIImage *pushImage;
    LineProjectModel *model;
    NSString *typeStr;
    LineString typee;
}

@end

@implementation MMCPushImageController

- (void)viewDidLoad {
    [super viewDidLoad];
    keyBoard=NO;
    
    self.navigationItem.title=@"编辑";
    // Do any additional setup after loading the view.
    [self initImageView];
    [self initTextField];
    [self navRightButton];
    [self hiddenKeyBoard];
    array=[NSMutableArray new];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillChangeFrame:) name:UIKeyboardDidShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardDidChangeFrame:) name:UIKeyboardWillHideNotification object:nil];
}
-(void)getPushImage:(UIImage *)image model:(LineProjectModel *)imageCellmodel style:(LineString )lineStyle{
    pushImage=image;
    model=imageCellmodel;
    typee=lineStyle;
    if (typee==lineONE) {
        typeStr=@"line";
    }else if (typee==lineTwo){
        typeStr=@"electric";
    }else{
        typeStr=@"soil";
    }
}
-(void)hiddenKeyBoard{
    UITapGestureRecognizer *panRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handlePanFromHiddenKeyBoard:)];
    [self.view addGestureRecognizer:panRecognizer];//关键语句，给self.view添加一个手势监测；
    panRecognizer.numberOfTapsRequired = 1;
    panRecognizer.delegate = self;

}
- (void)handlePanFromHiddenKeyBoard:(UITapGestureRecognizer *)recognizer{
    [textFielder resignFirstResponder];
}
-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
-(void)initImageView{
    imageView=[[UIImageView alloc]init];
    imageView.frame=CGRectMake(20, 10, kScreenW-40, kScreenH/2);
    imageView.userInteractionEnabled=YES;
    imageView.image=pushImage;
    UITapGestureRecognizer *panRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handlePanFromBigImage:)];
    [imageView addGestureRecognizer:panRecognizer];//关键语句，给self.view添加一个手势监测；
    panRecognizer.numberOfTapsRequired = 1;
    panRecognizer.delegate = self;
    [self.view addSubview:imageView];
}
-(void)initTextField{
    textFielder=[[UITextField alloc]init];
    textFielder.borderStyle=UITextBorderStyleRoundedRect;
    textFielder.placeholder=@"请输入名称...";
    textFielder.delegate=self;
    textFielder.frame=CGRectMake(20, CGRectGetMaxY(imageView.frame)+10, kScreenW-40, 30);
    [self.view addSubview:textFielder];
}
-(void)navRightButton{
    UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitle:@"上传" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(RightButtonPushImage) forControlEvents:UIControlEventTouchUpInside];
    button.frame = CGRectMake(0, 0, 40, 40);
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.rightBarButtonItem = rightButton;
}
- (void)handlePanFromBigImage:(UITapGestureRecognizer *)recognizer{
    if (!keyBoard) {
        [SJAvatarBrowser showImage:(UIImageView*)recognizer.view];
    }else{
        [textFielder resignFirstResponder];
    }
   
}
-(void)RightButtonPushImage{
    if (keyBoard) {
        [textFielder resignFirstResponder];
    }
 //   [self upload];
    if (![textFielder.text length]) {
        [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"请输入描述名"];
        return;
    }
    [[DataFormatterSingle shareCore]beginIgnoring];
    NSString *str= [NSString stringWithFormat:@"http://%@/Mobile/MediaUpload.html?token=%@&name=%@&type=%@&project_id=%d",IPAddress,[[DataFormatterSingle shareCore]getInfoToken ],textFielder.text,typeStr,[model.id intValue]];
    NSString *strurl=[str stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager POST:strurl parameters:nil constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        NSData *data;
        //判断图片是不是png格式的文件
        NSString *fileName;
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        // 设置时间格式
        formatter.dateFormat = @"yyyyMMddHHmmss";
        NSString *str = [formatter stringFromDate:[NSDate date]];
        data = UIImageJPEGRepresentation(imageView.image, 0.2);
        fileName = [NSString stringWithFormat:@"%@.jpg", str];
//        if (UIImagePNGRepresentation(imageView.image)) {
//            //返回为png图像。
//            data = UIImagePNGRepresentation(imageView.image);
//            fileName = [NSString stringWithFormat:@"%@.png", str];
//        }else {
//            //返回为JPEG图像。
//            data = UIImageJPEGRepresentation(imageView.image, 1.0);
//            fileName = [NSString stringWithFormat:@"%@.jpg", str];
//        }

        
        [formData appendPartWithFileData:data name:@"file" fileName:fileName mimeType:@"image/jpg/png/jpeg"];
        
    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
        [[DataFormatterSingle shareCore]endIgnoring];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:[responseObject objectForKey:@"info"]];
            [self navLeftPopView];
        });

    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"-------:%@",[error localizedDescription]);
        [[DataFormatterSingle shareCore]endIgnoring];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"上传失败"];
        });
    }];
    
}
-(void)navLeftPopView{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark - UITextfield delegate
CGFloat yOffset;
CGFloat keyboardOfset;

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
- (void)keyboardDidChangeFrame:(NSNotification *)notification{
    NSDictionary *info = [notification userInfo];
    CGFloat duration = [[info objectForKey:UIKeyboardAnimationDurationUserInfoKey] floatValue];
    
    keyBoard=NO;
    [UIView animateWithDuration:duration animations:^{
        textFielder.frame=CGRectMake(20, CGRectGetMaxY(imageView.frame)+10, kScreenW-40, 30);
    }];
}

- (void)keyboardWillChangeFrame:(NSNotification *)notification
{

    NSDictionary *info = [notification userInfo];
    CGFloat duration = [[info objectForKey:UIKeyboardAnimationDurationUserInfoKey] floatValue];
    //CGRect beginKeyboardRect = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue];
    CGRect endKeyboardRect = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue];
    keyBoard=YES;
    CGRect inputFieldRect = textFielder.frame;
    inputFieldRect.origin.y=endKeyboardRect.origin.y-textFielder.frame.size.height-64;
    [UIView animateWithDuration:duration animations:^{
        textFielder.frame = inputFieldRect;
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
