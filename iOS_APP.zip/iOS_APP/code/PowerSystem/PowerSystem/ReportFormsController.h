//
//  ReportFormsController.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/17.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ReportFormsController : UIViewController

- (IBAction)chartButtonClick:(id)sender;
- (IBAction)excelPlanClick:(id)sender;
- (IBAction)actualClick:(id)sender;
@end
