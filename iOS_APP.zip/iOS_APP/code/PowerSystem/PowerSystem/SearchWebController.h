//
//  SearchWebController.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/18.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SearchFileModel.h"
@interface SearchWebController : UIViewController<UIWebViewDelegate,UIAlertViewDelegate>

@property (weak, nonatomic) IBOutlet UIWebView *web_view;

-(void)getWebUrl:(NSString *)url model:(SearchFileModel *)fileModel;
@end
