//
//  DeleteLeaveImageController.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/19.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "DeleteLeaveImageController.h"
#import "SJAvatarBrowser.h"
#import "PushLeaveMessageController.h"
@interface DeleteLeaveImageController ()
{
    UIImage *ImageView;
    UIImageView *backview;
}
@end

@implementation DeleteLeaveImageController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initImageView];
    [self navRightButton];
    self.view.backgroundColor=STATICBACKCOLOR;
}

-(void)setPreviewImage:(UIImage *)image block:(void(^)(UIImage *image))Block{
    
    ImageView=image;
    _cellDeleteImageBlock=Block;
}
-(void)navRightButton{
    UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitle:@"删除" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(RightButtonDeleteMessage) forControlEvents:UIControlEventTouchUpInside];
    button.frame = CGRectMake(0, 0, 40, 40);
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.rightBarButtonItem = rightButton;
}
-(void)RightButtonDeleteMessage{
    UIActionSheet *myActionSheet = [[UIActionSheet alloc]
                                    initWithTitle:@"要删除这张照片吗?"
                                    delegate:self
                                    cancelButtonTitle:@"取消"
                                    destructiveButtonTitle:nil
                                    otherButtonTitles:@"确定",nil];
    [myActionSheet showInView:self.view];
}
-(void)initImageView{
    backview=[[UIImageView alloc]init];
    backview.image=ImageView;
    backview.frame=CGRectMake(0,([UIScreen mainScreen].bounds.size.height-ImageView.size.height*[UIScreen mainScreen].bounds.size.width/ImageView.size.width)/2-self.navigationController.navigationBar.frame.size.height, [UIScreen mainScreen].bounds.size.width, ImageView.size.height*[UIScreen mainScreen].bounds.size.width/ImageView.size.width);
    [self.view addSubview:backview];
}
#pragma mark - SheetView
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(buttonIndex==actionSheet.cancelButtonIndex)
    {
        return;
    }
    else
    {
        _cellDeleteImageBlock(ImageView);
        [self.navigationController popViewControllerAnimated:YES];
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
