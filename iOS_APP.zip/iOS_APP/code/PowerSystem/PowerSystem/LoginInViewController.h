//
//  LoginInViewController.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/10.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface LoginInViewController : UIViewController<UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UIImageView *headerImageView;
@property (weak, nonatomic) IBOutlet UILabel *accountLabel;
@property (weak, nonatomic) IBOutlet UILabel *passwordLabel;
@property (weak, nonatomic) IBOutlet UITextField *accountTextfield;
@property (weak, nonatomic) IBOutlet UITextField *passwordTextField;
@property (weak, nonatomic) IBOutlet UILabel *remeberPasswordLabel;
@property (weak, nonatomic) IBOutlet UIButton *loginButton;
@property (weak, nonatomic) IBOutlet UIButton *remeberPassButton;
@property (assign) BOOL remeberPass;

- (IBAction)LoginPower:(id)sender;
- (IBAction)configServer:(id)sender;
- (IBAction)remeberPassClick:(id)sender;


@property (nonatomic,copy) void(^ServerBlock)(NSString *ServerString,NSString *two,NSString *three);
@end
