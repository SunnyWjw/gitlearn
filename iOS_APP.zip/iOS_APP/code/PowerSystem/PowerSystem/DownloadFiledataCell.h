//
//  DownloadFiledataCell.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/21.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DownloadFiledataCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *DownImage;
@property (weak, nonatomic) IBOutlet UILabel *DownName;
@property (weak, nonatomic) IBOutlet UIProgressView *DownProgress;
@property (weak, nonatomic) IBOutlet UIButton *DownButton;
@property (weak, nonatomic) IBOutlet UILabel *styleLabel;
@end
