//
//  LineDetailCellModel.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/12.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "LineDetailCellModel.h"

@implementation LineDetailCellModel
+(LineDetailCellModel*)rewriteModel:(NSDictionary *)dict{
    return [[self alloc]initWithDict:dict];
}
-(LineDetailCellModel*)initWithDict:(NSDictionary *)dict{
    if (self==[super init]) {
        self.id=[dict objectForKey:@"id"];
        
        self.sort=[dict objectForKey:@"sort"];
        
        if ((NSNull *)[dict objectForKey:@"important_point"] == [NSNull null]) {
            self.projectTitleString=@"";
        }else{
            self.projectTitleString=[dict objectForKey:@"important_point"];
        }
        
        self.dateLabelString=[dict objectForKey:@"cycle"];
        
        self.start_dateString=[dict objectForKey:@"plan_start_date"];
        
        self.end_dateString=[dict objectForKey:@"plan_end_date"];
        
        if ((NSNull *)[dict objectForKey:@"complete_date"] == [NSNull null]) {
            self.complete_date=@"";
        }else{
            self.complete_date=[dict objectForKey:@"complete_date"];
        }
        
        if ((NSNull *)[dict objectForKey:@"complete_std"] == [NSNull null]) {
            self.complete_stdString=@"";
        }else{
            self.complete_stdString=[dict objectForKey:@"complete_std"];
        }
        
        self.responsible=[dict objectForKey:@"responsible"];
        
        if ((NSNull *)[dict objectForKey:@"responsible_name"] == [NSNull null]) {
            self.responNameLabelString=@"";
        }else{
            self.responNameLabelString=[dict objectForKey:@"responsible_name"];
        }
        
        self.remind=[dict objectForKey:@"remind"];
        
        self.is_complete =[dict objectForKey:@"is_complete"];
        
        self.confirm_date=[dict objectForKey:@"confirm_date"];
        
        
        


        
        
        
        
        

        
        
    
    }
    return self;
}

@end
