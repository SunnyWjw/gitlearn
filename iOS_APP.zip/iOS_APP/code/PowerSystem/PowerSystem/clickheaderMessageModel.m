//
//  clickheaderMessageModel.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/10.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "clickheaderMessageModel.h"

@implementation clickheaderMessageModel

@end
