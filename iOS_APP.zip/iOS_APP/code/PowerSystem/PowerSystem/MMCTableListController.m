//
//  MMCTableListController.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/15.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "MMCTableListController.h"
#import "LineProjectTableCell.h"
#import "LineProjectModel.h"
#import "AFNetworking.h"
#import "MMCImageController.h"
@interface MMCTableListController ()
{
    NSString * indexRowValue;
}
@end

@implementation MMCTableListController
@synthesize LineMutableArray,statye;
- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView setTableFooterView:[[UIView alloc] initWithFrame:CGRectZero]];
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    self.navigationItem.title=@"项目列表";
   // dispatch_async(dispatch_get_global_queue(0, 0), ^{
        [self getProjectData];
   // });
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)getindex:(int )indexrow{
    if (indexrow==1) {
        indexRowValue=@"substation_extend,substation_new";
        statye=lineTwo;
    }
    else if (indexrow==2)
    {
        indexRowValue=@"substation_extend,substation_new";
        statye=-1;
    }
    else
    {
        indexRowValue=@"line_project";
        statye=lineONE;
    }
}
-(void)getProjectData{
    NSString *str= [NSString stringWithFormat:@"http://%@/Mobile/ProjectList?proj_type=%@&token=%@&page=%d&page_size=%d",IPAddress,indexRowValue,[[DataFormatterSingle shareCore] getInfoToken],0,10];
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:str parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        //NSLog(@"--%@",[operation responseString]);
        NSNumber *status=[responseObject objectForKey:@"status"];
        if ([status intValue]==1){
            LineMutableArray =[NSMutableArray new];
            NSArray *arrays=[responseObject objectForKey:@"data"];
            for(NSDictionary *dic in arrays){
                LineProjectModel *lineModel=[[LineProjectModel alloc]init];
                [lineModel setValuesForKeysWithDictionary:dic];
                [LineMutableArray addObject:lineModel];
            }
            [self.tableView reloadData];
        }else{
            [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:[responseObject objectForKey:@"info"]];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"error*___%@",[error localizedDescription]);
        [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"网络错误"];
    }];
}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    // Return the number of rows in the section.

    return [LineMutableArray count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellId=@"LineCell";
    
    LineProjectTableCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (cell == nil) {
        cell = [[LineProjectTableCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    LineProjectModel *lineModel=[LineMutableArray objectAtIndex:indexPath.row];
    cell.projectImage.image=[UIImage imageNamed:@"folder"];
    cell.projectName.text=lineModel.name;
    cell.projectPeople.text=lineModel.responsible_name;
    cell.startDate.text=lineModel.start_date;
    cell.endDate.text=lineModel.end_date;
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    UIStoryboard *sb=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    LineProjectModel *lineModel=[LineMutableArray objectAtIndex:indexPath.row];
    
        MMCImageController *view=(MMCImageController *)[sb instantiateViewControllerWithIdentifier:@"MMCImage"];
        [view getLineProjectModel:lineModel style:statye];
        [self.navigationController pushViewController:view animated:YES];
    
}

@end
