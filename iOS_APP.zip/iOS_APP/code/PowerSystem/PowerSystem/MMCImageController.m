//
//  MMCImageController.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/15.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "MMCImageController.h"
#import "MMCTableViewCell.h"
#import "AFNetworking.h"
#import "ImageCellModel.h"
#import "MMCPushImageController.h"
@interface MMCImageController ()
{
    LineProjectModel *project;
    NSString *type;
}
@end

@implementation MMCImageController
@synthesize imageArray,style,imagePathArray,imagesPathAllArray,imageNameArray;
- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView setTableFooterView:[[UIView alloc] initWithFrame:CGRectZero]];
    self.tableView.backgroundColor=STATICBACKCOLOR;
    self.navigationItem.title=@"图片";
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    [self navRightButton];
   // dispatch_async(dispatch_get_global_queue(0, 0), ^{
        [self getImageData];
   // });
    
    __weak UITableView *tableView = self.tableView;
    // 下拉刷新
    tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        //刷新数据
        //dispatch_async(dispatch_get_global_queue(0, 0), ^{
            [self getImageData];
       // });
        // 模拟延迟加载数据，因此2秒后才调用（真实开发中，可以移除这段gcd代码）
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            // 结束刷新
            [tableView.header endRefreshing];
            [tableView reloadData];
        });
    }];
}
-(void)navRightButton{
    UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitle:@"拍照" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(RightButtonPhoto) forControlEvents:UIControlEventTouchUpInside];
    button.frame = CGRectMake(0, 0, 40, 40);
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.rightBarButtonItem = rightButton;
}
-(void)RightButtonPhoto{
    UIActionSheet *myActionSheet = [[UIActionSheet alloc]
                                    initWithTitle:nil
                                    delegate:self
                                    cancelButtonTitle:@"取消"
                                    destructiveButtonTitle:nil
                                    otherButtonTitles: @"从相册选择", @"拍照",nil];
    [myActionSheet showInView:self.tableView];
//拍照
//    if ([self takePhoto]) {
//        UIImagePickerController *controller = [[UIImagePickerController alloc] init];
//        [controller setSourceType:UIImagePickerControllerSourceTypeCamera];// 设置类型
//        
//        
//        // 设置所支持的类型，设置只能拍照，或则只能录像，或者两者都可以
//        NSString *requiredMediaType = ( NSString *)kUTTypeImage;
//        //NSString *requiredMediaType1 = ( NSString *)kUTTypeMovie;
//        
//        NSArray *arrMediaTypes=[NSArray arrayWithObjects:requiredMediaType,nil];
//        [controller setMediaTypes:arrMediaTypes];
//        
//        [controller setAllowsEditing:YES];// 设置是否可以管理已经存在的图片或者视频
//        [controller setDelegate:self];// 设置代理
//        [self.navigationController presentViewController:controller animated:YES completion:^{
//            
//        }];
//    }
    
}
#pragma mark - SheetView
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:
            [self LocalPhoto];
            break;
        case 1:
            [self takePhoto];
            break;
        case 2:
            
            break;
        default:
            break;
    }
}
-(void)LocalPhoto{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    //资源类型为图片库
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    picker.delegate = self;
    //设置选择后的图片可被编辑
    picker.allowsEditing = YES;
    [self presentViewController:picker animated:YES completion:^{
        
    }];
}
-(BOOL)takePhoto{
    UIImagePickerControllerSourceType sourceType = UIImagePickerControllerSourceTypeCamera;
    //判断是否有相机
    if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera]){
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        picker.delegate=self;
        //设置拍照后的图片可被编辑
        picker.allowsEditing = YES;
        //资源类型为照相机
        picker.sourceType = sourceType;
        
        [self presentViewController:picker animated:YES completion:^{
            
        }];
        return YES;
    }
    return NO;
}
//修改拍照界面按钮
//-(UIView *)findView:(UIView *)aView withName:(NSString *)name{
//    Class cl = [aView class];
//    NSString *desc = [cl description];
//    if ([name isEqualToString:desc])
//        return aView;
//    for (UIView *view in aView.subviews) {
//        Class cll = [view class];
//        NSString *stringl = [cll description];
//        if ([stringl isEqualToString:name]) {
//            return view;
//        }
//    }
//    return nil;
//}
//
//-(void)addSomeElements:(UIViewController *)viewController{
//    UIView *PLCameraView = [self findView:viewController.view withName:@"PLCameraView"];
//    UIView *PLCropOverlay = [self findView:PLCameraView withName:@"PLCropOverlay"];
//    UIView *bottomBar = [self findView:PLCropOverlay withName:@"PLCropOverlayBottomBar"];
//    UIImageView *bottomBarImageForSave = [bottomBar.subviews objectAtIndex:0];
//    UIButton *retakeButton=[bottomBarImageForSave.subviews objectAtIndex:0];
//    [retakeButton setTitle:@"重拍"  forState:UIControlStateNormal];
//    UIButton *useButton=[bottomBarImageForSave.subviews objectAtIndex:1];
//    [useButton setTitle:@"保存" forState:UIControlStateNormal];
//    UIImageView *bottomBarImageForCamera = [bottomBar.subviews objectAtIndex:1];
//    UIButton *cancelButton=[bottomBarImageForCamera.subviews objectAtIndex:1];
//    [cancelButton setTitle:@"取消" forState:UIControlStateNormal];
//}
//
//- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated
//{
//    [self addSomeElements:viewController];
//}

-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo{
    UIImage *images=[editingInfo objectForKey:UIImagePickerControllerOriginalImage];
    //当图片不为空时显示图片并保存图片
    if (images != nil) {
        //图片显示在界面上
        //以下是保存文件到沙盒路径下
        //把图片转成NSData类型的数据来保存文件
        if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
            //如果是 来自照相机的image，那么先保存
//            UIImageWriteToSavedPhotosAlbum(images, self,
//                                           @selector(imageWasSavedSuccessfully:didFinishSavingWithError:contextInfo:),
//                                           nil);
        }
//        NSData *data;
//        //判断图片是不是png格式的文件
//        if (UIImagePNGRepresentation(images)) {
//            //返回为png图像。
//            data = UIImagePNGRepresentation(images);
//        }else {
//            //返回为JPEG图像。
//            data = UIImageJPEGRepresentation(images, 1.0);
//        }
    }
    //关闭相册界面
    [picker dismissViewControllerAnimated:YES completion:^{
        
    }];
    [self pushImageController:images];
}
- (void) imageWasSavedSuccessfully:(UIImage *)paramImage didFinishSavingWithError:(NSError *)paramError contextInfo:(void *)paramContextInfo
{
    if (paramError == nil){
        NSLog(@"Image was saved successfully.");
    } else {
        NSLog(@"An error happened while saving the image.");
        NSLog(@"Error = %@", paramError);
    }
}

-(void)pushImageController :(UIImage *)image{
    UIStoryboard *sb=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    MMCPushImageController *view=(MMCPushImageController *)[sb instantiateViewControllerWithIdentifier:@"MMCPushImage"];
    [view getPushImage:image model:project style:style];
    [self.navigationController pushViewController:view animated:YES];
}
-(void)getLineProjectModel:(LineProjectModel *)model style:(LineString )lineStyle{
    project=model;
    style=lineStyle;
}

-(void)getImageData{
    NSString *str= [NSString stringWithFormat:@"http://%@/Mobile/MediaList",IPAddress];
    
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    if (style==lineONE) {
        type=@"line";
    }else if (style==lineTwo)
    {
        type=@"electric";
    }
    else{
        type=@"soil";
    }
    NSDictionary *parameters = @{@"project_id": project.id,@"type":type,@"token":[[DataFormatterSingle shareCore] getInfoToken]};
//        NSDictionary *parameters = @{@"project_id": project.id,@"type":type,@"token":[[DataFormatterSingle shareCore] getInfoToken],@"page":@"0",@"page_size":@"0"};
    [manager GET:str parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"--%@",[operation responseString]);
        NSNumber *status=[responseObject objectForKey:@"status"];

        if ([status intValue]==1){
            imageArray =[NSMutableArray new];
            imagePathArray=[NSMutableArray new];
            imagesPathAllArray=[NSMutableArray new];
            imageNameArray=[NSMutableArray new];
            NSArray *arrays=[responseObject objectForKey:@"data"];
            int num=0;
            for(int i=0;i<[arrays count];i++){
                BOOL add=NO;
                NSDictionary *dictt=[arrays objectAtIndex:i];
                NSString *timedate=[dictt objectForKey:@"date"];
                timedate=[timedate substringWithRange:NSMakeRange(0, 10)];
                
                for (int i=num;i<[arrays count];i++){
                    
                    NSDictionary *dic=[arrays objectAtIndex:i];
                    NSString *date=[dic objectForKey:@"date"];
                    date=[date substringWithRange:NSMakeRange(0, 10)];
                    
                    if ([timedate isEqualToString:date]) {
                        add=YES;
                        num++;
                         NSString *imagePath=[NSString stringWithFormat:@"http://%@/%@",IPAddress,[dic objectForKey:@"path"]];
                        [imagePathArray addObject:imagePath];
                        [imageNameArray addObject:[dic objectForKey:@"name"]];
                    }else{
                        if (add==YES) {
                            add=NO;
                            NSDictionary *imageDate=@{@"imageDate":timedate,@"imagePaths":imagePathArray,@"imageName":imageNameArray};
                            [imagesPathAllArray addObject:imageDate];
                            imagePathArray=[NSMutableArray new];
                            imageNameArray=[NSMutableArray new];
                            continue;
                        }
                    
                    }
                    
                }
                if (add==YES) {
                    NSDictionary *imageDate=@{@"imageDate":timedate,@"imagePaths":imagePathArray,@"imageName":imageNameArray};
                    [imagesPathAllArray addObject:imageDate];
                    imagePathArray=[NSMutableArray new];
                    imageNameArray=[NSMutableArray new];
                }

            }
            [self.tableView reloadData];
        }else{
            [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:[responseObject objectForKey:@"info"]];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"error*___%@",[error localizedDescription]);
        [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"网络错误"];
    }];

}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    
    return [imagesPathAllArray count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    // Return the number of rows in the section.
 
    return 1;
}

//定义header
- (UIView *) tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    UIView *view=[[UIView alloc]init];
    NSDictionary *dic=[imagesPathAllArray objectAtIndex:section];
    view.frame=CGRectMake(0, 0, kScreenW, 30);
    view.backgroundColor=STATICBACKCOLOR;
    UILabel *label=[[UILabel alloc]init];
    label.frame=view.frame;
    label.textAlignment=NSTextAlignmentCenter;
    label.font=[UIFont systemFontOfSize:15.0];
    label.textColor=[UIColor grayColor];
    NSString *dateString=[dic objectForKey:@"imageDate"];
    dateString=[[DataFormatterSingle shareCore]dateYearFormatter:dateString];
    label.text=dateString;
    [view addSubview:label];
    return view;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 30;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellId=@"ImageTableCell";
    MMCTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    
    if (cell == nil) {
        cell = [[MMCTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    NSDictionary *dic=[imagesPathAllArray objectAtIndex:indexPath.section];
    NSMutableArray *array=[dic objectForKey:@"imagePaths"];
    NSMutableArray *nameArray=[dic objectForKey:@"imageName"];
    [cell getImagePathArray:array name:nameArray];
    tableView.separatorStyle = UITableViewCellSelectionStyleNone;
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSLog(@"dis-------------");
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSDictionary *dic=[imagesPathAllArray objectAtIndex:indexPath.section];
    NSMutableArray *array=[dic objectForKey:@"imagePaths"];
    CGFloat Height=((kScreenW-3)/4);
    
    CGFloat number=[array count]/4;
    CGFloat numYu=[array count]%4;
    CGFloat height=0;
    if (numYu>0) {
        height=((kScreenW-3)/4);
    }else{
        height=0;
    }
    CGFloat maxHeight=number*Height+height;
    return maxHeight;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
