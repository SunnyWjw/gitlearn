//
//  WainingConnectModel.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/20.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WainingConnectModel : NSObject


@property(nonatomic,copy)NSNumber *idStr;
@property(nonatomic,copy)NSNumber *proj_idStr;
@property(nonatomic,copy)NSString *typeStr;
@property(nonatomic,copy)NSString *contentStr;
@property(nonatomic,copy)NSNumber *has_readStr;
@property(nonatomic,copy)NSNumber *user_idStr;
@property(nonatomic,copy)NSString *hashStr;

+(WainingConnectModel*)rewriteModel:(NSDictionary *)dict;
-(WainingConnectModel*)initWithDict:(NSDictionary *)dict;
@end
