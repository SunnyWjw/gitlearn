//
//  FileDataTableController.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/17.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FileDataTableController : UITableViewController
@property (nonatomic,strong)NSMutableArray *array;
@end
