//
//  SearchTableController.m
//  PowerSystem
//
//  Created by huhaifeng on 15/8/18.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import "SearchTableController.h"
#import "SearchWebController.h"
#import "SearchFileModel.h"
#import "DownloadFiledataCell.h"
@interface SearchTableController ()
{
    UISearchDisplayController *searchDisplayController;
    NSMutableArray *filterData;
    PlanManagerModel *planModel;
    SearchFileModel *selectModel;
}
@end

@implementation SearchTableController
@synthesize array,arrayName,cellButtonBlock;
- (void)viewDidLoad {
    [super viewDidLoad];
    arrayName=[NSMutableArray new];
    [self.tableView setTableFooterView:[[UIView alloc] initWithFrame:CGRectZero]];
    self.navigationItem.title=@"文件";
    [self initSearchBar];
   // dispatch_async(dispatch_get_global_queue(0, 0), ^{
        [self getFileDataSearch];
   // });
}
-(void)initSearchBar{
    UISearchBar *searchBar=[[UISearchBar alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 44)];
    searchBar.placeholder=@"搜索";
    self.tableView.tableHeaderView=searchBar;
    searchDisplayController = [[UISearchDisplayController alloc] initWithSearchBar:searchBar contentsController:self];
    searchDisplayController.searchResultsDataSource=self;
    searchDisplayController.searchResultsDelegate=self;
}
-(void)getFileDataType:(PlanManagerModel *)model{
    planModel=model;
}

-(void)getFileDataSearch{
    NSString *str=[NSString stringWithFormat:@"http://%@/Mobile/FileList",IPAddress];
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
//    NSNumber* num=@0;
//    NSNumber* number=@10;
    NSDictionary *parameter=@{@"type":planModel.value};
//    NSDictionary *parameter=@{@"type":planModel.value,@"page":num,@"page_size":number};
    [manager GET:str parameters:parameter success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"--%@",[operation responseString]);
        NSNumber *status=[responseObject objectForKey:@"status"];
        if ([status intValue]==1){
            array=[NSMutableArray new];
            NSArray *arrays=[responseObject objectForKey:@"data"];
            for(NSDictionary *dic in arrays){
                SearchFileModel *model=[[SearchFileModel alloc]init];
                [model setValuesForKeysWithDictionary:dic];
                [array addObject:model];
                [arrayName addObject:model.name];
            }
            [self.tableView reloadData];
        }
        else{
            [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:[responseObject objectForKey:@"info"]];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"error*___%@",[error localizedDescription]);
        [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"网络错误"];
    }];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    // Return the number of rows in the section.
    if (tableView==self.tableView) {
        return [array count];
    }
    else
    {
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self contains [cd] %@",searchDisplayController.searchBar.text];
        filterData =  [[NSMutableArray alloc] initWithArray:[arrayName filteredArrayUsingPredicate:predicate]];
        return filterData.count;
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellId=@"Download";
    
    DownloadFiledataCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (cell == nil) {
        cell = [[DownloadFiledataCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    SearchFileModel *model=[array objectAtIndex:indexPath.row];
    NSArray *paths=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
    NSString *path=[paths objectAtIndex:0];
    __weak SearchTableController *controller = self;
    __block NSMutableArray *arrays=array;
    
    cellButtonBlock=^(UIButton *sender){
        NSLog(@"-----index:%ld",(long)sender.tag);
        NSIndexPath *payh=[NSIndexPath indexPathForRow:sender.tag inSection:0];
        
        DownloadFiledataCell *celler=(DownloadFiledataCell*)[tableView cellForRowAtIndexPath:payh];
        
        SearchFileModel *modeler=[arrays objectAtIndex:sender.tag];
        UIProgressView *progress=[[UIProgressView alloc]init];
        progress.frame=CGRectMake(celler.DownName.frame.origin.x, CGRectGetMaxY(celler.DownName.frame)+2, celler.DownName.frame.size.width, 2);
        progress.progress=0.0;
        
        [celler addSubview:progress];
        [controller downloadFileURL:modeler.path savePath:path fileName:modeler.name tag:sender.tag pro:progress];
        
    };

    cell.DownButton.tag=indexPath.row;
    [cell.DownButton addTarget:self action:@selector(cellButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    
    if ([[DataFormatterSingle shareCore] retrieveFileData:path Name:model.name]) {
        cell.DownButton.userInteractionEnabled=NO;
        
        [cell.DownButton setImage:[UIImage imageNamed:@"download_on"] forState:UIControlStateNormal];
        cell.styleLabel.text=@"〉";
        //cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }else{
        cell.DownButton.userInteractionEnabled=YES;

        [cell.DownButton setImage:[UIImage imageNamed:@"download_off"] forState:UIControlStateNormal];
        cell.styleLabel.text=@" ";
        //cell.accessoryType = UITableViewCellAccessoryNone;
    }
    cell.DownName.text=model.name;
    NSString *typeImage=[[DataFormatterSingle shareCore]boolForType:model.path];
    UIImage *image;
    if ([typeImage isEqualToString:@"doc"]||[typeImage isEqualToString:@"docx"])
    {
        image=[UIImage imageNamed:@"file_doc"];
    }
    else if ([typeImage isEqualToString:@"xlsx"]||[typeImage isEqualToString:@"xls"])
    {
        image=[UIImage imageNamed:@"file_xlsx"];
    }
    else if ([typeImage isEqualToString:@"gif"])
    {
        image=[UIImage imageNamed:@"file_gif"];
    }
    else if ([typeImage isEqualToString:@"jpg"])
    {
        image=[UIImage imageNamed:@"file_jpg"];
    }
    else if ([typeImage isEqualToString:@"png"])
    {
        image=[UIImage imageNamed:@"file_png"];
    }
    else if ([typeImage isEqualToString:@"ppt"])
    {
        image=[UIImage imageNamed:@"file_ppt"];
    }
    else if ([typeImage isEqualToString:@"pdf"])
    {
        image=[UIImage imageNamed:@"file_pdf"];
    }
    else if ([typeImage isEqualToString:@"zip"]||[typeImage isEqualToString:@"rar"])
    {
        image=[UIImage imageNamed:@"file_zip"];
    }
    else
    {
        image=[UIImage imageNamed:@"file_zip"];
    }
    cell.DownImage.image=image;
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    return cell;
}

-(void)cellButtonClick:(UIButton *)sender{
    
    cellButtonBlock(sender);
}
- (void)downloadFileURL:(NSString *)aUrl savePath:(NSString *)aSavePath fileName:(NSString *)aFileName tag:(NSInteger)aTag pro:(UIProgressView *)proView{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    //检查本地文件是否已存在
    NSString *fileName = [NSString stringWithFormat:@"%@/%@", aSavePath, aFileName];
    
    //检查附件是否存在
    if ([fileManager fileExistsAtPath:fileName]) {
        
    }
    else
    {
        if (![fileManager fileExistsAtPath:aSavePath]) {
            [fileManager createDirectoryAtPath:aSavePath withIntermediateDirectories:YES attributes:nil error:nil];
        }
        NSString *str=[NSString stringWithFormat:@"http://%@/%@",IPAddress,aUrl];
        NSString *strurl=[str stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSURL *url = [[NSURL alloc] initWithString:strurl];
        NSURLRequest *request = [NSURLRequest requestWithURL:url];
        AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
        operation.inputStream   = [NSInputStream inputStreamWithURL:url];
        operation.outputStream  = [NSOutputStream outputStreamToFileAtPath:fileName append:NO];
        [operation setDownloadProgressBlock:^(NSUInteger bytesRead, long long totalBytesRead, long long totalBytesExpectedToRead) {
            NSLog(@"is download：%f", (float)totalBytesRead/totalBytesExpectedToRead);
            proView.hidden=NO;
            proView.progress=(float)totalBytesRead/totalBytesExpectedToRead;
            //cellproessBlock(aTag,(float)totalBytesRead/totalBytesExpectedToRead);
        }];
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
            [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"下载成功"];
            [proView removeFromSuperview];
            
            [self.tableView reloadData];
            // NSData *audioData = [NSData dataWithContentsOfFile:fileName];
            //设置下载数据到res字典对象中并用代理返回下载数据NSData
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            //下载失败
            [fileManager removeItemAtPath:fileName error:nil];
            [proView removeFromSuperview];
            NSLog(@"error-----:%@",[error localizedDescription]);
            [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"网络错误"];
        }];

        
        [operation start];

    }
}
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:
            [self pushSearchWebController];
            break;
        case 1:
            [self pushUIDocumentInteraction];
            break;
        default:
            break;
    }
}
-(void)pushUIDocumentInteraction{
    if (![[DataFormatterSingle shareCore]retrieveFileData:nil Name:selectModel.name]) {
        [[SHKActivityIndicator currentIndicatorCar]displayCompletedCar:@"请先下载该文件"];
        return;
    }
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docDir = [paths objectAtIndex:0];
    NSString *filePath = [docDir stringByAppendingPathComponent:selectModel.name];
    NSURL *url = [NSURL fileURLWithPath:filePath];
    [self setupDocumentControllerWithURL:url];
    [self.docInteractionController presentOptionsMenuFromRect:CGRectMake(0, 20, 1500, 40) inView:self.view  animated:YES];
}
- (void)setupDocumentControllerWithURL:(NSURL *)url
{
    if (self.docInteractionController == nil)
    {
        self.docInteractionController = [UIDocumentInteractionController interactionControllerWithURL:url];
        self.docInteractionController.delegate = self;
    }
    else
    {
        self.docInteractionController.URL = url;
    }
}

-(void)pushSearchWebController{
    UIStoryboard *sb=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
    SearchWebController *view=(SearchWebController *)[sb instantiateViewControllerWithIdentifier:@"SearchWeb"];
    [view getWebUrl:nil model:selectModel];
    [self.navigationController pushViewController:view animated:YES];
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    selectModel=[array objectAtIndex:indexPath.row];
    UIActionSheet *action=[[UIActionSheet alloc] initWithTitle:@"预览" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"直接预览", @"从应用选择",nil];
    [action showInView:self.tableView];
    return;
}
//定义header
//- (UIView *) tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
//
//}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0;
}
//- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    return 40;
//}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
