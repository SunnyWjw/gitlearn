//
//  clickheaderMessageModel.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/10.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface clickheaderMessageModel : NSObject
@property(nonatomic,copy)NSString *user_name;
@property(nonatomic,copy)NSString *email;
@property(nonatomic,copy)NSString *type;
@property(nonatomic,copy)NSString *type_name;
@end
