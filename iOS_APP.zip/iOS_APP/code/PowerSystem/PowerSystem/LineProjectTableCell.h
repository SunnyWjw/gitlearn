//
//  LineProjectTableCell.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/11.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LineProjectTableCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *projectImage;
@property (weak, nonatomic) IBOutlet UILabel *projectName;

@property (weak, nonatomic) IBOutlet UILabel *projectPeople;

@property (weak, nonatomic) IBOutlet UILabel *startDate;

@property (weak, nonatomic) IBOutlet UILabel *endDate;
@end
