//
//  LineDetailCellFrame.h
//  PowerSystem
//
//  Created by huhaifeng on 15/8/12.
//  Copyright (c) 2015年 huhaifeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LineDetailCellModel.h"
@interface LineDetailCellFrame : NSObject
@property(nonatomic,assign,readonly) CGRect backImageFrame;
@property(nonatomic,assign,readonly) CGRect projectTitleFrame;
@property(nonatomic,assign,readonly) CGRect start_dateFrame;
@property(nonatomic,assign,readonly) CGRect fengefuFrame;
@property(nonatomic,assign,readonly) CGRect end_dateFrame;
@property(nonatomic,assign,readonly) CGRect circleImageFrame;
@property(nonatomic,assign,readonly) CGRect lineFrame;
@property(nonatomic,assign,readonly) CGRect responNameLabelFrame;
@property(nonatomic,assign,readonly) CGRect dateLabelFrame;
@property(nonatomic,assign,readonly) CGRect complete_stdFrame;

@property(nonatomic,assign,readonly)int maxHeight;
@property(nonatomic,strong)LineDetailCellModel *weibo;

-(CGSize)sizeWithString:(NSString*)str font:(UIFont *)font maxSize:(CGSize)maxSize;
@end
